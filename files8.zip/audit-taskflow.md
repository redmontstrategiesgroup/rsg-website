# Codebase Audit — TaskFlow

**Date:** 2026-07-23
**Repository:** `/home/claude/taskflow` (local fixture) · **Commit/branch:** `main` (uncommitted working tree)
**Detected stack:** Node.js + TypeScript (CommonJS), `node:http` server, in-memory stores; client React (`web/`)
**Auditor's stance:** read-only forensic audit. The only change made to run verifications was `npm install` (to enable `tsc`, `node --test`, and `npm audit`). No source was modified.

---

## 1. Executive summary

TaskFlow presents as a finished team task manager — the README advertises secure auth, real-time tasks, email invites, Stripe billing, and a live analytics dashboard. The reality is uneven: **the task core is genuinely real and even tested, but the money-making and "live" surfaces are fake, the authorization model is broken in two places, and production secrets are committed to the repo.** The app also cannot currently build, and the HTTP layer isn't wired to any of the route handlers, so as it stands nothing is actually served beyond a health stub.

- **Product maturity rating:** **Early MVP** (leaning toward Prototype) — the real task engine keeps it out of pure-prototype territory, but broken auth, fake billing/analytics, a failing build, and an unwired API make it non-deployable today.
- **Findings:** **3 Critical · 6 High · 3 Medium · 1 Low**
- **Bottom line:** A real task core wrapped in a not-yet-real product — fix the leaked secrets and the two authorization holes *today*, then make the API actually reachable before touching features.

---

## 2. What the product claims to do (reverse-engineered intent)

Triangulated from the README, client UI copy (`web/dashboard.tsx`), route handlers, the DB/env config, and the auth model:

- Users can sign up and log in securely, with member/admin **team roles**.
- Users can **create and track tasks** ("in real time").
- Users can **invite teammates by email**.
- Users can **upgrade to Pro and pay monthly via Stripe**.
- Users see a **live analytics dashboard** (active users, MRR, churn).
- Admins can remove users.

## 3. Claimed vs. Real — capability matrix

| Capability | Status | Evidence (file / trace) | Severity if broken |
|---|---|---|---|
| Secure authentication & team roles | **Partial** | Sessions are real & server-verified (`src/auth.ts` `requireUser`) — but passwords are plaintext (`auth.ts:9,16`) and admin authz is bypassable (`routes/admin.ts:8`) | Critical / High |
| Create & track tasks | **Real** | Persisted store with owner-scoped listing (`src/store.js`, `routes/tasks.ts:5-14`); covered by passing tests | — (IDOR on single-task fetch, see H1) |
| Invite teammates *by email* | **Partial** | Invite record persists (`routes/invites.ts:11`) but **no email is ever sent**; `RESEND_API_KEY` configured, never used | Medium |
| Upgrade to Pro / pay via Stripe | **Fake** | `routes/billing.ts` returns `{success:true}` with no charge, no persistence; `STRIPE_SECRET_KEY` never called | Critical |
| Live analytics dashboard | **Fake** | `src/analytics.ts` returns hardcoded `1240 / 8400 / …`; rendered as live in `web/dashboard.tsx` | High |
| Remove users (admin) | **Broken** | `routes/admin.ts` gates on `body.role` (client-supplied), not the session | Critical |

**Features claimed but absent/fake in the backend:** Stripe billing (entirely fake), the "live" analytics dashboard (hardcoded), and email delivery for invites (never sent). Additionally, **none of the route handlers are connected to the HTTP server** (`src/server.ts` returns a health stub for every request), so the advertised API is not actually reachable in its current state.

---

## 4. Verification results (commands actually run)

| Check | Result | Notes |
|---|---|---|
| Type check (`tsc --noEmit`) | ❌ FAIL | `src/analytics.ts(8,5): error TS2322: Type 'string' is not assignable to type 'number'` |
| Lint | ⚠️ n/a | No ESLint config present — the project has no linting at all (see M3) |
| Tests (`node --test`) | ✅ PASS | 3/3 passing — but they cover **only** the task store; nothing tests auth, billing, or authz |
| Production build (`tsc`) | ❌ FAIL | Same TS2322 error — the project cannot compile/ship as-is |
| Dependency audit (`npm audit`) | ✅ PASS | 0 vulnerabilities |
| Secret scan | ❌ LEAKS | Committed `.env` with a **live** Stripe key, a Resend key, the session secret, and DB credentials |

**Actions taken to run the project:** `npm install` only. No source changes.

---

## 5. Findings

### 🔴 Critical

#### C1 — Production secrets committed to the repository
1. **Problem** (CONFIRMED): A committed `.env` contains live third-party credentials and database access.
2. **Affected paths:** `.env:1-4`
3. **Evidence** (masked by the scanner):
   ```
   STRIPE_SECRET_KEY=sk_live_51Qx…REDACTED     ← LIVE Stripe secret key
   RESEND_API_KEY=re_ab1…REDACTED
   SESSION_SECRET=super-…REDACTED               ← signs all session tokens
   DATABASE_URL=postgres://admin:S3cretPassw0rd@db.internal:5432/taskflow
   ```
4. **User / business impact:** Anyone with repo access (or anyone the repo is ever shared/leaked to) can charge/refund via the live Stripe account, send email as the company, forge session tokens for any user, and connect directly to the production database. This is a full compromise of billing, identity, and data.
5. **Recommended correction:** Treat all four as compromised and **rotate them now**. Remove `.env` from the repo, add it to `.gitignore`, and load secrets from the deployment platform's secret manager. Because they may persist in git history, scrub history (e.g. `git filter-repo`) after rotating.
6. **Estimated effort:** ~2–3 hrs (rotation + wiring a secret store + history scrub).
7. **Fix before further feature development?** **Yes** — nothing else matters while live keys are exposed.

#### C2 — Admin authorization is bypassable (privilege escalation)
1. **Problem** (CONFIRMED): The "delete user" endpoint checks a role supplied in the request body instead of the authenticated session, so any logged-in user can delete any user.
2. **Affected paths:** `src/routes/admin.ts:6-13`
3. **Evidence:**
   ```ts
   if (body.role !== "admin") return { status: 403, ... }; // client-supplied role
   // correct check: if (actor.role !== "admin") ...
   ```
   `actor` (the real, session-derived user) is fetched but its role is never checked.
4. **User / business impact:** Any authenticated member can escalate to admin actions and delete arbitrary accounts — account takeover / destructive action across the whole tenant base.
5. **Recommended correction:** Authorize on the server-verified principal: `if (actor.role !== "admin") return 403`. Never read privilege from client input. Add a regression test.
6. **Estimated effort:** ~30 min (one-line fix + test).
7. **Fix before further feature development?** **Yes.**

#### C3 — "Upgrade to Pro" billing is fake and reports false success
1. **Problem** (CONFIRMED): The paid-upgrade endpoint never charges anything and never persists a plan change; a bare `catch` returns success even on failure.
2. **Affected paths:** `src/routes/billing.ts:6-14`
3. **Evidence:**
   ```ts
   // TODO: charge via Stripe … then persist the new plan
   return { status: 200, body: { success: true, plan: "pro" } }; // no charge, no persistence
   } catch { return { status: 200, body: { success: true, plan: "pro" } }; } // swallows all errors
   ```
   No `stripe` import or call site exists anywhere in the repo (confirmed by grep).
4. **User / business impact:** The core revenue flow is theater. Users can be shown a successful "upgrade" while no payment occurs and no entitlement is recorded — the business collects no money and its own state is wrong. The false-success `catch` also masks any future real failure.
5. **Recommended correction:** Implement the real Stripe charge/subscription server-side, persist the resulting plan against the user, and remove the swallow-all `catch` so failures surface honestly. Until implemented, the UI should not claim the feature works.
6. **Estimated effort:** ~2–4 days (Stripe integration, plan persistence, webhooks, tests).
7. **Fix before further feature development?** **Yes** if monetization is in scope; otherwise remove the claim from the UI.

### 🟠 High

#### H1 — IDOR: any user can read any task by ID
1. **Problem** (CONFIRMED): `getTaskById` fetches a task by id with no ownership check.
2. **Affected paths:** `src/routes/tasks.ts:16-21`
3. **Evidence:**
   ```ts
   const task = getTask(id); // BUG: missing `task.ownerId === user.id` check
   ```
   (Contrast `listMyTasks`, which *is* correctly scoped — so the pattern is known, just not applied here.)
4. **User / business impact:** Any authenticated user can read other users'/tenants' tasks by guessing or enumerating IDs — a cross-tenant data leak.
5. **Recommended correction:** After fetching, verify `task.ownerId === user.id` (or an explicit team-membership check) before returning; else 404.
6. **Estimated effort:** ~30 min + test.
7. **Fix before further feature development?** **Yes.**

#### H2 — Passwords stored and compared in plaintext
1. **Problem** (CONFIRMED): User passwords are stored as plaintext and compared with `===`.
2. **Affected paths:** `src/auth.ts:9`, `src/auth.ts:16`
3. **Evidence:**
   ```ts
   const user: User = { ...role, password };      // plaintext at rest
   if (!user || user.password !== password) ...    // plaintext comparison
   ```
4. **User / business impact:** Any database exposure (made far more likely by the leaked `DATABASE_URL` in C1) hands over every user's actual password, enabling credential-stuffing across other sites.
5. **Recommended correction:** Hash with a slow algorithm (bcrypt/argon2) at signup; compare with the library's verify. Migrate existing records on next login.
6. **Estimated effort:** ~2–4 hrs.
7. **Fix before further feature development?** **Yes.**

#### H3 — Production build fails (project cannot ship)
1. **Problem** (CONFIRMED): `tsc` fails, so both `typecheck` and `build` error out.
2. **Affected paths:** `src/analytics.ts:8`
3. **Evidence:** `error TS2322: Type 'string' is not assignable to type 'number'` (`churn: "3%"` vs `churn: number`).
4. **User / business impact:** No production artifact can be produced — the app is undeployable until this compiles.
5. **Recommended correction:** Fix the type (make `churn` a number, or change the type). Note this is a symptom of H4/analytics being fabricated — real analytics wouldn't hardcode a mismatched string.
6. **Estimated effort:** ~5 min.
7. **Fix before further feature development?** **Yes** (trivial, and blocks everything downstream).

#### H4 — The advertised "live analytics dashboard" is hardcoded mock data
1. **Problem** (CONFIRMED): Dashboard stats are static literals rendered as if live.
2. **Affected paths:** `src/analytics.ts:4-9`, `web/dashboard.tsx:2-3`
3. **Evidence:** `getDashboardStats()` returns `activeUsers: 1240, mrr: 8400, …` with no data source; the client renders them directly.
4. **User / business impact:** A headline feature is fabricated. Users make decisions on numbers that never change and reflect nothing real; the "live analytics" claim is false.
5. **Recommended correction:** Compute stats from real data (queries/aggregations), or clearly label the dashboard as a placeholder and remove the "live" claim until built.
6. **Estimated effort:** ~2–5 days depending on the metrics.
7. **Fix before further feature development?** **Yes** if it's a promoted feature; otherwise stop advertising it.

#### H5 — No tests on critical paths (auth, authz, billing)
1. **Problem** (CONFIRMED): The only tests cover the task store; auth, authorization, invites, and billing are untested.
2. **Affected paths:** `test/store.test.mjs` (the sole test file)
3. **Evidence:** 3 passing tests, all for `src/store.js`. No test references `auth`, `admin`, `billing`, or `tasks` route logic.
4. **User / business impact:** The most dangerous code (the very code with C2/H1/H2 bugs) has no safety net, so regressions there ship silently.
5. **Recommended correction:** Add tests for session enforcement, the admin role check, task ownership, and (once real) the billing flow. Prioritize the paths that touch auth and money.
6. **Estimated effort:** ~1–2 days.
7. **Fix before further feature development?** Recommended before building on these paths.

#### H6 — Route handlers are not wired to the HTTP server (API unreachable)
1. **Problem** (CONFIRMED, structural): `server.ts` returns a health stub for every request; no handler is dispatched by method/path.
2. **Affected paths:** `src/server.ts:12-15`
3. **Evidence:** `createServer((_req, res) => { … res.end(JSON.stringify({ ok: true })); })` — the `handlers` object is declared but never routed.
4. **User / business impact:** As deployed, the product exposes nothing but `{ok:true}`. Every other finding in this section describes handler logic that *would* run once routing exists — the code is real, but currently unreachable.
5. **Recommended correction:** Implement a router mapping method+path to the handlers, parse bodies/auth headers, and return handler results. This is also the right moment to add auth middleware centrally.
6. **Estimated effort:** ~1 day.
7. **Fix before further feature development?** **Yes** — without it, none of the backend is actually usable.

### 🟡 Medium

#### M1 — Invites are stored but never emailed
1. **Problem** (CONFIRMED): `inviteTeammate` persists an invite record but sends no email, despite the "invite by email" claim; `RESEND_API_KEY` is configured yet unused.
2. **Affected paths:** `src/routes/invites.ts:8-14`
3. **Evidence:** `invites.push(invite)` then returns; no Resend/email call anywhere (confirmed by grep).
4. **User / business impact:** Invited teammates never receive anything, so the team-growth flow silently dead-ends.
5. **Recommended correction:** Send the invite email (Resend) with the token link after persisting; handle/report send failures.
6. **Estimated effort:** ~half a day.
7. **Fix before further feature development?** No (but needed for the invite flow to function).

#### M2 — Multiple advertised UI actions do nothing
1. **Problem** (CONFIRMED): "Export to CSV" is a no-op, "Invite teammate" only logs to console, and "Upgrade to Pro" is a dead link.
2. **Affected paths:** `web/dashboard.tsx:10-12`
3. **Evidence:**
   ```tsx
   <button onClick={() => {}}>Export to CSV</button>
   <button onClick={() => { console.log("invite clicked"); }}>Invite teammate</button>
   <a href="#">Upgrade to Pro</a>
   ```
4. **User / business impact:** The UI advertises capabilities that don't exist, eroding trust and inflating perceived completeness.
5. **Recommended correction:** Wire each control to its (real) backend action, or remove it until the feature exists.
6. **Estimated effort:** ~1 day (once the backends exist).
7. **Fix before further feature development?** No.

#### M3 — No linting and no error/loading/empty-state handling
1. **Problem** (CONFIRMED/SUSPECTED): There is no ESLint config, and the client has no error, loading, or empty states around actions (moot today because the handlers are dead, but it will matter once they're wired).
2. **Affected paths:** project root (no `.eslintrc`); `web/dashboard.tsx`
3. **Evidence:** the `lint` script is a placeholder; no async/error/loading UI in the client.
4. **User / business impact:** No automated guardrail against a class of bugs; once actions are real, failures and pending states will be invisible to users.
5. **Recommended correction:** Add ESLint (with `jsx-a11y`), and add error/loading/empty states as the real data flows are built.
6. **Estimated effort:** ~half a day for linting; states folded into feature work.
7. **Fix before further feature development?** No.

### ⚪ Low

#### L1 — Unused dependency
1. **Problem** (CONFIRMED): `date-fns` is declared in `package.json` but never imported.
2. **Affected paths:** `package.json` (`dependencies`)
3. **Evidence:** no `date-fns` import anywhere in `src/` or `web/`.
4. **User / business impact:** Minor install/bundle bloat and dependency-surface noise.
5. **Recommended correction:** Remove it (or use it).
6. **Estimated effort:** ~5 min.
7. **Fix before further feature development?** No.

---

## 6. What's genuinely strong

Credit where due — these are real and worth preserving:

- **Server-side session verification is correct.** `requireUser` (`src/auth.ts:20-25`) validates an unforgeable, HMAC-derived token against server state; the *authentication* mechanism itself is sound. (The problems are around it — plaintext passwords and the admin role check — not in it.)
- **The task engine is real and persists.** `src/store.js` is an actual store with create/read/list/update, and `listMyTasks` correctly scopes results to the caller — the one place authorization is done right.
- **There are real, passing tests for that engine.** `test/store.test.mjs` genuinely exercises persistence and owner-scoping (3/3 green). This is the seed of a real test suite.
- **Clean, typed domain model.** `src/types.ts` gives clear shared types; the codebase is small and readable.

## 7. Biggest technical risks & biggest product gaps

**Top technical risks**
1. Live production secrets exposed in the repo (C1).
2. Privilege escalation via client-supplied role (C2).
3. Plaintext passwords, amplified by the leaked DB URL (H2 + C1).
4. Cross-tenant data read via IDOR (H1).

**Top product gaps**
1. Billing is entirely fake and falsely reports success (C3).
2. The API isn't wired up, so the backend is currently unreachable (H6).
3. The "live" analytics dashboard is hardcoded (H4).
4. Email invites never send (M1).

---

## 8. Product maturity rating

**Rating: Early MVP** (with a caveat: **not currently deployable**).

| Level | Meaning |
|---|---|
| Prototype / Demo | Looks like the product; core flows fake/broken. |
| **Early MVP** ⟵ | Some core flows genuinely work; significant gaps, missing/broken auth on parts, thin tests. |
| Functional MVP | Core value flow works end to end and persists; known gaps; some tests. |
| Production-leaning | Core flows solid and secured; reasonable tests/error handling. |
| Production-ready | Secure, tested, resilient; only polish remaining. |

TaskFlow lands at **Early MVP** because its core value flow (tasks) is genuinely built, persisted, and tested — that's more than a prototype. But it's pulled down hard by fake billing/analytics, two authorization holes, plaintext credentials, a failing build, and an API that isn't connected. To move up a level: wire the API (H6), fix the build (H3), close the two authz holes and hash passwords (C2, H1, H2), and make *or unclaim* billing and analytics (C3, H4).

## 9. Recommended order of operations

Security and correctness first, then reachability, then honesty of features, then tests/polish — each stage unblocks the next.

1. **Stop the bleeding (today):** rotate & remove leaked secrets (C1); fix admin authz (C2); fix the IDOR (H1); hash passwords (H2). These are small changes with the largest risk reduction.
2. **Make it build and run:** fix the type error (H3) and wire routing so handlers are reachable (H6) — until this, none of the backend actually executes.
3. **Make claims real or drop them:** implement Stripe billing (C3), build real analytics or remove the "live" claim (H4), send invite emails (M1), and wire the dead UI controls (M2).
4. **Add a safety net & UX robustness:** tests on auth/authz/billing (H5); linting and error/loading/empty states (M3).
5. **Hygiene:** remove unused deps (L1).

## 10. Phased recovery / improvement roadmap

**Phase 1 — Stabilize security & deployability (~3–5 days)**
Goal: no exposed secrets, no auth holes, and the app builds and actually serves requests.
Includes: C1, C2, H1, H2, H3, H6.

**Phase 2 — Make the product real (~1–2 weeks)**
Goal: every advertised feature either works for real or is removed from the UI.
Includes: C3 (billing), H4 (analytics), M1 (invite email), M2 (dead controls).

**Phase 3 — Harden & polish (~1 week)**
Goal: the dangerous paths are tested and failures are visible to users.
Includes: H5 (tests on critical paths), M3 (linting + error/loading/empty states), L1 (dependency cleanup).

---

_End of audit. Findings reflect the working tree at `main` and the verification runs recorded in §4. Secrets are masked throughout; treat the four values in C1 as compromised regardless of masking. "SUSPECTED" items note what would confirm them._
