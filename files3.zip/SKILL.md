---
name: building-premium-interfaces
description: >-
  Redesign and implement a product interface to a premium, production-grade
  standard: deliberate, modern, trustworthy, and specific to the actual product —
  never a raw component-library dump, generic AI dashboard, or
  gradient-and-glowing-card template. Use whenever the user wants to elevate the
  look, feel, or UX quality of a real interface: "redesign this page/screen/flow,"
  "make this look premium / professional / polished / less generic," "this looks
  like a template or AI slop — fix it," building or refining a product's real UI
  (dashboards, settings, billing, onboarding, tables, forms, detail views),
  implementing a design in the project's existing stack and components, or
  establishing a coherent visual system (typography, spacing, color, elevation,
  motion, components, states). Trigger even when the user never says "premium" —
  any request to seriously improve interface hierarchy, polish, accessibility,
  responsive behavior, or real-world states (loading, empty, success, error) for
  a product UI.
---

# Building Premium Interfaces

The goal is an interface that feels like a real team shipped it on purpose. Premium here does not mean decorated — it means **considered**. Every choice should trace back to who is using the screen, what they came to do, and what they need to trust. The failure mode to avoid at all costs is generic output: an unedited component library, the default "AI dashboard" (six vanity stat cards, a purple gradient, glowing borders, a chart nobody asked for), or a template that could belong to any product. Deliberate and product-specific beats flashy every time.

Work in phases. Don't jump to code.

## Phase 1 — Interrogate before you design

You cannot design a premium interface without knowing what it is for. Before touching layout, establish answers to each of these. If a real user is in the loop and the answer isn't obvious, ask. If you're working alone, make explicit, reasonable assumptions and **state them in the final report** so they can be corrected.

- **Primary user** — who is on this screen, and how sophisticated are they?
- **Primary task** — the one job they came to do.
- **Highest-value action** — the thing the product most wants them to be able to do here. This becomes the single primary action.
- **Most important information** — what must be legible in the first second.
- **Trust concerns** — money, security, destructive/irreversible actions, legal, health, anything where a mistake is costly. These raise the bar for clarity and confirmation.
- **Device sizes that matter** — is this desktop-first, mobile-first, or genuinely both?
- **The four runtime states** — what loading, empty, success, and failure look like for this screen. Design them now, not later.

## Phase 2 — Audit the current system and preserve what's strong

Redesign is not an excuse to throw everything out. Look at what exists first and identify the elements worth keeping: an established brand color, a logo, a recognizable layout pattern, working terminology, an existing component library. **Preserve strong brand elements** and build with the grain of the existing system rather than reinventing it. Change what's genuinely weak; keep what already works. If there is no existing interface (greenfield), say so and set a deliberate direction from scratch instead.

## Phase 3 — Establish a coherent system, then apply it

Define the system as tokens and conventions before you place components, so the result is consistent rather than assembled ad hoc. Decide deliberately on:

**Foundations** — typography (a real scale with intentional weights and tracking, not random sizes), a spacing scale on a consistent rhythm, a restrained color system (a small neutral ramp, one or two purposeful accents, and semantic colors for success / warning / danger), border treatment, radius, elevation, and motion.

**Components** — forms, buttons, navigation, tables, charts, notifications, and empty states, each following the foundations above.

Encode foundations as variables/tokens in whatever the stack uses (CSS custom properties, a theme file, design tokens). This is what makes a system a system.

### Craft defaults (use unless the product calls for otherwise)

These push output toward "premium" and away from "generic." They are starting points, not a cage — deviate with intent.

- **Type**: one type scale with clear steps; body around 14–16px; headings by weight and size, not color; slight negative tracking on large text; small uppercase labels get positive tracking; use `tabular-nums` for money, counts, and anything in a column.
- **Color**: mostly neutrals and whitespace. One brand/primary accent, used sparingly and mostly for the primary action. Reserve red strictly for destructive/error. Let the palette reflect the product — e.g. a financial product can carry a more restrained, trustworthy tone. Avoid multi-stop gradients as decoration.
- **Space**: base unit of 4px, generous and consistent. Intentional whitespace is a feature; cramped or randomly-spaced UI reads as cheap.
- **Depth**: prefer hairline borders and one or two subtle shadows over heavy glows. No glassmorphism unless it genuinely serves the product.
- **Radius**: consistent and modest. Don't make everything a pill.
- **Motion**: short (roughly 120–220ms), eased, and purposeful — it should explain a change (something appeared, moved, expanded), never decorate. Always honor `prefers-reduced-motion`.
- **Icons**: one consistent set, consistent weight and size. Icons support labels; they rarely replace them.

## Design requirements

Hold the result to these:

- **Clear hierarchy** — the eye should land on the most important thing first, then flow logically.
- **One obvious primary action** per screen. Everything else is visibly secondary or tertiary.
- **Strong typography and intentional whitespace** doing most of the work.
- **Real product terminology** — the actual nouns and verbs of the domain, not "Item," "Data," "Submit."
- **Minimal clutter** — remove anything that isn't earning its place.
- Prefer the clearest layout for the content. If a list, table, or description layout communicates better than a wall of identical cards, use it. **Don't reach for repeated cards by default.**

### Anti-patterns — do not ship these

They are the tells of generic, template, or "AI-generated" UI:

- Glassmorphism as a default aesthetic.
- Gradients as decoration; glowing borders/cards.
- Animations that don't explain anything.
- Filler metrics and vanity stat tiles that no one uses to make a decision.
- Repetitive card grids where another layout is clearer.
- Placeholder/lorem terminology standing in for real domain language.

## Non-negotiables: accessibility and states

These are part of "done," not polish to add if there's time.

**Accessibility**
- Full keyboard operability; logical focus order.
- **Visible focus states** on every interactive element (never remove focus outlines without a clearly visible replacement).
- Adequate color contrast for text and meaningful UI (target WCAG AA).
- Respect `prefers-reduced-motion`.
- Touch targets large enough to hit comfortably (~44px).
- Useful, specific form validation and error messages — say what's wrong and how to fix it, near the field, not just a generic red line.
- **Guard destructive actions** — irreversible or costly actions get a confirmation that names the consequence, with the destructive control clearly distinguished. Don't make "delete" a one-tap accident.

**States** — implement all four for the screen, not just the happy path:
- **Loading** — skeletons or clear progress that preserve layout; avoid content jumps.
- **Empty** — explain what goes here and offer the action to fill it; never a blank void.
- **Success** — confirm what happened.
- **Failure** — say what went wrong and what to do next; keep the user's input.

## Phase 4 — Implement in the existing stack

Build in the project's real stack and component system. Reuse and extend existing shared components instead of forking one-off styles; if a component needs to change, change it centrally so the whole product benefits. Match the codebase's conventions (framework, styling approach, file structure). If you create or modify shared components/tokens, track them for the report.

## Phase 5 — Verify in a running browser

Open the running interface in a browser and check it at representative **desktop, tablet, and mobile** widths. Confirm hierarchy holds, the primary action stays obvious, nothing overflows or collapses awkwardly, focus is visible when tabbing, and the implemented states actually render. Fix what the real render exposes.

If no running browser or display is available in the environment, do the closest verification you can (e.g. render the component in isolation), and **state plainly in the report what could not be browser-verified** rather than implying it was.

## Phase 6 — Report at completion

Close with a concise explanation covering exactly these points:

- **Design direction** — the concept and why it fits this product and user.
- **Hierarchy decisions** — what leads, what follows, and why.
- **Shared components created or changed.**
- **Accessibility improvements.**
- **Responsive behavior** — how it adapts across the target widths.
- **States implemented** — loading, empty, success, failure.
- **Browser verification performed** — what you checked and at which widths (and anything that couldn't be verified).
- **Remaining design limitations** — honest open items, assumptions made, and what you'd do next.
