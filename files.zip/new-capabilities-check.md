# New-capabilities check — applied to InternalHelp

Two of the added features, exercised against the same demo app, to confirm they produce sensible output.

## (a) Quick pass + audit-only — what "quick security look, don't change anything" would return

*Triage only — not an exhaustive review. Worst-first.*

1. **[Critical] Anyone reads any tenant's data.** `/documents/<id>` has no ownership/tenant check and `/chat` trusts a client-supplied `tenant_id`. **[verified live]** an unauthenticated request and a cross-tenant user both read Acme payroll (SSNs); an Acme user read Globex's confidential docs.
2. **[Critical] `/debug/config` leaks all secrets.** Unauthenticated endpoint returns the full environment. **[verified live]** planted DB password and Stripe key came back in cleartext.
3. **[Critical] SQL injection through a model-supplied tool argument.** `search_customers` string-builds SQL from `name`. **[verified live]** `zzz' OR '1'='1` bypassed the filter.

Also Critical/High and worth flagging before any deep pass: a hardcoded provider key in `agent.py`, and an injection→email exfiltration chain (uploaded-doc instructions → ungated `send_email`). A deep pass would still need the full control walk (authz on every route/tool, logging/PII, rate limits, file handling, deps) and the complete attack battery. **No code was changed** (audit-only).

## (b) Compliance framing — OWASP LLM Top 10 (2025) coverage view

| ID | Risk | Status | Evidence |
|----|------|--------|----------|
| LLM01 | Prompt Injection | **Gap** | F5 — untrusted doc content spliced into the system prompt; model can act |
| LLM02 | Sensitive Information Disclosure | **Gap** | F1, F2, F3, F8, F9 — cross-tenant reads, secret dump, hardcoded key, PII in logs |
| LLM03 | Supply Chain | **Gap** | F12 — outdated, unscanned Flask pin |
| LLM04 | Data and Model Poisoning | **Gap** | F10 — unauthenticated, unvalidated upload can poison the retrieval corpus |
| LLM05 | Improper Output Handling | **Gap** | F4, F7 — model output into string-built SQL; tool args unvalidated |
| LLM06 | Excessive Agency | **Gap** | F6, F7 — ungated `send_email`, no per-tool authz, model-controlled recipient |
| LLM07 | System Prompt Leakage | **N/A** | the system prompt holds no secrets/authz logic; its real leak path is the logs → counted under LLM02 |
| LLM08 | Vector and Embedding Weaknesses | **Gap** | F2 — retrieval crosses tenants (filter is client-controlled, not session-derived) |
| LLM09 | Misinformation | **Gap (minor)** | no source citations or uncertainty/decline behavior; low priority for an internal tool |
| LLM10 | Unbounded Consumption | **Gap** | F11, F10 — no rate limits/quotas; no upload size cap |

Every ID is accounted for, with the one N/A reasoned rather than left silent — which is the point of the coverage view.
