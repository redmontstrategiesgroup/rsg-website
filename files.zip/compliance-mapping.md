# Compliance mapping reference

Use this when the user wants findings framed against a recognized standard. Two are covered: the **OWASP Top 10 for LLM Applications (2025)** — the AI-specific risk vocabulary — and the **OWASP ASVS 5.0** — the web-application-layer verification standard that the LLM list sits on top of. Tags are approximate: one finding can touch several IDs, and a clean review isn't "one tag per finding" but "every serious risk traceable to something." Include tags only when the user asks for compliance framing; otherwise keep findings uncluttered.

## Contents
- OWASP LLM Top 10 (2025) — the list and what maps to each
- Reverse index — finding type → LLM ID
- OWASP ASVS 5.0 — domain mapping
- Producing a coverage view
- Other frames (pointers)

## OWASP LLM Top 10 (2025)
Published by the OWASP GenAI Security Project (Nov 2024). This skill's phases already cover all ten even though they aren't organized by it — the mapping below is mostly a relabeling.

- **LLM01 Prompt Injection** — untrusted content steering the model. Maps to SKILL §6 (separation of instructions/content, architecture-level resistance) and injection-via-upload/retrieval tests.
- **LLM02 Sensitive Information Disclosure** — PII/secrets surfaced by the app. Maps to §9 (redaction, permission-aware output), §3 (secret exposure paths), cross-tenant reads, and PII-in-logs.
- **LLM03 Supply Chain** — compromised deps, models, or integrations. Maps to §12 (dependency risk) and provenance of models/third-party services.
- **LLM04 Data and Model Poisoning** — malicious data entering the corpus/training. Maps to upload validation (§5) and retrieval-corpus integrity (poisoning the RAG store via uploads).
- **LLM05 Improper Output Handling** — trusting model output downstream. Maps to §4 (output validation) and tool-arg validation (§7) — model output into SQL/shell/path/tools.
- **LLM06 Excessive Agency** — the model can do too much, too easily. Maps to §7 (tool allowlist, per-tool authz, destination allowlist, confirmation scaled to risk) and the whole risk-tier ladder.
- **LLM07 System Prompt Leakage** — the system prompt leaks, or holds things it shouldn't. Maps to the "reveal hidden instructions" test and the rule that nothing sensitive (secrets, authz logic) lives in the prompt.
- **LLM08 Vector and Embedding Weaknesses** — retrieval crossing trust or leaking. Maps to §2 (per-tenant/owner filtering on vector stores), permission-aware retrieval (§6/§9), and deletion of derived embeddings (§9 retention).
- **LLM09 Misinformation** — confident wrong output users act on. Maps to §9 (citations + safe uncertainty/decline behavior); weight it for assistants that inform decisions.
- **LLM10 Unbounded Consumption** — cost/DoS from uncontrolled use. Maps to §8 (rate limits, quotas) and idempotency/replay handling (§7).

Weighting by architecture: chat-only → emphasize LLM01, LLM02, LLM09; RAG → add LLM08; tool-calling agents → weight LLM06, LLM03, LLM10.

## Reverse index — finding type → LLM ID
- Cross-tenant read / broken object authz surfacing data → LLM02 (+ LLM08 if via retrieval)
- Client-controlled tenant → LLM02 / LLM08
- Injection via uploaded/retrieved content → LLM01 (+ LLM04 if it poisons the store)
- Model output into SQL/shell/path → LLM05
- Ungated/underscoped tool or outbound action → LLM06
- Missing destination allowlist / exfil path → LLM06 (+ LLM02)
- Secret in prompt / prompt disclosure → LLM07
- Secret in source/logs/error/endpoint → LLM02
- No rate limits / quotas / idempotency → LLM10
- Outdated/unscanned deps → LLM03
- No citations / fabrication → LLM09

## OWASP ASVS 5.0 (May 2025) — domain mapping
ASVS is the testable web-app standard beneath the LLM concerns; map to its **named domains** (5.0 renumbered chapters, and requirement IDs are best quoted directly from asvs.dev when precision is needed). This skill's categories correspond to:

- Identity & access (authN) → **Authentication**, **Session Management**, **Self-contained Tokens**, **OAuth/OIDC**
- Server-side / object / role authorization → **Authorization** (access control)
- Input validation, injection sinks, output handling → **Encoding and Sanitization** (incl. injection prevention) and **Validation**
- File upload/handling → **File Handling**
- Secrets & cryptography, encryption in transit/at rest → **Cryptography**, **Secure Communication**
- Audit & log hygiene → **Security Logging and Error Handling**
- Redaction, retention, deletion → **Data Protection**
- Rate limiting / anti-automation → **Validation / Business Logic** (anti-automation)
- Secure configuration, debug endpoints → **Configuration**

## Producing a coverage view
When compliance framing is requested, add a short table after the findings: each LLM Top 10 ID, and whether the review found it **Covered** (control present/adequate), **Gap** (finding raised — link the finding ID), or **N/A** (not reachable in this architecture, with one-line why). This turns a findings list into an auditable baseline and makes the "N/A" reasoning explicit rather than silent.

## Other frames (pointers)
If the user works under a broader program, point them at these rather than reproducing them: **MITRE ATLAS** (adversarial-ML tactics/techniques, good for red-team TTP language), **NIST AI RMF** and **ISO/IEC 42001** (AI governance/management-system framing). These complement — they don't replace — the LLM Top 10 + ASVS pairing above.
