# Stack-specific recon guide

The controls in `references/controls-checklist.md` are stack-agnostic; this file says *where each one tends to live* in common stacks, so recon is fast and nothing idiomatic gets missed. Read only the section(s) matching what you found in the repo. Each entry lists where auth/authz, routes, secrets, and the model/tool surface usually sit, plus the framework's characteristic footguns.

## Contents
- Node / Express
- Next.js
- Python / FastAPI
- Python / Flask
- Python / Django (+ DRF)
- Ruby on Rails
- LLM orchestration (LangChain / LlamaIndex)
- Vector stores
- Model-provider SDKs
- Serverless / edge

## Node / Express
Routes in `app.get/post(...)` or `Router()` files; auth/authz as middleware. **Footguns:** middleware **order** — a route registered before the auth middleware is unprotected; per-route `authMiddleware` that checks a session but no per-object ownership (IDOR); `req.body`/`req.query` trusted for identity or tenant. Secrets in `process.env` (check for a committed `.env`). Look for `child_process.exec`, string-built SQL, and `res.json(dbRow)` returning unfiltered records.

## Next.js
Endpoints hide in several places: **API routes** (`pages/api/*`, `app/api/*/route.ts`), **Server Actions** (`"use server"` functions — these are *callable POST endpoints*, not just internal functions, so they need the same authz as routes), **middleware** (`middleware.ts` — often does auth but runs at the edge and can be misconfigured to skip paths), and **route handlers/RSC** fetching data. **Footguns:** assuming Server Actions are safe because they're imported by a component (a caller can invoke them directly with arbitrary args); `NEXT_PUBLIC_*` env vars are shipped to the browser — a secret named that way is exposed; trusting client-passed IDs in an action. Model calls and tool defs usually live in `app/api/**` or a `lib/ai/*`.

## Python / FastAPI
Routes via `@app.get/post` and `APIRouter`; auth/authz via `Depends(...)`. **Footguns:** an endpoint missing its `Depends(get_current_user)` is open; a dependency that authenticates but doesn't authorize the specific object; Pydantic validates shape but not authority (a valid `tenant_id` in the body is still attacker-chosen). Secrets in env / `pydantic-settings`. Look for f-string SQL vs. parameterized queries, and background tasks running with elevated rights.

## Python / Flask
Routes via `@app.route`; auth is often hand-rolled (decorators like `@login_required`, or nothing). **Footguns:** decorator applied inconsistently across routes; `request.get_json()` / `request.form` trusted for tenant/identity; raw string SQL; a `/debug` or `/admin` blueprint left unauthenticated; full request/response logged. Secrets in env or, too often, a module constant.

## Python / Django (+ DRF)
URLconf → views/viewsets; auth via Django auth, authz via permissions. **Footguns (DRF specifically):** `permission_classes` enforce view-level access but **object-level** permissions require `has_object_permission` (+ `check_object_permissions`) — easy to omit, giving IDOR; a `get_queryset` not filtered by `request.user`/tenant leaks rows; `AllowAny` left on a viewset. Django ORM parameterizes by default, but `.raw()` / `.extra()` / f-strings reintroduce SQLi. Secrets in `settings.py` (check `SECRET_KEY`, `DEBUG=True` in prod, and committed settings).

## Ruby on Rails
`config/routes.rb` → controllers; authz via Pundit/CanCanCan or `before_action`. **Footguns:** `before_action :authenticate` present but no policy check scoping the record to the user (IDOR); mass assignment when strong params are loose (`params.permit!`); `Model.find(params[:id])` without an ownership scope; SQL via string interpolation in `where("... #{x}")`. Secrets in Rails credentials / env; check `config/master.key` isn't committed.

## LLM orchestration (LangChain / LlamaIndex)
This is where **agency** risk concentrates. Find the **tool/function definitions** (LangChain `Tool`/`@tool`, function-calling schemas; LlamaIndex `FunctionTool`/query engines) and the **agent executor** that dispatches them. **Footguns:** tools that wrap a DB/HTTP/shell call with no per-call authorization and take model-supplied args verbatim (parameter tampering); a retriever with no metadata filter for tenant/owner (cross-tenant retrieval, LLM08); prompt templates that concatenate retrieved `Document` content into the system message with no separation (LLM01); "agent can use any tool" configurations with no allowlist; callbacks/logging that dump full prompts. Trace the path from the agent's chosen action to the real side effect and ask what re-authorizes it.

## Vector stores
pgvector, Pinecone, Weaviate, Qdrant, Milvus, FAISS, etc. **What to check:** does every query carry a **tenant/owner metadata filter applied server-side before results reach the model** (or are namespaces/collections per-tenant)? Is that filter derived from the session, not the request? On document delete, are the **embeddings** deleted too (retention/right-to-erasure)? A shared index with no filter is a cross-tenant retrieval finding (LLM08). FAISS/in-memory stores often have *no* metadata filtering at all — check hard.

## Model-provider SDKs
OpenAI / Anthropic / Bedrock / Azure OpenAI / Vertex clients. **Where:** grep for the SDK import and client init to find (a) where the **API key** comes from — env/secret-manager (good) vs. hardcoded/`NEXT_PUBLIC_` (finding); (b) **prompt assembly** — is untrusted content concatenated into the system role, or kept in a separate user/data section; (c) whether **model output** is parsed/validated before use. Note what data is sent to the provider (is sensitive data leaving the boundary intentionally?).

## Serverless / edge (Vercel / Lambda / Cloudflare Workers)
Handlers per function; secrets via platform env/bindings. **Footguns:** auth expected "at the gateway" but a function is directly invocable; secrets in client-exposed vars; long-lived function URLs without auth; edge middleware that skips matched paths. Confirm each function independently authenticates and authorizes rather than trusting an upstream that may be bypassable.
