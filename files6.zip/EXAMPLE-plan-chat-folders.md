# Implementation Plan: Chat Folders in ai-chatbot

> Produced end-to-end by the `planning-complex-features` skill against a real clone of
> `vercel/ai-chatbot`. Every reference below is to a file that actually exists in the repo.

## Desired outcome
A signed-in user can create named folders in the left sidebar, move chats into them, and
rename/delete folders. The chat history groups chats under their folder (collapsible), with
ungrouped chats still listed as today. Folder membership is private to the owner.

## Current system
- **Framework:** Next.js App Router with route groups `app/(chat)` and `app/(auth)`; React
  server/client components; SWR for client data-fetching.
- **Data (Drizzle + Postgres, `lib/db/schema.ts`):** `chat` (table `"Chat"`) has `id`, `title`,
  `userId → user.id` (notNull), `visibility` (`public|private`, default `private`), `createdAt` —
  chats are already per-user. `message` (`"Message_v2"`), `vote`, `document`, `suggestion`, `stream`
  also exist. There is **no folder concept**.
- **DB access layer (`lib/db/queries.ts`):** all persistence goes through exported functions —
  `getChatsByUserId({ id, limit, ... })` (paginated), `saveChat`, `deleteChatById`,
  `updateChatVisibilityById`, `updateChatTitleById`, etc. This is the single place to add folder
  queries.
- **Auth (`app/(auth)/auth.ts`, Auth.js v5):** server code calls `auth()`; `session.user` carries
  `id` and `type: "guest" | "regular"`. Guest (anonymous) users are supported.
- **API convention:** handlers live at `app/(chat)/api/*/route.ts`, obtain the session via `auth()`,
  validate input, call the query layer, and surface errors with the shared convention used by sibling
  routes (see `app/(chat)/api/history/route.ts`, which is paginated).
- **Sidebar UI (`components/chat/`):** `app-sidebar.tsx` composes the sidebar; `sidebar-history.tsx`
  + `sidebar-history-item.tsx` render the chat list; primitives in `components/ui/sidebar.tsx`.
  History is fetched with SWR.
- **Migrations:** Drizzle; `package.json` has `db:generate`, `db:migrate`, `db:push`; migrations in
  `lib/db/migrations`.

## Gaps
- No `folder` table and no `chat.folderId` — chats are a flat per-user list.
- `getChatsByUserId` returns chats with no grouping; the sidebar renders a single flat list.
- No API surface for folder CRUD or for moving a chat into a folder.
- No UI affordance to create/rename/delete a folder or assign a chat to one.

## Proposed architecture
- **Frontend:** extend `components/chat/app-sidebar.tsx` and `sidebar-history.tsx` to render folders
  as collapsible `SidebarGroup`s (from `components/ui/sidebar.tsx`) with their chats nested, and
  ungrouped chats below. Add a "New folder" control, a per-folder overflow menu (rename/delete), and
  a "Move to folder" action on `sidebar-history-item.tsx` (menu-based first; drag-and-drop later).
  Fetch folders via SWR; call `mutate` after changes.
- **Backend:** new route handlers matching the sibling-route pattern (`auth()` → validate → query
  layer → shared error handling):
  - `app/(chat)/api/folders/route.ts` — `GET` (list caller's folders), `POST` (create `{ name }`).
  - `app/(chat)/api/folders/[id]/route.ts` — `PATCH` (rename), `DELETE`.
  - `PATCH app/(chat)/api/chat/[id]/route.ts` (new) — set/clear `folderId` on a chat the caller owns.
- **Database (additive, one migration):**
  - new `folder` table `"Folder"`: `id` uuid pk, `userId` uuid → `user.id` (notNull),
    `name` varchar(64) (notNull), `createdAt`/`updatedAt` timestamps, optional `position` integer.
  - add `folderId` uuid **nullable** to `chat`, `references(() => folder.id, { onDelete: "set null" })`.
    Nullable + set-null keeps existing rows valid and makes rollback safe.
- **Query layer (`lib/db/queries.ts`):** add `createFolder`, `getFoldersByUserId`, `renameFolder`,
  `deleteFolder`, and `moveChatToFolder({ chatId, folderId, userId })`. Extend `getChatsByUserId`
  (or add a companion) to include `folderId` so the sidebar can group; keep pagination.
- **Background jobs:** none required.
- **Authentication & authorization:** every folder query is scoped by `session.user.id`; mutations
  verify the folder/chat belongs to the caller before writing (else 403/404) — enforced server-side
  in the handlers, never in the client. Design choice: allow any authenticated session (guests
  included, mirroring chats); optionally restrict to `type === "regular"` if guest folders aren't
  wanted.
- **External integrations:** none.
- **Logging & analytics:** log folder create/rename/delete/move following existing logging; if
  product analytics are added later, emit `folder_created` / `chat_moved`.
- **Error handling:** reuse the sibling routes' error convention (e.g. `ChatSDKError`) for bad input,
  unauthorized, and not-found; the sidebar shows a toast on failure and reverts the optimistic update.
- **Trust boundaries:** the API handlers are the boundary — client-supplied `folderId`/`chatId` are
  never trusted without an ownership check against `session.user.id`.
- **Data ownership:** a folder belongs to exactly one user; only the owner may read, rename, delete,
  or place chats in it.

## User flows
**Primary:** user clicks "New folder" → names it → folder appears → opens a chat's menu →
"Move to folder" → picks a folder → the chat re-nests under it → expanding/collapsing the folder
shows/hides its chats.
**Alternative / failure:** empty rename is rejected (422); deleting a folder returns its chats to
ungrouped (FK set-null) rather than deleting them; moving a chat you don't own, or into a folder you
don't own, returns 403/404 and the UI reverts; an unauthenticated request returns 401.

## Implementation phases
### Phase 1 — Schema + folder CRUD API (behind `foldersEnabled` flag)
- Changes: add `folder` table and nullable `chat.folderId` in `lib/db/schema.ts`; `db:generate`
  migration; add `createFolder`/`getFoldersByUserId`/`renameFolder`/`deleteFolder` to `queries.ts`;
  add `app/(chat)/api/folders/route.ts` and `.../[id]/route.ts` with `auth()` + Zod validation +
  ownership checks.
- Testable result: integration tests — owner creates/lists/renames/deletes folders; another user
  gets 403/404 on the owner's folder; unauthenticated → 401.
### Phase 2 — Move a chat into a folder
- Changes: `moveChatToFolder` query; `PATCH app/(chat)/api/chat/[id]/route.ts` setting/clearing
  `folderId` with an ownership check; extend `getChatsByUserId` to return `folderId`.
- Testable result: integration test — owner moves their chat into their folder (persists); non-owned
  chat/folder → 403; the chat list now carries `folderId`.
### Phase 3 — Sidebar grouping UI (parallelizable with Phase 2 once the API shape is fixed)
- Changes: fetch folders via SWR; render collapsible folder groups + nested chats in
  `app-sidebar.tsx`/`sidebar-history.tsx`; add create/rename/delete controls and the "Move to folder"
  menu on `sidebar-history-item.tsx`; optimistic updates + `mutate`.
- Testable result: Playwright — create a folder, move a chat in, reload, folder + membership persist;
  deleting a folder returns its chats to ungrouped.
### Phase 4 — Polish + enable
- Changes: folder ordering (`position`), empty-folder state, optional drag-and-drop; flip
  `foldersEnabled` on.
- Testable result: manual click-through of the primary + failure flows in a preview deploy.

## Acceptance criteria
### Phase 1
- [ ] `POST /api/folders` with a valid name → 201 + `Folder` row owned by the caller; empty name → 422.
- [ ] `GET /api/folders` returns only the caller's folders; `PATCH`/`DELETE` on another user's folder
      → 403/404; unauthenticated → 401.
- [ ] Migration adds `Folder` and nullable `Chat.folderId`; existing chats remain valid (`folderId` null).
### Phase 2
- [ ] `PATCH` chat move sets `folderId` for an owned chat; non-owned chat or folder → 403/404.
- [ ] `getChatsByUserId` includes `folderId`; pagination still works.
### Phase 3
- [ ] Sidebar shows folders as collapsible groups with nested chats; ungrouped chats still listed.
- [ ] Moving a chat updates the UI optimistically and persists across reload; failure reverts + toast.
### Phase 4
- [ ] With the flag on, create → move → rename → delete works end-to-end in preview.

## Testing plan
- **Unit:** Zod schemas; folder-name validation; `moveChatToFolder` ownership logic.
- **Integration:** all folder endpoints and the chat-move endpoint against a test Postgres, covering
  every status transition and the FK set-null on folder delete.
- **End-to-end (Playwright, matching existing `tests/`):** create folder → move chat → reload →
  persisted; delete folder → chats return to ungrouped.
- **Security:** `folderId`/`chatId` validated as UUIDs and always checked against `session.user.id`;
  no cross-user folder/chat enumeration.
- **Authorization:** owner vs. other-user vs. unauthenticated × {list, create, rename, delete, move};
  plus the guest-vs-regular decision.
- **Failure-state:** empty/duplicate name; moving into a deleted folder (rejected); DB error surfaces
  the shared error shape and the UI reverts.
- **Manual browser testing:** click-through of the primary flow and the non-owner, empty-name, and
  delete-folder cases in a preview deploy.

## Deployment plan
- **Migrations:** one additive Drizzle migration (`db:generate` → `db:migrate`); new table + nullable
  column, safe to run before the code deploy.
- **Environment variables:** none new.
- **Feature flag:** `foldersEnabled` gates the UI and the new endpoints until Phase 4.
- **Monitoring:** count folder create/rename/delete/move; watch for elevated 403/404 (ownership-check
  regressions) and migration errors.
- **Rollback:** flag off hides the UI and disables the endpoints instantly; the additive schema can
  remain unused, so no down-migration is required.
- **Compatibility:** nullable `folderId` + `on delete set null` means old and new code coexist during
  the deploy window.

## Risks
- **Security:** trusting a client `folderId`/`chatId` without an ownership check would leak or move
  others' chats → validate UUIDs and scope every query by `session.user.id`.
- **Data integrity:** deleting a folder must not delete its chats → FK `on delete set null` (chats
  fall back to ungrouped).
- **Performance:** grouping shouldn't add N extra queries → return `folderId` from the existing
  paginated `getChatsByUserId` and group client-side, or one folder query + one chat query.
- **Accessibility:** collapsible groups and menus need keyboard operability and labels; drag-and-drop
  (if added) needs a keyboard/menu fallback.
- **Integration:** the sidebar's SWR cache must be invalidated (`mutate`) after folder/move changes or
  the list goes stale.
- **Migration:** none destructive; additive only.
