---
name: demo-to-production-conversion
description: >-
  Convert a demo, prototype, or pilot build into a real system serving paying customers — replacing mock data and fake integrations, removing hard-coded client details, adding authentication and per-tenant data ownership, and supplying the operational layer a demo never needed: billing, support tooling, monitoring, backups, and deployment configuration. Use when a proof of concept is being turned into a live product, when a pilot is going to a second customer, or when someone asks "what's missing before this is real", "can we sell this", "how do I make this multi-customer", or "this works for the demo, now what". Trigger whenever a system built to impress one audience is about to carry real money, real data, or a second client. For the tenancy, roles, and data-isolation design specifically, use multi-tenant-client-portal.
---

# Demo to Production Conversion

## What a demo optimizes for, and why that is the problem

A demo is built to make **one path** look effortless to **one audience** on **one occasion**. Every
shortcut that serves that goal is a defect in production: fixed data so nothing looks empty, a single
hard-coded client so nothing needs configuring, no authentication so nothing interrupts the flow, no
error handling because the demo path does not fail.

**The conversion is not a polish pass.** It is the addition of everything the demo deliberately left
out — most of which is not visible in the interface at all. Expect the operational layer (tenancy,
billing, support, monitoring, backups) to be a larger body of work than the feature itself, and plan
accordingly rather than discovering it after committing a date.

This differs from `preventing-fake-implementations`, which *detects* whether things are real. Here you
already know the demo is a demo; the job is the conversion, and the emphasis is on the
multi-customer and operational dimensions a single-tenant demo never had.

## Workflow

**Step 1 — Inventory the shortcuts.** Go through the categories in
`references/conversion-inventory.md` and build a complete list before changing anything. The inventory
is the deliverable that lets someone scope the work honestly; converting ad hoc guarantees the
operational gaps are found last, under time pressure.

**Step 2 — Decide the tenancy model first.** Everything else depends on it. Will this serve multiple
customer organizations? If yes, tenancy is a data-model decision that must be made before any further
schema work, because retrofitting a tenant identifier into an existing schema and every existing query
is dramatically more expensive than starting with it. See `multi-tenant-client-portal`.

**Step 3 — Replace the fakes**, in dependency order: real persistence, then authentication, then
per-object authorization, then real integrations. Each is a prerequisite for the next being meaningful
— authorization without authentication is nothing, and integrations without persistence have nowhere
to write.

**Step 4 — Remove the hard-coding.** Client names, logos, colors, domains, sample records, seeded
users, magic identifiers. Configuration becomes per-tenant data, never a branch in the code.

**Step 5 — Add the operational layer.** Billing and plan enforcement, support access, monitoring and
alerting, backups with a verified restore, deployment configuration for each environment, and audit
logging. None of this is visible in the product, and all of it is required to operate one.

**Step 6 — Handle the demo data.** Decide deliberately whether existing demo records are deleted,
migrated, or retained as a sandbox — and make sure demo data can never appear in a real customer's
account. Seed scripts that run in production are a recurring source of exactly that.

**Step 7 — Verify as a customer, not as the builder.** Sign up as a new tenant from scratch, with no
pre-seeded state, and complete the core flow. Then do it as a *second* tenant and confirm neither can
see the other. This is the test that finds what the demo hid.

## The four gaps that define a demo

Check these specifically, first:

**1. Single tenancy assumed.** Data with no owner, queries with no scope, one implicit customer. The
most expensive gap to close later.

**2. No real authentication or authorization.** A login screen that accepts anything, or authorization
enforced only by hiding controls in the interface.

**3. Integrations that never called anything.** Fixed responses standing in for the external service.
Real integrations bring credential storage, token refresh, rate limits, and failure handling — all
absent from the stub.

**4. No operational surface.** No monitoring, so failures are discovered by customers; no backups, so a
mistake is permanent; no support tooling, so investigating a customer problem means querying the
database by hand.

## Guardrails

- **Never launch with demo data reachable in a real account.**
- **Never defer the tenancy decision.** It gets more expensive every day.
- **Never treat "it worked in the demo" as evidence of anything.** The demo ran one path, once, with
  favorable data.
- **Never keep a client-specific branch in code.** Configuration is data.
- **Never go live without a verified restore.** An untested backup is a belief.
- **Never rely on the builder's account for testing.** It has state, permissions, and habits a real
  customer will not have.
- **Do not convert quietly.** The inventory, with effort estimates, should be visible to whoever is
  committing to a launch date — the most common failure here is a demo being sold as nearly finished
  when the operational layer has not been started.
