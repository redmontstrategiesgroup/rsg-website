---
name: integration-connector-builder
description: >-
  Build third-party integrations to a consistent standard — OAuth and API key flows, encrypted credential storage, token refresh, connection testing, webhooks versus polling, pagination, rate limit handling, retries, field mapping, revocation, and audit logging. Use whenever someone is connecting an external service, adding a connector or integration to a platform, implementing OAuth, storing third-party credentials, syncing data with an external API, or asks "how do I handle token refresh", "how should I store this API key", "should I poll or use webhooks", "what happens when the user revokes access", or "why does the sync keep hitting rate limits". Trigger on any integration holding a credential on the user's behalf, since credential storage and revocation are where these go wrong in ways users feel. For what the integration is allowed to store, for how long, and who counts as a subprocessor, use privacy-and-data-retention.
---

# Integration Connector Builder

## The shape of the problem

A connector holds a credential that grants access to someone's data in another system. That single
fact drives everything: the credential must be stored so a database leak does not expose it, refreshed
without user involvement, revoked promptly when access ends, and never used for anything the user did
not authorize.

The second fact: **the external service will be slow, rate-limited, briefly broken, and occasionally
breaking-changed without notice.** A connector that assumes availability will fail loudly and often.

Build every connector to the same internal interface — connect, test, sync, disconnect — so the
tenth one is not a fresh invention and so failures look the same everywhere.

## Credentials

- **Encrypt at rest with a key that is not in the database.** A dump of the credentials table must not
  be usable. Use envelope encryption with a key from a secrets manager or KMS.
- **Never log a credential, token, or refresh token** — not at debug level, not in an error report, not
  in a request trace. Redact structurally at the logger, not by remembering.
- **Scope minimally.** Request the narrowest permissions the feature needs. Broad scopes are easy to
  ask for during setup and impossible to justify after a breach.
- **Store per-connection, not per-application**, and isolate by tenant so one customer's connection is
  unreachable from another's context.
- **Support revocation from both directions** — the user disconnecting in your product, and the user
  revoking in the provider's. Handle the second by treating persistent auth failures as revocation and
  surfacing it, rather than retrying forever.

## OAuth mechanics that matter

- **Use the state parameter** and verify it, or you have a CSRF hole in the connect flow.
- **Use PKCE** wherever the provider supports it.
- **Store the refresh token as carefully as the access token** — it is the longer-lived secret.
- **Refresh proactively**, before expiry, not reactively on a 401. Reactive refresh means every
  expiry produces a user-visible failure first.
- **Serialize refreshes per connection.** Concurrent refreshes race, and many providers invalidate the
  old refresh token when a new one is issued — so the loser of the race permanently loses the
  connection.
- **Handle refresh failure as disconnection**, not as a retryable error. Tell the user their connection
  needs re-authorizing; do not silently keep failing.

## Sync strategy

**Prefer webhooks; fall back to polling; reconcile periodically regardless.**

Webhooks are timely and cheap but unreliable — they get missed. Polling is reliable but latent and
expensive. Most robust connectors use webhooks for freshness, incremental polling as a safety net, and
a periodic full reconciliation to catch what both missed.

- **Incremental where possible** — request only what changed since a stored cursor, and store the cursor
  durably.
- **Paginate properly**, following the provider's cursor rather than assuming page numbers, and handle
  a page failing mid-sync without restarting from zero.
- **Never fetch everything on every sync** unless the dataset is genuinely small.

## Rate limits and failure

- **Read the provider's limit headers and back off before hitting the limit**, rather than after.
- **On 429, honor `Retry-After`.** Ignoring it is how an integration gets an account suspended.
- **Exponential backoff with jitter** on transient failures; no retries on 4xx other than 429.
- **A circuit breaker per provider** stops a dead dependency from consuming every worker.
- **Distinguish "provider is down" from "this connection is broken."** The first is transient and
  affects everyone; the second needs the user to act. Showing the wrong message wastes support time.

## Connection testing and status

Every connector exposes a **test** that makes a real, cheap, read-only call and reports a specific
result — not a stored flag. Run it at connect time and periodically after.

Surface a status the user can see: connected, needs re-authorization, degraded, syncing, last
successful sync. **"Needs re-authorization" is the one that matters** — it is actionable, and silence
here is why integrations quietly stop working for months.

## Field mapping

- **Keep the provider's raw payload** alongside your normalized version. When the mapping turns out to
  be wrong, you can re-derive without re-fetching.
- **Map explicitly**, never by assuming field names match.
- **Handle absent, null, and empty as distinct** — providers disagree about which they use.
- **Version the mapping**, since providers change payloads without warning.

## Audit

Log every connect, disconnect, token refresh, permission change, and sync run: actor, connection,
provider, action, outcome, timestamp. This is the record that answers "who connected this and what
did it access", and it is needed exactly when nobody remembers.

## Guardrails

- **Never store a credential in plaintext**, including in a development database.
- **Never request broader scopes than the feature needs.**
- **Never retry indefinitely on authentication failure** — surface it as needing re-authorization.
- **Never sync without a cursor** for anything that grows.
- **Never let one failing connection stall the others** — isolate per connection.
- **Never expose provider errors verbatim** to users; they leak internals and mean nothing to the reader.
- **Do not treat a successful connect as proof the integration works.** Run the real test call.

## Tooling

Audit existing connector code for the failure modes above:

```bash
python3 scripts/connector_audit.py <path>              # markdown report
python3 scripts/connector_audit.py <path> --severity high
python3 scripts/connector_audit.py <path> --json --out audit.json
```

Exits 1 when any high-severity candidate is found, so it can gate CI. Every finding is a pointer to
a place a human must look, not a verdict.

## References

- `references/oauth-and-credentials.md` — storage model, the refresh race and how to serialize it,
  refresh-failure classification, connect-flow checklist, revocation from both directions
- `references/sync-and-pagination.md` — choosing webhooks vs polling, cursor durability, the
  timestamp-boundary bug, pagination failure modes, reconciliation, raw payload retention
- `references/rate-limits-and-failure.md` — limit headers, retry classification table, jittered
  backoff, per-provider circuit breaker, per-connection isolation, the two messages users see
