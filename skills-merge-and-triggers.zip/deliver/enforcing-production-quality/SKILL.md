---
name: enforcing-production-quality
description: >-
  Drive a feature from "looks finished" to genuinely production-capable, and refuse to call it ready until real checks have actually been run — closing gaps across persistence, server-side authorization, input validation, error and recovery handling, loading and empty states, duplicate request protection, accessibility, responsive behavior, idempotency, logging, and tests. Use whenever someone wants to harden, finish, productionize, or ship a feature: "make this production ready", "is this actually done", "turn this prototype into something real", "wire this up for real", "harden this before launch", or when auditing whether a feature is real, partial, simulated, or interface-only. Trigger especially when a feature demos well but has never been exercised against failure, another user's data, or a page refresh — those are the three gaps that separate a demo from a product. This covers whether it works; building-premium-interfaces covers whether it looks and feels considered.
---

# Enforcing Production Quality

## What "production ready" has to mean

It is a claim about evidence, not a feeling about completeness. The standard here:

**A feature is production ready when its behavior has been verified end to end, by commands that were
actually run and flows that were actually exercised — including the unauthorized case, the failure
case, and the refresh.**

Anything short of that is a hypothesis. The most common failure in this work is not building the wrong
thing; it is declaring done based on the happy path working once, in development, signed in as
yourself, with the network up.

## The three gaps that define a demo

Nearly every "nearly finished" feature has at least one:

**1. It does not persist.** State lives in component memory or browser storage, so it survives
navigation but not a refresh, and does not exist on another device. This looks completely finished
until someone reloads.

**2. It is not authorized server-side.** The interface hides what the user should not see, and the
server never checks. Anyone who calls the endpoint directly gets everything. This is invisible in
manual testing because you are always signed in as someone who is allowed.

**3. It has never failed.** No handling for a rejected request, a timeout, a validation error, a
duplicate submission, or an empty result — because none of those happened during development.

Start every hardening pass by checking those three specifically.

## Workflow

**Step 1 — Inspect before changing.** Read the feature's full path: interface, client state, endpoint,
authorization, service logic, database access, schema. Understand what genuinely works before altering
anything, and follow the repository's existing conventions rather than importing new ones.

**Step 2 — Classify the current state honestly.** Each capability is exactly one of: **real**
(verified end to end), **partial** (works for the main case, gaps elsewhere), **awaiting
configuration** (correct but needs credentials or setup), **labeled demo** (fake and clearly marked),
**misleading demo** (fake and presented as real), or **not implemented**. Misleading demo is the
category that matters most — it is the one that damages trust when discovered.

**Step 3 — Close the gaps**, in this order, because each depends on the previous:

- **Persistence** — real database writes, correct transaction boundaries, survives refresh and new
  sessions
- **Authorization** — server-side, per-object, scoped by actor in the query
- **Validation** — schema-validated at the boundary, all errors returned together
- **Failure handling** — every external call has a timeout and a defined behavior on failure
- **Duplicate protection** — idempotency for mutations, disabled controls during submission,
  database-level uniqueness where it matters
- **States** — loading, empty, error, and success each designed rather than defaulted
- **Recovery** — every error state offers a way forward, and no failure loses work
- **Accessibility** — keyboard-complete, labeled, focus managed, target sizes adequate
- **Responsive** — works at the smallest supported width, not only at desktop
- **Observability** — a structured log line with correlation ID; audit events for sensitive actions
- **Tests** — covering the unauthorized case, the invalid input, the duplicate, and the empty state

**Step 4 — Run the real gates.** Type-check, lint, tests, and a production build. Record commands and
exit codes. A gate you did not run is a gate that did not pass.

**Step 5 — Exercise the feature manually.** Start the application and actually perform: create, edit,
reload the page, sign out and back in, invalid input, empty state, a simulated server failure, a
duplicate submission, access as an authorized user, access as an unauthorized user, keyboard-only
operation, and both mobile and desktop widths. Check the browser console, server logs, and network
tab for errors that do not surface in the interface.

**Step 6 — Give an honest verdict.** See below.

## The states people skip

**Loading** — every asynchronous operation shows progress, and controls that trigger mutations disable
while in flight. This is also the cheapest duplicate-submission defense.

**Empty** — a first-run empty state explains what the thing is and how to get started. It is the
highest-leverage screen in most features and usually the least designed.

**Error** — says what went wrong in the user's terms, preserves their input, and offers a next action.
Never a raw error string; never a dead end.

**Partial and interrupted** — a multi-step flow saves progress. Closing the tab should not discard
work.

**Failure of a dependency** — when something downstream is unavailable, the interface says so
specifically rather than hanging or silently doing nothing.

## Guardrails

- **Never fabricate data to make something look finished.** No hardcoded sample values in a production
  path, no simulated delay standing in for a real call, no success message before the operation
  confirms. If a capability is not built, an honest empty state beats a fake full one.
- **Never hard-code success.** A path that cannot fail has not been tested; it has been bypassed.
- **Never rely on the interface for authorization.** Hiding a control is presentation, not security.
- **Never call it done because the checks pass.** Passing gates and a working feature are different
  claims. The manual pass is what connects them.
- **Never claim a check was run that was not run.** If the build could not complete, the tests could
  not connect, or a flow could not be exercised, say exactly that. An honest gap is useful; a false
  claim of verification is the specific failure this skill exists to prevent.
- **Do not expand scope.** Harden the feature in front of you. Note adjacent problems; do not fix them
  in the same pass.

## The verdict

End with a plain statement, one of:

- **Production ready** — every gap closed, every gate run and passing, every listed flow exercised.
- **Ready with noted limitations** — usable, with specific named gaps and their risk.
- **Not ready** — what remains and what it would take.

Support it with: commands run and their results, flows manually exercised, failures found and fixed,
**anything that could not be verified and why**, and remaining risks. The unverifiable list is the
most valuable part of the report, because it is the part nobody else can reconstruct later.
