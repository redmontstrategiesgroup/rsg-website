---
name: privacy-and-data-retention
description: Build a data inventory and retention policy for a system holding personal or sensitive data — data categories, purpose of collection, retention periods, deletion and export workflows, consent, redaction, logging restrictions, third-party sharing, and subprocessors. Use when designing or reviewing what a system stores and for how long, when someone says "how long should we keep this", "we need a deletion flow", "what personal data do we hold", "can users export their data", "do we need a privacy policy", or when a client asks who their data is shared with. Trigger when adding a new data field, integration, or AI feature that sends data to a third party, since that is when the subprocessor list changes and nobody updates it. This designs the policy and inventory; security-and-privacy-review tests a build by attempting the attacks, and sensitive-records-and-exports covers sharing health, legal, or intimate records.
---

# Privacy and Data Retention

Two questions drive everything here: **what do we hold, and why are we still holding it?**

Most systems can't answer either. Data accumulates because deleting it requires a decision and keeping it doesn't. Then a deletion request arrives, or a client asks who their data is shared with, and the work of finding out is much larger than it would have been to track it from the start.

## Scope

This skill covers the policy layer — inventory, retention periods, deletion workflows, subprocessors, and the machinery that enforces them.

For designing the *product features* around sensitive records — sharing, exports, expiring links, access auditing — the `sensitive-records-and-exports` skill covers that ground and the two work together.

## Not legal advice

This produces an engineering artifact: what's stored, why, for how long, and how it's deleted. It is not a compliance opinion. GDPR, HIPAA, CCPA, and sector rules have requirements that turn on facts about the business, and a lawyer decides those.

Say this plainly when a client asks whether they're compliant. Being useful here means building the inventory that makes a legal review cheap, not substituting for one.

## Output

- `docs/data-inventory.md` — the categories, purposes, retention, and locations
- `docs/subprocessors.md` — who else touches the data
- Inline: fields with no stated purpose, data with no retention period, and anything that leaves the system unnoticed

## Workflow

### 1. Find what's actually stored

```bash
python3 scripts/data_inventory.py --root . --report
python3 scripts/data_inventory.py --root . --inventory docs/data-inventory.json
```

Scans schema definitions, migrations, and model files for fields matching personal-data patterns, and cross-references against a declared inventory. Reports personal-data-shaped fields with no inventory entry.

Static analysis finds candidates, not truth. It will miss personal data in a JSON blob, a free-text notes field, or a column named `meta`. Free-text fields are the most common hiding place — a notes column collects anything, including things nobody intended to store.

### 2. Give every category a purpose

For each: what it is, why it's collected, what would break if it weren't, and how long it's needed.

**A field with no articulable purpose should be deleted.** This is the single most effective privacy measure available, and it's free — data you don't hold can't leak, can't be subpoenaed, and doesn't need a deletion workflow.

The common finding is a field collected for a feature that no longer exists.

### 3. Set retention periods

Read `references/retention-periods.md`. The general shape: as long as the purpose requires, plus any legal minimum, and no longer.

Common tensions worth resolving explicitly:

- **Legal minimums against deletion promises.** Financial records often must be kept for years; a user's deletion request can't remove them. The answer is usually anonymization rather than deletion, and the privacy policy must say so.
- **Backups against deletion.** A 30-day deletion promise isn't kept if backups hold the data for a year. `references/deletion-workflows.md` covers reconciling this — the usual approach is documenting backup retention as a stated exception and ensuring restores re-apply pending deletions.
- **Logs against everything.** Logs accumulate personal data nobody planned for and retain it far past the primary record.

### 4. Build deletion that works

A deletion flow needs to handle: the primary record, related records, files and uploads, cached copies, search indexes, analytics, logs, backups, and third-party systems.

The last one is the one that gets missed. If a record was synced to a CRM, an email platform, and an LLM provider's logs, deleting it locally deletes one of five copies.

Distinguish soft delete (recoverable, still stored) from hard delete (gone). Users asking for deletion generally mean the second. Soft-delete-only while telling users their data is deleted is a false statement, and it's one that gets discovered.

### 5. Build export

Users can generally request their data. Design it once rather than fulfilling requests by hand.

Machine-readable, complete, and covering data across every system — not just the primary database.

### 6. Track subprocessors

Every third party touching personal data: hosting, email, analytics, error tracking, payments, and **AI providers**.

The AI one changes most often and gets tracked least. Any workflow sending client data to a model provider has added a subprocessor, and enterprise clients ask about this specifically.

Record: who, what data, what for, where they're located, and what their retention is.

### 7. Restrict logging

Logs are the most common accidental personal-data store. A request logger capturing full bodies stores everything users submit, in a system with weaker access controls and often longer retention than the database.

Redact at the logging layer, not by remembering not to log things.

## For RSG client work

Clients increasingly ask these questions during security review, and being able to answer quickly is a differentiator for a small agency.

Worth having ready: a standing subprocessor list, a statement of what data RSG-built automations process and where it goes, and a clear answer on whether client data reaches an LLM provider and under what terms.

That last question comes up in nearly every enterprise or health-adjacent engagement. Find out before building, not after.
