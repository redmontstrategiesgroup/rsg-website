---
name: webhook-and-event-reliability
description: >-
  Build and harden webhook receivers and event-driven integrations so they survive duplicates, out-of-order delivery, provider retries, and downstream failure — covering signature verification, idempotent handling, ordering, retry and backoff policy, dead-letter queues, event versioning, replay, and monitoring. Use whenever someone is receiving or sending webhooks, consuming an event stream, integrating a payment or messaging provider's callbacks, or asks "why did this run twice", "why did the events arrive out of order", "how do I verify this webhook is real", "what happens when my handler fails", or "how do I replay missed events". Trigger on any inbound callback endpoint, since an unverified or non-idempotent receiver is both a security hole and a data-corruption risk. For queues, cron, and long-running work your own system initiates, use background-job-reliability instead.
---

# Webhook and Event Reliability

## The three assumptions that are always wrong

Event delivery is not a function call, and every reliability bug comes from treating it like one.

**1. "It arrives once."** It does not. Providers retry on timeout, on non-2xx, and sometimes
spuriously. Network duplication happens. **Assume every event arrives at least twice** and design so
that is harmless.

**2. "It arrives in order."** It does not. Retries reorder by definition — an event that failed and
retried arrives after events that came later. Parallel delivery reorders. **Never assume the sequence
you receive matches the sequence that happened.**

**3. "It arrives."** Sometimes it does not. Providers give up after a retry budget, your endpoint may
be down longer than that budget, and a deploy can drop in-flight requests. **You need a way to
reconcile what you missed**, which usually means periodically polling the provider's state rather than
trusting the stream alone.

## Verify before you trust

An unverified webhook endpoint accepts events from anyone who finds the URL. For a payment provider
that means forged payment confirmations.

- **Verify the signature on every request**, using the raw body exactly as received. Parsing and
  re-serializing before verification breaks the signature and is the most common implementation bug.
- **Use a constant-time comparison** for the signature.
- **Check the timestamp** and reject events outside a tolerance window, so a captured request cannot be
  replayed indefinitely.
- **Support two signing secrets simultaneously**, or you cannot rotate the secret without dropping
  events during the cutover.
- **Verify before doing anything else** — before parsing, logging the body, or touching the database.

## Idempotency is the core requirement

Every handler must produce the same result whether it runs once or five times.

- **Use the provider's event ID** as the idempotency key where one exists. Record it before processing
  and check it first.
- **Store the key and the outcome in the same transaction as the work.** If they can commit
  separately, the gap between them is the race you were trying to close.
- **Prefer setting state over incrementing it.** "Mark this order paid" is naturally idempotent;
  "add one to the payment count" is not.
- **A repeat should return success without re-acting.** Returning an error on a duplicate causes the
  provider to retry harder.

## Handling ordering

- **Prefer state-carrying events.** An event that includes the full current state can be applied in any
  order using a version or timestamp comparison — discard anything older than what you have. This
  eliminates the ordering problem rather than managing it.
- **Where order genuinely matters**, sequence per entity rather than globally: buffer out-of-order
  events for that entity until the gap fills, with a timeout that escalates rather than blocking
  forever.
- **Do not serialize all processing to preserve order.** It destroys throughput to solve a problem that
  usually only applies per-entity.

## Respond fast, process asynchronously

**Acknowledge the webhook immediately after verification, then do the work in a background job.**

Providers time out quickly and treat slow responses as failures, triggering retries — so a handler
that does real work inline creates duplicates under exactly the load where you least want them. Verify,
persist the raw event, return 2xx, and process from the queue.

This also gives you replay for free: the stored raw events are the source of truth, so a bug in
processing can be fixed and re-run without asking the provider to resend.

## Retries, dead letters, and monitoring

- **Retry with exponential backoff and jitter.** Synchronized retries after an outage cause a thundering
  herd that extends the outage.
- **Cap the retry budget**, then dead-letter. Infinite retries turn a poison message into an infinite
  loop.
- **Distinguish retryable from permanent.** A timeout is retryable; a validation failure is not, and
  retrying it wastes the budget and delays real work.
- **Alert on any dead-letter arrival.** They accumulate silently for months otherwise.
- **Monitor** received rate, processing lag, failure rate, and dead-letter depth. Lag is the signal that
  detects a stalled consumer — depth alone will not.

## Versioning

Events are a contract with consumers you may not control. Add fields freely; never remove or repurpose
one. Carry an explicit version so consumers can branch, and when a breaking change is unavoidable,
publish both versions during a migration window rather than switching in place.

## Guardrails

- **Never process an unverified event**, including in development. Development handlers become
  production handlers.
- **Never do slow work inside the webhook response.** Verify, store, acknowledge, queue.
- **Never log the raw body of a signed webhook** — it frequently contains personal or payment data.
- **Never treat a missing event as impossible.** Build reconciliation against the provider's state for
  anything financially or legally significant.
- **Never return a non-2xx for a duplicate.** It triggers more retries.
- **Do not trust event contents over your own records** for authorization decisions. An event says what
  happened; it does not establish who may act on it.

## Tooling

```bash
# Static audit of receiver code
python3 scripts/webhook_check.py scan <path>
python3 scripts/webhook_check.py scan <path> --json --out report.json

# Prove a handler is idempotent: snapshot state after 1 delivery and after 2,
# then diff. Any difference is a side effect that double-applies on a retry.
python3 scripts/webhook_check.py replay --after1 one.json --after2 two.json \
        --ignore updated_at last_seen
```

`scan` only inspects files that look like receivers, and exits 1 on any high-severity candidate so it
can gate CI. `replay` is the check that actually matters — the static scan cannot prove idempotency,
only two real runs can.

## References

- `references/signature-verification.md` — the raw-body rule and framework-specific fixes,
  constant-time comparison, timestamp tolerance, two-secret rotation, order of operations
- `references/idempotency-and-ordering.md` — the dedup table and insert-then-work, deriving event ids,
  idempotent-equivalent table, version-guarded writes, out-of-order creates
- `references/retry-and-dlq.md` — transient vs permanent classification, backoff schedule, what a DLQ
  needs, replay safety, reconciliation, and the monitoring signal teams skip
