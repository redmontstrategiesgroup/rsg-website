#!/usr/bin/env python3
"""Rebuild the tuned skill library from the live source. Idempotent and re-runnable."""
import os, re, shutil, sys

SRC = "/mnt/skills/user"
DST = "/home/claude/work"
MERGED = "/home/claude/merged-SKILL.md"
KEEP, RETIRE = "accessible-one-hand-ux", "designing-accessible-one-hand-ux"

HANDOFFS = {
 "accessibility-regression-audit":
   " For designing or auditing one-handed and motor accessibility in the first place — rather than "
   "checking whether a change broke it — use accessible-one-hand-ux instead.",
 "preventing-fake-implementations":
   " For a whole-repo assessment, start with auditing-existing-codebases.",
 "background-job-reliability":
   " For inbound callbacks from a provider, use webhook-and-event-reliability instead — this skill "
   "covers work your own system initiates.",
 "webhook-and-event-reliability":
   " For queues, cron, and long-running work your own system initiates, use background-job-reliability instead.",
 "enforcing-production-quality":
   " This covers whether it works; building-premium-interfaces covers whether it looks and feels considered.",
 "demo-to-production-conversion":
   " For the tenancy, roles, and data-isolation design specifically, use multi-tenant-client-portal.",
 "designing-ai-tool-schemas":
   " For designing the approval step itself — what the approver sees, how consent is scoped, batching "
   "— use human-approval-workflows.",
 "integration-connector-builder":
   " For what the integration is allowed to store, for how long, and who counts as a subprocessor, "
   "use privacy-and-data-retention.",
 "privacy-and-data-retention":
   " This designs the policy and inventory; security-and-privacy-review tests a build by attempting "
   "the attacks, and sensitive-records-and-exports covers sharing health, legal, or intimate records.",
}

# auditing-existing-codebases is within 22 chars of the cap; trim a redundant
# trigger phrase to make room for its handoff clause.
TRIM = ("auditing-existing-codebases",
        '"review this codebase before we build more features", ',
        '')
TRIM_CLAUSE = (" Assesses and reports; refining-projects-for-release performs the fixes.")


def read_desc(path):
    t = open(path, encoding="utf-8").read()
    fm = re.search(r"^---\n(.*?)\n---", t, re.S)
    d = re.search(r"(description:\s*>?-?\s*\n?)(.*)", fm.group(1), re.S)
    return t, fm, d


def set_desc(path, new_desc):
    t, fm, d = read_desc(path)
    start = fm.start(1) + d.start(2)
    end = fm.start(1) + d.end(2)
    open(path, "w", encoding="utf-8").write(t[:start] + new_desc + t[end:])


def flat(path):
    _, _, d = read_desc(path)
    return re.sub(r"\s+", " ", d.group(2)).strip()


def main():
    if os.path.exists(DST):
        shutil.rmtree(DST)
    shutil.copytree(SRC, DST)

    # 1. Merge: carry B's reference into A, install merged SKILL.md, retire B.
    shutil.copy(f"{DST}/{RETIRE}/references/interaction-rules.md",
                f"{DST}/{KEEP}/references/interaction-rules.md")
    shutil.copy(MERGED, f"{DST}/{KEEP}/SKILL.md")
    shutil.rmtree(f"{DST}/{RETIRE}")
    print(f"merged {RETIRE} -> {KEEP}")

    # 2. Trim the one description with no headroom, then give it its handoff.
    name, old, new = TRIM
    p = f"{DST}/{name}/SKILL.md"
    t = open(p, encoding="utf-8").read()
    if old not in t:
        sys.exit(f"FAIL: trim target not found in {name}")
    open(p, "w", encoding="utf-8").write(t.replace(old, new, 1))
    set_desc(p, flat(p) + TRIM_CLAUSE)
    print(f"trimmed + handoff  {len(flat(p)):4}  {name}")

    # 3. Apply the remaining handoff clauses.
    for name, clause in HANDOFFS.items():
        p = f"{DST}/{name}/SKILL.md"
        cur = flat(p)
        if clause.strip() in cur:
            print(f"already applied     {name}"); continue
        new_desc = cur + clause
        if len(new_desc) > 1024:
            sys.exit(f"FAIL: {name} would be {len(new_desc)} chars")
        set_desc(p, new_desc)
        print(f"handoff            {len(new_desc):4}  {name}")


if __name__ == "__main__":
    main()
