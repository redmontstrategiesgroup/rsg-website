# Comfort Questionnaire

The intake that a product's onboarding should ship, and the intake to use while designing for a specific person. It asks one thing in many forms: **"What can you comfortably do?"** — never "what condition do you have?"

Adapt the wording to the product's domain. Keep it about comfortable, repeatable ability. Every question offers a **skip / "prefer not to say"** that resolves to the most supportive default. The questionnaire must itself be answerable with the abilities it asks about — offer the answers as large, spaced, single-tap choices (and keyboard/voice/switch-navigable); never make someone drag a slider to tell you they can't drag.

Feed the answers to `scripts/generate_layout.py` to get a recommended starting layout, then let the user adjust it and save it as a named profile.

## Questions and answer keys

Each question maps to one key in the answers JSON. Allowed values are in `[brackets]`; the **first value is the safe default** used when skipped.

1. **Which hand will you mostly use?**
   `hand`: `[either, left, right, varies]`
2. **Will you usually hold the device with that same hand, or is it braced / on a stand?**
   `grip`: `[varies, same_hand, braced]`
3. **What's comfortable to reach without shifting your grip?**
   `reach`: `[full, most, lower_only, thumb_only]`
4. **Which fingers are comfortable for tapping?**
   `fingers`: `[all, few_fingers, one_finger, thumb_only]`
5. **How is fine aiming for small things?**
   `precision`: `[precise, okay, hard, very_hard]`
6. **Do your movements sometimes shake or land off-target?**
   `tremor`: `[no, sometimes, often]`
7. **Is pressing and holding a button comfortable?**
   `hold`: `[yes, brief, no]`
8. **Is dragging things across the screen comfortable?**
   `drag`: `[yes, short, no]`
9. **Are pinch / two-finger gestures comfortable?**
   `pinch`: `[yes, no]`
10. **How quickly does your hand tire with repeated actions?**
    `endurance`: `[high, medium, low]`  (high = doesn't tire quickly)
11. **Any pain with sustained or repeated use?**
    `pain`: `[no, sometimes, yes]`
12. **Do you use any of these? (choose any)**
    `assistive`: array, any of `[keyboard, voice, switch, foot, dwell]` (empty = none)
    — `switch` = switch access / scanning; `foot` = foot pedals; `dwell` = dwell / eye / head pointer.
13. **Do you prefer extra time (no fast double-taps or countdowns)?**
    `timing`: `[standard, extended]`
14. **Preferred text size?**
    `text_size`: `[default, large, very_large]`

## Answer schema

```json
{
  "hand": "either | left | right | varies",
  "grip": "varies | same_hand | braced",
  "reach": "full | most | lower_only | thumb_only",
  "fingers": "all | few_fingers | one_finger | thumb_only",
  "precision": "precise | okay | hard | very_hard",
  "tremor": "no | sometimes | often",
  "hold": "yes | brief | no",
  "drag": "yes | short | no",
  "pinch": "yes | no",
  "endurance": "high | medium | low",
  "pain": "no | sometimes | yes",
  "assistive": ["keyboard", "voice", "switch", "foot", "dwell"],
  "timing": "standard | extended",
  "text_size": "default | large | very_large"
}
```

Every key is optional; a missing key falls back to its safe default. So a partial answer set is valid — the generator fills the rest with the most supportive option.

## Example answers

```json
{
  "hand": "right",
  "grip": "same_hand",
  "reach": "thumb_only",
  "fingers": "thumb_only",
  "precision": "hard",
  "tremor": "often",
  "hold": "no",
  "drag": "no",
  "pinch": "no",
  "endurance": "low",
  "pain": "sometimes",
  "assistive": [],
  "timing": "extended",
  "text_size": "large"
}
```

Run it:

```bash
python scripts/generate_layout.py example_answers.json
```
