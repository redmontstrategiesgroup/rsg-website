#!/usr/bin/env python3
"""
generate_layout.py — turn comfortable-ability answers into a recommended control layout.

This is the engine behind the "What can you comfortably do?" onboarding. It reads a
short set of answers (see ../assets/onboarding-questionnaire.md), applies deterministic
rules, and emits a recommended layout/profile plus warnings explaining the key choices.

It does NOT ask about, store, or reason over any medical diagnosis. Ability in, layout out.
The output is a *starting recommendation the user can adjust* — a product should expose the
same choices as live settings and let the user save the result as a named profile.

Usage:
    python generate_layout.py answers.json          # read answers file, print summary + JSON
    python generate_layout.py answers.json --json    # print only the JSON layout
    python generate_layout.py --example              # run a built-in worked example
    python generate_layout.py --interactive          # ask the questions on the command line

Answers schema (all keys optional; first listed value is the safe default):
    hand:       either | left | right | varies
    grip:       varies | same_hand | braced
    reach:      full | most | lower_only | thumb_only
    fingers:    all | few_fingers | one_finger | thumb_only
    precision:  precise | okay | hard | very_hard
    tremor:     no | sometimes | often
    hold:       yes | brief | no
    drag:       yes | short | no
    pinch:      yes | no
    endurance:  high | medium | low
    pain:       no | sometimes | yes
    assistive:  list of any of: keyboard, voice, switch, foot, dwell
    timing:     standard | extended
    text_size:  default | large | very_large
"""

import argparse
import json
import sys

# --- Defaults (the most supportive option when an answer is missing) ---------

DEFAULTS = {
    "hand": "either",
    "grip": "varies",
    "reach": "full",
    "fingers": "all",
    "precision": "precise",
    "tremor": "no",
    "hold": "yes",
    "drag": "yes",
    "pinch": "yes",
    "endurance": "high",
    "pain": "no",
    "assistive": [],
    "timing": "standard",
    "text_size": "default",
}

ALLOWED = {
    "hand": {"either", "left", "right", "varies"},
    "grip": {"varies", "same_hand", "braced"},
    "reach": {"full", "most", "lower_only", "thumb_only"},
    "fingers": {"all", "few_fingers", "one_finger", "thumb_only"},
    "precision": {"precise", "okay", "hard", "very_hard"},
    "tremor": {"no", "sometimes", "often"},
    "hold": {"yes", "brief", "no"},
    "drag": {"yes", "short", "no"},
    "pinch": {"yes", "no"},
    "endurance": {"high", "medium", "low"},
    "pain": {"no", "sometimes", "yes"},
    "timing": {"standard", "extended"},
    "text_size": {"default", "large", "very_large"},
}

ASSISTIVE_VALUES = {"keyboard", "voice", "switch", "foot", "dwell"}


def normalize(answers):
    """Fill defaults, lowercase, and drop unrecognized values (falling back to default)."""
    a = dict(DEFAULTS)
    a["assistive"] = []
    for key, default in DEFAULTS.items():
        if key not in answers or answers[key] is None:
            continue
        val = answers[key]
        if key == "assistive":
            if isinstance(val, str):
                val = [val]
            if isinstance(val, list):
                a["assistive"] = [str(v).strip().lower() for v in val
                                  if str(v).strip().lower() in ASSISTIVE_VALUES]
            continue
        val = str(val).strip().lower()
        a[key] = val if val in ALLOWED[key] else default
    return a


# --- Rule helpers ------------------------------------------------------------

def has(a, key, *values):
    return a[key] in values


def uses(a, method):
    return method in a["assistive"]


def any_assistive(a, *methods):
    return any(m in a["assistive"] for m in methods)


# --- The rule engine ---------------------------------------------------------

def generate(answers):
    a = normalize(answers)
    warn = []

    # Handedness -------------------------------------------------------------
    handedness = a["hand"]
    if handedness == "varies":
        handedness = "either"
        warn.append("Hand varies: default to an 'either'/centered layout and let the user flip handedness per session.")

    # Reach ------------------------------------------------------------------
    limited_reach = has(a, "reach", "most", "lower_only", "thumb_only")
    thumb_driven = has(a, "reach", "thumb_only") or has(a, "grip", "same_hand") or has(a, "fingers", "thumb_only")
    reach = {
        "reach_origin": handedness,
        "primary_control_anchor": "reachable_band" if (limited_reach or thumb_driven) else "flexible",
        "reachability_shift": limited_reach or has(a, "grip", "same_hand"),
    }
    if reach["primary_control_anchor"] == "reachable_band":
        warn.append("Limited/thumb reach: anchor primary actions to a reachable band and provide a reachability shift; never strand a key action in the opposite top corner.")

    # Target + spacing tier --------------------------------------------------
    tier_score = 0
    if has(a, "precision", "okay"): tier_score += 1
    if has(a, "precision", "hard"): tier_score += 2
    if has(a, "precision", "very_hard"): tier_score += 3
    if has(a, "tremor", "sometimes"): tier_score += 1
    if has(a, "tremor", "often"): tier_score += 2
    if uses(a, "dwell"): tier_score += 2
    if limited_reach: tier_score += 1
    if has(a, "fingers", "thumb_only"): tier_score += 1
    # >=3 so a single strong signal (very-hard precision) reaches extra-large on its own.
    if tier_score >= 3:
        target_tier = "extra_large"
    elif tier_score >= 1:
        target_tier = "large"
    else:
        target_tier = "default"
    if target_tier != "default":
        warn.append(f"Precision/tremor/dwell factors: use '{target_tier}' target and spacing tier; give destructive controls extra separation.")

    # Gesture policy ---------------------------------------------------------
    keyboardish = any_assistive(a, "keyboard", "switch", "voice", "dwell")
    replace_drag = has(a, "drag", "short", "no") or has(a, "fingers", "thumb_only") or keyboardish
    replace_pinch = has(a, "pinch", "no") or has(a, "fingers", "thumb_only", "one_finger") or has(a, "grip", "same_hand") or has(a, "reach", "thumb_only") or keyboardish
    replace_swipe = has(a, "drag", "short", "no") or limited_reach or keyboardish
    gesture_policy = {
        "replace_drag": replace_drag,
        "replace_pinch_zoom": replace_pinch,
        "replace_rotate": replace_pinch,
        "replace_swipe_nav": replace_swipe,
        "replace_hover_reveal": True,  # hover-only is never acceptable; always provide tap/focus reveal
    }
    if replace_drag:
        warn.append("Drag is hard/absent: every reorder, slider, and drag-to-upload needs a tap/stepper/keyboard equivalent — no drag on the critical path.")
    if replace_pinch:
        warn.append("Pinch/rotate hard/absent: pair zoom and rotate with on-screen buttons or steppers.")

    # Hold policy ------------------------------------------------------------
    replace_hold = has(a, "hold", "brief", "no") or has(a, "pain", "yes") or any_assistive(a, "dwell", "switch")
    hold_policy = {
        "replace_press_and_hold": replace_hold,
        "no_force_or_3d_touch": True,
    }
    if replace_hold:
        warn.append("Sustained holds hard/absent: replace press-and-hold (confirm, record, fast-forward) with tap or a two-step; never require maintained pressure.")

    # Timing policy ----------------------------------------------------------
    extended_time = has(a, "timing", "extended") or any_assistive(a, "switch", "voice") or has(a, "precision", "hard", "very_hard") or has(a, "tremor", "often")
    avoid_double_tap = has(a, "precision", "hard", "very_hard") or has(a, "tremor", "sometimes", "often") or any_assistive(a, "switch", "dwell")
    timing_policy = {
        "extended_time": extended_time,
        "disable_auto_advance": extended_time,
        "avoid_double_tap_windows": avoid_double_tap,
        "no_disappearing_ui_before_action": True,
    }
    if extended_time:
        warn.append("Extra time needed: remove timeouts/countdowns and auto-advance; let interactions wait for the user.")

    # Input methods ----------------------------------------------------------
    input_methods = {}
    # Keyboard access is a cheap, foundational baseline and the substrate switch/voice ride on.
    recommend_keyboard = True
    if uses(a, "keyboard") or uses(a, "switch") or uses(a, "voice") or recommend_keyboard:
        input_methods["keyboard"] = {
            "full_keyboard_access": True,
            "visible_focus_indicator": True,
            "single_key_alternatives_to_chords": True,
            "no_keyboard_traps": True,
            "skip_links": True,
        }
    if uses(a, "voice"):
        input_methods["voice"] = {
            "name_all_interactive_controls": True,
            "label_icon_only_controls": True,
            "command_equivalents_for_gestures": True,
            "numbered_overlay_fallback": True,
        }
    if uses(a, "switch"):
        input_methods["switch"] = {
            "sequential_navigation": True,
            "group_or_region_scanning": True,
            "adjustable_scan_speed": True,
            "auto_scan_or_dwell_option": True,
            "no_simultaneous_input": True,
            "low_step_budget_for_core_tasks": True,
        }
    if uses(a, "foot"):
        input_methods["foot"] = {
            "map_high_frequency_actions": True,
            "pedal_as_modifier_for_chords": True,
            "no_precision_pointing_on_foot": True,
            "optional_accelerator_not_gate": True,
        }
    if uses(a, "dwell"):
        input_methods["dwell"] = {
            "dwell_to_click": True,
            "adjustable_dwell_time": True,
            "visible_dwell_progress": True,
            "suppress_accidental_hover_activation": True,
            "larger_targets_and_spacing": True,
            "no_required_press_or_drag": True,
        }

    # Undo + confirmation ----------------------------------------------------
    high_misfire_risk = has(a, "precision", "hard", "very_hard") or has(a, "tremor", "often") or any_assistive(a, "switch", "dwell")
    undo_confirmation = {
        "undo_for_every_reversible_action": True,
        "guard_destructive_actions": True,
        "prefer_undo_with_delay": high_misfire_risk,
        "separate_destructive_from_safe_controls": True,
        "no_double_submit_on_double_fire": True,
    }
    if high_misfire_risk:
        warn.append("Higher mis-fire risk: prefer undo-with-delay on destructive actions and keep them well separated from safe controls.")

    # Progress persistence ---------------------------------------------------
    persistence_critical = has(a, "endurance", "low") or has(a, "pain", "yes") or extended_time
    persistence = {
        "autosave": True,
        "restore_on_return": True,
        "warn_before_discarding_unsaved": True,
        "critical": persistence_critical,
    }
    if persistence_critical:
        warn.append("Low endurance / pain / extra time: progress persistence is critical — autosave and allow the task to be finished in short bursts with save points.")

    # Profiles ---------------------------------------------------------------
    # Only affirmative signals trigger this — note that "grip: varies" is the safe
    # default, so it must not by itself imply day-to-day variability.
    suggest_time_of_day = has(a, "pain", "sometimes", "yes") or has(a, "endurance", "low") or has(a, "hand", "varies")
    profiles = {
        "named_profiles": True,
        "fast_switch": True,
        "suggest_time_of_day_profiles": suggest_time_of_day,
    }
    if suggest_time_of_day:
        warn.append("Ability changes across the day: offer named profiles (e.g. a 'good day' and a 'tired/painful day' profile) that switch in a step or two.")

    # Emergency reset + onboarding ------------------------------------------
    emergency_reset = {"always_reachable_reset_to_safe_default": True}
    onboarding = {
        "operable_by_stated_modality": True,
        "skippable_with_safe_defaults": True,
        "rerunnable": True,
    }

    layout = {
        "profile_name": profile_name(a),
        "handedness": handedness,
        "reach": reach,
        "target_size_tier": target_tier,
        "spacing_tier": target_tier,
        "gesture_policy": gesture_policy,
        "hold_policy": hold_policy,
        "timing_policy": timing_policy,
        "motion": {"honor_reduced_motion": True},
        "text_size": a["text_size"],
        "input_methods": input_methods,
        "undo_confirmation": undo_confirmation,
        "progress_persistence": persistence,
        "profiles": profiles,
        "emergency_reset": emergency_reset,
        "onboarding": onboarding,
        "warnings": warn,
        "resolved_answers": a,
    }
    return layout


def profile_name(a):
    """Build a short, human-readable profile name from salient abilities. No diagnosis."""
    side = {"left": "Left", "right": "Right", "either": "Either-hand", "varies": "Variable-hand"}[a["hand"]]
    bits = [side]
    if has(a, "reach", "thumb_only"):
        bits.append("thumb reach")
    elif has(a, "reach", "lower_only"):
        bits.append("low reach")
    elif has(a, "reach", "most"):
        bits.append("partial reach")
    if has(a, "tremor", "often"):
        bits.append("tremor")
    elif has(a, "tremor", "sometimes"):
        bits.append("some tremor")
    if has(a, "precision", "very_hard", "hard"):
        bits.append("low precision")
    if has(a, "hold", "no"):
        bits.append("no holds")
    elif has(a, "hold", "brief"):
        bits.append("brief holds")
    if has(a, "drag", "no"):
        bits.append("no drag")
    for m, label in [("voice", "voice"), ("switch", "switch"), ("foot", "pedal"), ("dwell", "dwell"), ("keyboard", "keyboard")]:
        if uses(a, m):
            bits.append(label)
    return " \u00b7 ".join(bits)


# --- Rendering ---------------------------------------------------------------

def render_summary(layout):
    lines = []
    lines.append(f"Recommended profile: {layout['profile_name']}")
    lines.append("")
    lines.append(f"  Handedness ............ {layout['handedness']}")
    r = layout["reach"]
    lines.append(f"  Primary controls ...... anchor to {r['primary_control_anchor']}"
                 f"{' + reachability shift' if r['reachability_shift'] else ''} (reach side: {r['reach_origin']})")
    lines.append(f"  Target / spacing ...... {layout['target_size_tier']}")
    lines.append(f"  Text size ............. {layout['text_size']}")

    gp = layout["gesture_policy"]
    subs = [name.replace('replace_', '').replace('_', ' ')
            for name, on in gp.items() if on]
    lines.append(f"  Provide alternatives .. {', '.join(subs) if subs else 'none required'}")

    if layout["hold_policy"]["replace_press_and_hold"]:
        lines.append("  Holds ................. replace all required press-and-hold")
    tp = layout["timing_policy"]
    timing_notes = []
    if tp["extended_time"]:
        timing_notes.append("extended time, no auto-advance")
    if tp["avoid_double_tap_windows"]:
        timing_notes.append("no double-tap windows")
    if timing_notes:
        lines.append(f"  Timing ................ {', '.join(timing_notes)}")

    if layout["input_methods"]:
        lines.append(f"  Input methods ......... {', '.join(layout['input_methods'].keys())}")

    uc = layout["undo_confirmation"]
    lines.append("  Undo / destructive .... "
                 + ("undo-with-delay + separation" if uc["prefer_undo_with_delay"]
                    else "undo + confirmation + separation"))
    if layout["progress_persistence"]["critical"]:
        lines.append("  Progress .............. autosave (CRITICAL — support finishing in bursts)")
    else:
        lines.append("  Progress .............. autosave + restore")
    if layout["profiles"]["suggest_time_of_day_profiles"]:
        lines.append("  Profiles .............. named profiles incl. good-day / tired-day")
    else:
        lines.append("  Profiles .............. named profiles + fast switch")
    lines.append("  Emergency reset ....... always-reachable reset to safe default")

    if layout["warnings"]:
        lines.append("")
        lines.append("Why these choices:")
        for w in layout["warnings"]:
            lines.append(f"  - {w}")

    lines.append("")
    lines.append("This is a starting recommendation. Expose the same choices as live settings, "
                 "let the user adjust and save it as a named profile, and keep an always-reachable reset.")
    return "\n".join(lines)


# --- Built-in example + interactive mode ------------------------------------

EXAMPLE_ANSWERS = {
    "hand": "right",
    "grip": "same_hand",
    "reach": "thumb_only",
    "fingers": "thumb_only",
    "precision": "hard",
    "tremor": "often",
    "hold": "no",
    "drag": "no",
    "pinch": "no",
    "endurance": "low",
    "pain": "sometimes",
    "assistive": [],
    "timing": "extended",
    "text_size": "large",
}

INTERACTIVE_QUESTIONS = [
    ("hand", "Which hand will you mostly use?", ["either", "left", "right", "varies"]),
    ("grip", "Hold with that same hand, or braced/on a stand?", ["varies", "same_hand", "braced"]),
    ("reach", "What's comfortable to reach without shifting grip?", ["full", "most", "lower_only", "thumb_only"]),
    ("fingers", "Which fingers are comfortable for tapping?", ["all", "few_fingers", "one_finger", "thumb_only"]),
    ("precision", "How is fine aiming for small things?", ["precise", "okay", "hard", "very_hard"]),
    ("tremor", "Do movements sometimes shake or land off-target?", ["no", "sometimes", "often"]),
    ("hold", "Is pressing and holding comfortable?", ["yes", "brief", "no"]),
    ("drag", "Is dragging across the screen comfortable?", ["yes", "short", "no"]),
    ("pinch", "Are pinch / two-finger gestures comfortable?", ["yes", "no"]),
    ("endurance", "How quickly does your hand tire (high = not quickly)?", ["high", "medium", "low"]),
    ("pain", "Any pain with sustained or repeated use?", ["no", "sometimes", "yes"]),
    ("timing", "Prefer extra time (no fast double-taps/countdowns)?", ["standard", "extended"]),
    ("text_size", "Preferred text size?", ["default", "large", "very_large"]),
]


def run_interactive():
    print("Answer each (press Enter to accept the safe default in [brackets]).\n")
    answers = {}
    for key, prompt, opts in INTERACTIVE_QUESTIONS:
        opts_str = "/".join(o if i else f"[{o}]" for i, o in enumerate(opts))
        raw = input(f"{prompt}\n  {opts_str}: ").strip().lower()
        if raw:
            answers[key] = raw
    raw = input("Assistive methods, space-separated (keyboard voice switch foot dwell), or blank:\n  : ").strip().lower()
    if raw:
        answers["assistive"] = raw.split()
    return answers


def load_answers(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        sys.exit(f"Error: answers file not found: {path}")
    except json.JSONDecodeError as e:
        sys.exit(f"Error: {path} is not valid JSON ({e}).")
    if not isinstance(data, dict):
        sys.exit("Error: answers file must be a JSON object of question keys to values.")
    return data


def main():
    p = argparse.ArgumentParser(description="Generate a recommended control layout from comfort answers.")
    p.add_argument("answers", nargs="?", help="Path to an answers JSON file.")
    p.add_argument("--example", action="store_true", help="Run a built-in worked example.")
    p.add_argument("--interactive", action="store_true", help="Ask the questions on the command line.")
    p.add_argument("--json", action="store_true", help="Print only the JSON layout.")
    args = p.parse_args()

    if args.example:
        answers = EXAMPLE_ANSWERS
        if not args.json:
            print("Example answers:")
            print(json.dumps(answers, indent=2))
            print("\n" + "=" * 60 + "\n")
    elif args.interactive:
        answers = run_interactive()
        print()
    elif args.answers:
        answers = load_answers(args.answers)
    else:
        p.print_help()
        sys.exit(1)

    layout = generate(answers)

    if args.json:
        print(json.dumps(layout, indent=2))
    else:
        print(render_summary(layout))
        print("\n" + "-" * 60)
        print("Machine-readable layout (wire this into the product's settings):\n")
        print(json.dumps(layout, indent=2))


if __name__ == "__main__":
    main()
