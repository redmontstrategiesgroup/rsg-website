# Output Templates

Use during **step 8**. Pick the template for the mode. Follow the structure so findings are scannable and every claim maps to a flow and a test. Fill brackets; delete guidance notes.

- [Severity scale](#severity-scale)
- [Audit report template](#audit-report-template)
- [Design spec template](#design-spec-template)

## Severity scale

- **Blocker** — a core task cannot be completed by an in-scope user/modality, or a single imprecise input causes irreversible loss.
- **High** — a core task is completable but fails the efficiency bar (excessive steps, an unavoidable hold/drag, punishing on error, or exhausting); or a frequent task is blocked.
- **Medium** — a non-core task is blocked, or a core task has a friction that a fatigue/pain-limited user will feel but can work around.
- **Low** — a rough edge that reduces comfort without blocking the task.

---

## Audit report template

```
# Accessible One-Hand UX Audit — [Product / Feature]

## Comfort profiles in scope
[The comfortable-ability profiles this audit designs for — e.g. "right thumb, low reach, tremor, no long holds"; "keyboard-only"; "voice + foot pedal". If a specific profile was generated, note it and the layout it recommends. No diagnoses.]

## Summary
- Overall: [pass / at-risk / blocked]
- Per-flow verdict:
  - [Flow A] — [pass / at-risk / blocked]
  - [Flow B] — [pass / at-risk / blocked]
- Top blockers (fix first):
  1. [Barrier → which flow → who it blocks]
  2. ...

## Flow-by-flow findings

### [Flow name]
Task: [what the user is trying to do]

| Step | Barrier | Capability it demands | Who it blocks | Severity | Remediation |
|------|---------|-----------------------|---------------|----------|-------------|
| [step] | [barrier from barriers.md] | [reach / precision / hold / gesture / timing / two-inputs / endurance] | [thumb / keyboard / voice / switch / dwell / low-precision] | [Blocker/High/Medium/Low] | [fix from remediations.md] |

[Short narrative: the story of walking this flow with the in-scope profile, and the specific fixes.]

### [Next flow]
...

## Control-system recommendations
Concrete settings and defaults, not adjectives:
- Reachable zone: [default anchor, reach-origin control, reachability shift]
- Handedness: [left / right / either default; what mirrors]
- Target & spacing tier: [default; large; extra-large — what scales]
- Gesture policy: [which of drag / pinch / rotate / swipe / hover get substitutes, and the substitute]
- Remapping: [what's rebindable; single-key alternatives to chords]
- Input methods: [keyboard / voice / switch / foot / dwell — enabled + key settings like dwell time, scan speed]
- Undo & confirmation posture: [what's undoable; what's guarded; undo-with-delay vs confirm]
- Progress persistence: [what autosaves / restores]
- Profiles: [named profiles offered; how fast to switch]
- Emergency reset: [the always-reachable path back to a safe default]
- Onboarding: [the comfort questionnaire → generated layout, and that it's skippable/re-runnable]

## Modality test results
Per `test-protocol.md`. Mark pass / at-risk / blocked.

| Flow | 1-hand | Keyboard | Low precision | Zoom | Voice | Switch | Reduced motion | High contrast | Accidental activation | Interrupted | Efficiency |
|------|--------|----------|---------------|------|-------|--------|----------------|---------------|-----------------------|-------------|------------|
| [A] |  |  |  |  |  |  |  |  |  |  |  |
| [B] |  |  |  |  |  |  |  |  |  |  |  |

[For every non-pass cell, name the failing test and the barrier behind it below the table.]

## Remediation plan
- **Now** (blockers): [fix — barrier it removes — acceptance criterion]
- **Next** (high): [...]
- **Later** (medium/low): [...]
```

---

## Design spec template

```
# Accessible One-Hand UX Spec — [Product / Feature]

## Comfort profiles supported
[The range of comfortable abilities this design serves, across hand, reach, precision, tremor, hold, drag, gesture, endurance, and assistive methods (keyboard / voice / switch / foot / dwell). No diagnoses.]

## Control system
Defaults, ranges, and behaviors:
- Reachable zone: [...]
- Handedness: [...]
- Target & spacing tier: [...]
- Gesture policy (and the single-input path for each gesture): [...]
- Remapping model: [...]
- Undo & confirmation policy: [...]
- Progress persistence: [...]
- Named profiles: [...]
- Emergency reset: [...]

## Per-flow design

### [Flow name]
Task: [what the user is trying to do]
- Accessible-by-design notes: [how the flow avoids the barrier catalog]
- The single-input path for every action: [for each action in the flow, the tap/key/voice/switch/dwell path that completes it without a gesture, chord, hold, or precise drag]
- Error & interruption behavior: [undo/confirm; autosave/restore]

### [Next flow]
...

## Acceptance criteria
Drawn from `test-protocol.md` — the conditions this design must pass:
- One-hand: [...]
- Keyboard-only: [...]
- Reduced precision: [...]
- Zoom / large text: [...]
- Voice: [...]
- Switch-sequential: [...]
- Reduced motion / high contrast: [...]
- Accidental activation: [...]
- Interrupted sessions: [...]
- Efficiency bar: [...]

## Onboarding flow
[The "What can you comfortably do?" questions adapted to this product, how answers map to the initial layout via the generator, that it's skippable with safe defaults and re-runnable, and that the onboarding itself is operable by each supported modality.]
```
