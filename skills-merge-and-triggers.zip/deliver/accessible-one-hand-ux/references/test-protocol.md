# Test Protocol

Use during **step 7**. A flow is not accessible because it has ARIA labels, and not accessible because it's "technically possible" — it's accessible when a person with limited movement can actually complete it *efficiently*. This protocol proves that.

Run every applicable test against every flow that matters. Record a pass/fail per flow × test in the results table (see `report-template.md`). Any fail on a core task is a blocker until fixed.

Each test lists **Setup** (how to simulate it if you don't have the real assistive tech), **Do** (attempt the flows), and **Pass** (the bar).

## Contents
- [The efficiency bar](#the-efficiency-bar)
- [1. One hand only](#1-one-hand-only)
- [2. Keyboard only](#2-keyboard-only)
- [3. Reduced pointer precision](#3-reduced-pointer-precision)
- [4. Screen zoom / large text](#4-screen-zoom--large-text)
- [5. Voice input](#5-voice-input)
- [6. Sequential switch-style navigation](#6-sequential-switch-style-navigation)
- [7. Reduced motion](#7-reduced-motion)
- [8. High contrast](#8-high-contrast)
- [9. Repeated accidental activation](#9-repeated-accidental-activation)
- [10. Interrupted sessions](#10-interrupted-sessions)
- [Scoring](#scoring)

## The efficiency bar

"Possible" is not the standard. For every core task, also check:

- **Step cost.** It doesn't take an unreasonable number of extra steps versus the default path. A rough heuristic: an accessible path that takes many times the taps/selections of the mouse path is a partial failure even if it "works." Note the step count.
- **No unavoidable pain trigger.** No core task *requires* a sustained hold, a long precise drag, or forceful/repeated precise action with no alternative.
- **Meetable timing.** No step depends on a reaction time, double-tap window, or timeout the user can't comfortably meet; extended-time and no-auto-advance options actually remove the pressure.
- **Recoverable.** A slip is recoverable (undo or confirmation), so the user isn't punished for imprecision.
- **Reasonable effort end to end.** Completing the whole task doesn't demand endurance a fatigue- or pain-limited user can't spend in one sitting, or the task has save points so it can be done in bursts.

A flow that is "possible but exhausting," "possible but 30 taps," or "possible but one slip deletes everything" fails the efficiency bar.

## 1. One hand only

- **Setup.** Put one hand behind your back. Do the flow with a thumb, device held in the same hand. Then repeat with the non-dominant hand. Optionally brace the device and use one finger.
- **Do.** Complete each flow without the second hand touching the device.
- **Pass.** Every action is reachable within a comfortable one-handed zone; nothing needs pinch, rotate, multi-touch, a long precise drag, or a hold-while-moving; primary actions don't live in the opposite top corner.

## 2. Keyboard only

- **Setup.** Ignore the mouse/trackpad entirely (or unplug it). Tab, arrows, Enter/Space, Escape, single keys.
- **Do.** Complete each flow using only the keyboard.
- **Pass.** Every interactive element is focusable and activatable; focus is always visible; no keyboard traps; skip links exist past repeated nav; no required chord lacks a single-key/sequential alternative; drag and hover actions have keyboard equivalents.

## 3. Reduced pointer precision

- **Setup.** Simulate tremor and imprecision: enlarge the cursor, add a pointer offset, or deliberately tap slightly off-center and quickly; on touch, tap with a knuckle or the pad of the thumb rather than aiming carefully. If available, use a shaky-input or sticky-keys style aid.
- **Do.** Complete each flow while landing imprecisely.
- **Pass.** Targets are large and spaced enough that mis-taps are rare; a mis-tap never fires a destructive action without a guard; adjacent safe/destructive controls are separated; no task hinges on landing on a few pixels.

## 4. Screen zoom / large text

- **Setup.** Set OS/browser zoom to 200%+ and the largest text size; on mobile, max out display and font size.
- **Do.** Complete each flow at high zoom.
- **Pass.** Nothing critical is clipped, overlapped, or pushed off-screen; controls remain reachable (reachable-zone logic still holds when things reflow); no horizontal-scroll traps that hide the primary action; the layout reflows rather than breaking.

## 5. Voice input

- **Setup.** Use a voice-control tool, or simulate strictly: allow yourself only "activate the control named X", "scroll", "go back", and a numbered-overlay tap. If a control has no name you'd guess, you can't use it except via the overlay.
- **Do.** Complete each flow by (simulated) voice.
- **Pass.** Every actionable control has a clear, unique name that matches what a user would say; icon-only controls are named; gestures have named command equivalents; no critical action needs precise freeform pointing; timeouts don't cut off a spoken interaction.

## 6. Sequential switch-style navigation

- **Setup.** Simulate single-switch scanning: Tab moves the "scan" one element at a time, Enter selects, nothing else. Count selections per task.
- **Do.** Complete each flow purely sequentially.
- **Pass.** A logical scan order; grouping keeps core-task selection counts within a reasonable budget; no element is reachable only by pointing; no step needs two inputs at once; no timed element vanishes before it can be reached.

## 7. Reduced motion

- **Setup.** Turn on the OS "reduce motion" setting.
- **Do.** Complete each flow.
- **Pass.** The product honors reduced-motion (no large/essential animation, parallax, or motion-gated transitions); nothing becomes unusable or hidden because an animation was suppressed; no action requires perceiving motion.

## 8. High contrast

- **Setup.** Enable OS high-contrast / forced-colors and, separately, a dark or inverted mode.
- **Do.** Complete each flow.
- **Pass.** All controls, focus indicators, and state (selected, disabled, error) remain visible and distinguishable; nothing relies on a color or a subtle shade that high-contrast flattens; focus stays clearly visible (this interacts with keyboard/switch/dwell use).

## 9. Repeated accidental activation

- **Setup.** Deliberately fat-finger: double-fire buttons, tap slightly off, press near destructive controls, trigger swipes and long-presses by accident.
- **Do.** Try to cause damage across each flow — especially near delete/send/discard/pay.
- **Pass.** No destructive or irreversible action fires from a single imprecise input without a confirmation, two-step, or undo-with-delay; double-firing a button doesn't double-submit or double-charge; accidental swipes/long-presses don't cause loss; there's a way back from anything triggered by mistake.

## 10. Interrupted sessions

- **Setup.** Midway through each flow: background the app / switch tabs, wait out a session timeout, simulate a phone call, or navigate away and come back.
- **Do.** Resume and try to finish.
- **Pass.** Progress persists (autosave/draft); returning restores input; timeouts don't silently wipe work; if data must be discarded, the user was warned and offered to save. No flow forces a from-scratch restart after a normal interruption.

## Scoring

For each flow, mark each applicable test **pass / at-risk / blocked**:

- **Blocked** — a core task cannot be completed via that modality/condition, or a single slip causes irreversible loss. Must fix before shipping.
- **At-risk** — completable but fails the efficiency bar (too many steps, an unavoidable hold, punishing on error, or exhausting). Fix or justify.
- **Pass** — completable and efficient by the bar above.

A flow's overall verdict is the worst result across its applicable tests. Report the specific failing test and the barrier behind it, not just the score.
