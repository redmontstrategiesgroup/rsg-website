# Worked Examples

Three end-to-end runs to imitate: an audit, a greenfield design, and a power-user remap. They show how the workflow, the barrier/modality/remediation references, the generator, and the templates fit together. They're illustrative, not exhaustive — adapt to the real product.

- [Example 1 — Audit: mobile checkout](#example-1--audit-mobile-checkout)
- [Example 2 — Design: a new kanban web app](#example-2--design-a-new-kanban-web-app)
- [Example 3 — Remap: voice + foot-pedal power user](#example-3--remap-voice--foot-pedal-power-user)

## Example 1 — Audit: mobile checkout

**Request.** "Audit our mobile checkout — a lot of users seem to abandon it."

**Step 1, comfort profile.** In scope: a common one-handed profile — right thumb, phone held in the same hand, low reach, frequent tremor, no comfortable long holds or drags, tires quickly, wants extra time. Running `python scripts/generate_layout.py --example` on those answers returns the profile *"Right · thumb reach · tremor · low precision · no holds · no drag"* and a layout that anchors primary actions to a reachable band, uses an extra-large target/spacing tier, replaces drag and pinch, drops timeouts, prefers undo-with-delay on destructive actions, and flags progress persistence as critical.

**Step 2, flows.** Browse cart → edit quantities → remove an item → enter shipping → enter payment → place order. (Placing the order is the destructive/irreversible one; watch it closely.)

**Step 3–5, barriers and fixes (excerpt of the flow-by-flow table):**

| Step | Barrier | Capability it demands | Who it blocks | Severity | Remediation |
|------|---------|-----------------------|---------------|----------|-------------|
| Remove item | Slide-to-delete only | Precise drag | thumb, low-precision, switch, dwell | High | Add a "Remove" button; keep the swipe as an extra (remediation 4) |
| Edit quantity | Tiny +/- stepper, tap to reach 12 | Precision + repetition | thumb, tremor, low-endurance | High | Larger stepper with spacing; allow direct number entry (remediations 3, 5) |
| Place order | "Pay" pinned to top-right corner | Reach | thumb (right hand can't reach its own top-right) | Blocker | Anchor primary action to the reachable band (remediation 1) |
| Place order | Single tap charges immediately | Recoverable error | low-precision, tremor | High | Undo-with-delay or a confirm; separate from other controls (remediation 13) |
| Shipping form | Back gesture / 10-min timeout wipes entered data | Endurance, works in bursts | low-endurance, extra-time | Blocker | Autosave + restore; warn before discard (remediation 14) |

**Step 7, test results (excerpt).** One-hand: *blocked* (Pay unreachable) → *pass* after re-anchoring. Interrupted sessions: *blocked* (form wiped) → *pass* after autosave. Reduced precision: *at-risk* (stepper mis-taps, adjacent remove) → *pass* after larger targets + separation. Accidental activation: *at-risk* (one tap pays) → *pass* after undo-with-delay.

**Step 8, verdict.** Checkout was *blocked* for the in-scope profile on two counts (unreachable primary action, lost progress) and *at-risk* on precision and accidental charges. The **Now** list: re-anchor "Pay" to the reachable band; autosave the forms. **Next**: remove-button and larger quantity controls; undo-with-delay on the charge. Each line ships with its acceptance criterion from the test protocol.

## Example 2 — Design: a new kanban web app

**Request.** "We're building a kanban board. Make it work for people with limited hand use."

This is population design, so cover the full range of the questionnaire dimensions rather than one profile, and give every action a single-input path.

**Control system (excerpt).**
- Handedness: either/centered default; primary toolbar reachable; layout doesn't depend on side.
- Targets: default / large / extra-large tier; cards and controls scale together.
- Gesture policy: the signature kanban gesture — **drag a card between columns** — gets first-class non-drag paths: a "Move to…" menu on each card, keyboard cut/paste (select card, `x`, focus column, `v`), and arrow-key move within a column. Hover-revealed card actions (edit, archive) also appear on focus and on tap, with a persistent "⋯" affordance. Pinch-zoom of the board is paired with zoom buttons.
- Remapping: single-key alternatives for every shortcut; all rebindable.
- Undo/confirmation: move, archive, and delete are undoable; delete is undo-with-delay; archive/delete separated from routine controls.
- Persistence: board state and any open card editor autosave.
- Profiles + reset: named profiles, fast switch, always-reachable reset.

**Per-flow design — "move a card to another column."** Single-input paths: (a) touch — tap card → "Move to…" → pick column; (b) keyboard — focus card, `x` to cut, arrow to target column, `v`; (c) voice — "move card to In Review"; (d) switch — scan to card, select, scan the "Move to…" list, select; (e) dwell — dwell the card, dwell "Move to…", dwell the column. No path requires a drag, a hold, a chord, or precise pointing.

**Acceptance criteria** are taken from the test protocol: the move flow must pass one-hand, keyboard-only, voice, switch-sequential (within a small step budget), and dwell, with reduced motion honored and no accidental card loss on mis-fire.

**Onboarding.** A first-run "What can you comfortably do?" flow (adapted wording) sets the initial tier, handedness, and enabled input methods via the generator — skippable to safe defaults, re-runnable, and answerable one-handed / keyboard-only.

## Example 3 — Remap: voice + foot-pedal power user

**Request.** "I run our transcription tool by voice and a foot pedal — the shortcuts fight me."

**Profile.** Answers include `assistive: ["voice", "foot"]`, `hold: "no"`, `drag: "no"`. The generator enables voice (name every control, command equivalents for gestures, numbered-overlay fallback), foot (map high-frequency actions, pedal-as-modifier), and the keyboard baseline; it replaces required holds and drags and prefers undo-with-delay.

**Remap (excerpt).** The frequent transcription actions — play/pause, rewind 5s, insert timestamp — map to the three pedals as single discrete triggers (remediation 10), replacing a hold-to-rewind that pain made unusable (remediation 8's hold replacement). Chorded shortcuts (`Ctrl+Shift+T`) each gain a single-key alternative and can be rebound so the pedal is the modifier half (remediation 6). Every transport control gets a spoken name so "pause", "rewind", "insert timestamp" work by voice without hunting for a button.

**Acceptance.** Voice test: every action addressable by a name the user would say. Foot: the three most frequent actions each fire from one pedal press. No action requires a sustained hold or a two-key chord.
