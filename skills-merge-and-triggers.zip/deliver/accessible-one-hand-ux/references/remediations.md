# Remediation Catalog

Fixes for the barriers in `barriers.md`, mapped to the modalities in `modalities.md`. Use during **step 5 (remediate)** and **step 6 (specify the control system)**.

Prefer **removing** a barrier over adding a path around it. Add an alternative only when removal isn't possible, and make the alternative first-class. Every fix carries **acceptance criteria** — the concrete condition the test protocol checks. A remediation with no acceptance criterion isn't finished; it's a wish.

Each entry: **What / How / Fixes (barriers) / Acceptance / Tradeoffs.**

## Contents
- [1. Configurable reachable zone](#1-configurable-reachable-zone)
- [2. Left / right / either-handed layouts](#2-left--right--either-handed-layouts)
- [3. Larger targets and spacing](#3-larger-targets-and-spacing)
- [4. Alternatives for drag](#4-alternatives-for-drag)
- [5. Alternatives for gestures](#5-alternatives-for-gestures)
- [6. Remappable controls](#6-remappable-controls)
- [7. Full keyboard access](#7-full-keyboard-access)
- [8. Voice access](#8-voice-access)
- [9. Switch-compatible navigation](#9-switch-compatible-navigation)
- [10. Foot-pedal support](#10-foot-pedal-support)
- [11. Dwell activation](#11-dwell-activation)
- [12. Easy undo](#12-easy-undo)
- [13. Confirmation for destructive actions](#13-confirmation-for-destructive-actions)
- [14. Persistent progress](#14-persistent-progress)
- [15. Fast profile switching and named profiles](#15-fast-profile-switching-and-named-profiles)
- [16. Emergency reset](#16-emergency-reset)
- [17. Accessible onboarding from comfortable actions](#17-accessible-onboarding-from-comfortable-actions)

## 1. Configurable reachable zone

- **What.** Keep the actions that matter inside a band the user can reach without re-gripping.
- **How.** Anchor primary controls to a reachable region (typically a lower band on touch); let the user set the reach origin (which side, how far the reach extends); offer a "bring UI down" / reachability shift; float or duplicate a stranded key action into the band when it's needed.
- **Fixes.** Controls outside reach; critical actions at extremes; reach that shifts with content.
- **Acceptance.** Every primary action in the flow is operable one-handed within the configured zone, without putting the device down.
- **Tradeoffs.** Costs vertical space; solve with a togglable shift rather than permanently crowding the layout.

## 2. Left / right / either-handed layouts

- **What.** The layout adapts to the working hand.
- **How.** Mirror control placement by handedness; keep primary actions on the chosen side; default to "either" (center / reachable-band) when unknown; remember the choice.
- **Fixes.** Fixed one-side placement; controls on the side opposite the working hand.
- **Acceptance.** No core action requires the non-working side; switching handedness mirrors the relevant controls and persists.
- **Tradeoffs.** Mirrored layouts need testing on both sides so nothing important is orphaned.

## 3. Larger targets and spacing

- **What.** Comfortable, forgiving hit areas.
- **How.** Enforce a minimum target size and minimum spacing between adjacent controls; expose a size tier (default / large / extra-large) that scales targets, spacing, and text together; give destructive controls extra padding and separation from safe ones.
- **Fixes.** Small targets; tightly spaced targets; dense hit areas; precision-dependent controls (partly).
- **Acceptance.** At the chosen tier, targets meet the size/spacing minimum and the flow is completable with simulated tremor without hitting the wrong control.
- **Tradeoffs.** Larger targets fit less on screen; use tiers and progressive disclosure rather than shrinking everything back down.

## 4. Alternatives for drag

- **What.** Every drag has a no-drag equivalent.
- **How.** Reorder via move-up / move-down buttons, a "move to…" picker, or cut-and-paste; slide-to-confirm via a plain button; drag-to-upload via a file-picker button; drag sliders paired with steppers or direct number entry; keyboard: select then arrow-key to move.
- **Fixes.** Drag-only actions; slide-to-confirm/delete; drag sliders; precision drag handles.
- **Acceptance.** Every reorder, move, slider, and slide action is completable with taps or keys only — no drag anywhere on the critical path.
- **Tradeoffs.** More affordances on screen; group them into a menu if space is tight, but keep them one level deep.

## 5. Alternatives for gestures

- **What.** No content or action reachable only by a multi-finger or hover gesture.
- **How.** Pinch-zoom paired with zoom in/out buttons or a zoom stepper; rotate paired with rotate buttons; swipe navigation paired with visible next/previous/tab buttons; hover reveals also triggered by focus and by tap, and their affordance made persistent (visible without hover); two-finger scroll backed by a scrollbar and keyboard scroll.
- **Fixes.** Pinch/zoom/rotate; hover-only reveal; swipe-only navigation; multi-touch gestures.
- **Acceptance.** Every gesture-driven action and every hover-revealed item is reachable by a single tap, a button, focus, or a key; nothing is hidden behind hover or multi-touch alone.
- **Tradeoffs.** Persistent affordances can feel busier than hover-clean designs; that is the correct trade.

## 6. Remappable controls

- **What.** The user can rebind how actions are triggered.
- **How.** Expose an action map; allow rebinding of keys, gestures, pedals, and switches; provide a single-key alternative for every chord; ship sensible presets; persist per user and per context.
- **Fixes.** Multi-key chords; awkward default bindings; conflicts with an assistive device.
- **Acceptance.** Every shortcut has a single-input path; a user can rebind any action and the binding persists across sessions.
- **Tradeoffs.** A remap UI is work to build; even a small "single-key alternatives" preset covers most of the benefit.

## 7. Full keyboard access

- **What.** The entire product is operable from the keyboard.
- **How.** Ensure a logical tab order; a clearly visible focus indicator on every focusable element; no keyboard traps and Escape to dismiss; skip links past repeated nav; keyboard equivalents for drag, hover, and canvas actions; avoid required chords.
- **Fixes.** Hover-only reveal; drag-only actions; excessive navigation (with skip links); anything mouse-only.
- **Acceptance.** Every flow is completable keyboard-only, with focus always visible and never trapped.
- **Tradeoffs.** Custom widgets need real focus management; budget for it rather than shipping mouse-only components.

## 8. Voice access

- **What.** The product is drivable by spoken commands.
- **How.** Give every control a clear, unique name matching what a user would say; label icon-only controls with a spoken name; provide named command equivalents for gestures; support a numbered-overlay fallback; keep timeouts generous.
- **Fixes.** Unlabeled/ambiguous controls; gesture-only actions; strict timing (partly).
- **Acceptance.** Every flow is completable by voice; every actionable control is addressable by a name a user would guess.
- **Tradeoffs.** Naming discipline is ongoing; enforce it in component review.

## 9. Switch-compatible navigation

- **What.** The product works with sequential scanning.
- **How.** Provide a logical scan order; group/region scanning to minimize steps; adjustable scan speed and an auto-scan/dwell option; remove every simultaneous-input requirement; keep core-task step counts low; ensure no element is pointer-only.
- **Fixes.** Simultaneous input; excessive navigation; pointer-only elements; timed disappearing UI.
- **Acceptance.** Every flow is completable via sequential selection; core tasks stay within a reasonable step budget; nothing requires two inputs at once.
- **Tradeoffs.** Optimizing scan order and grouping takes design attention per screen.

## 10. Foot-pedal support

- **What.** Frequent single actions can be triggered by foot.
- **How.** Map high-frequency discrete actions (confirm, next/previous, scroll, push-to-talk) to pedals; let a pedal be the modifier half of a chord; never assign precision pointing to a foot; keep pedals optional accelerators.
- **Fixes.** Multi-key chords (as the modifier); repetitive frequent actions; sustained hold (replace hold-to-talk with pedal push-to-talk).
- **Acceptance.** The most frequent actions are each a single discrete trigger a pedal can fire; nothing requires a pedal to function.
- **Tradeoffs.** Only a few actions fit; reserve pedals for the true high-frequency ones.

## 11. Dwell activation

- **What.** Clicking without a physical press.
- **How.** Support dwell-to-click; make dwell time adjustable with visible dwell progress; suppress accidental activation on mere hover/pass-over; provide a dwell-friendly alternative to any drag; ensure targets are large and well spaced enough to rest on cleanly.
- **Fixes.** Mandatory physical press/hold; hover-only reveal (accidental activation); small/crowded targets for pointer users; drag.
- **Acceptance.** Every action is achievable by dwell; passing the pointer over elements does not trigger them; no action needs a held press or drag.
- **Tradeoffs.** Generous targets and dwell margins take space; that is required for reliable dwelling.

## 12. Easy undo

- **What.** A reliable, reachable way back from mistakes.
- **How.** Provide undo for every reversible action; a generous undo window; a visible undo affordance (a toast with an Undo button, a persistent undo control); multi-level undo where feasible; make the undo control itself reachable (in the reachable zone, keyboard-accessible, name-addressable).
- **Fixes.** Difficult/missing undo; accidental actions (paired with undo); irreversible single-input commits (converted to reversible-with-undo where possible).
- **Acceptance.** The last destructive or editing action is reversible in a single step, and the undo control is reachable by the profile's modality.
- **Tradeoffs.** Undo infrastructure is engineering work; it removes a whole class of anxiety and is worth it.

## 13. Confirmation for destructive actions

- **What.** A guard between a slip and an irreversible consequence.
- **How.** For destructive or non-reversible actions, require a confirmation, a two-step (no hold), or an undo-with-delay (the action pends briefly and can be canceled); separate destructive controls from safe ones with spacing; never place a destructive action where a mis-tap or an easy gesture triggers it.
- **Fixes.** Accidental destructive actions; irreversible single-input commits.
- **Acceptance.** No destructive or irreversible action fires from a single imprecise input without a confirmation, a two-step, or an undo-with-delay; destructive controls are separated from safe ones.
- **Tradeoffs.** Confirmations add friction; reserve them for genuinely destructive actions so they don't become reflexive noise (and prefer undo-with-delay when it fits).

## 14. Persistent progress

- **What.** Work survives interruptions.
- **How.** Autosave input as it's entered; keep draft state; restore on return; survive backgrounding, timeouts, and navigation-away; warn before any action that would discard unsaved work and offer to save.
- **Fixes.** Lost progress after interruptions; fatigue-inducing sequences with no save point.
- **Acceptance.** Interrupt any flow midway — background it, wait out a timeout, navigate away — and resume with no lost input.
- **Tradeoffs.** Draft/restore is work and touches storage; it is essential for anyone who works slowly or in short bursts.

## 15. Fast profile switching and named profiles

- **What.** Whole comfort configurations, saved and switchable.
- **How.** Let users save named profiles ("Right thumb · low reach · tremor", "Tired evening", "Voice + pedal"); switch between them in a step or two; scope profiles per device or context; apply changes immediately.
- **Fixes.** Ability that changes over time and between sessions; a single fixed configuration that fits no bad day.
- **Acceptance.** A user can switch to a saved profile in at most two steps and the new settings apply immediately.
- **Tradeoffs.** Profile management UI is extra surface; even two or three preset profiles deliver most of the value.

## 16. Emergency reset

- **What.** A safe way out when a setting makes the UI unusable.
- **How.** Provide one obvious, always-reachable reset to a safe default layout — reachable even from a broken state (a fixed hardware/keyboard path, a persistent control, or a recovery entry that doesn't depend on the setting that broke things).
- **Fixes.** A configuration change that strands the user (e.g., a reach or size setting that hides the controls needed to change it back).
- **Acceptance.** From a deliberately broken layout state, the reset is reachable and restores a usable default.
- **Tradeoffs.** Requires a reset path independent of the settings it recovers from; design it in rather than assuming settings can always be undone through the normal UI.

## 17. Accessible onboarding from comfortable actions

- **What.** The "What can you comfortably do?" flow that generates a starting layout.
- **How.** Ask about comfortable abilities, never diagnosis (see `assets/onboarding-questionnaire.md`); generate a recommended layout (see `scripts/generate_layout.py`); make it skippable (safe defaults) and re-runnable; expose the same choices as live settings and named profiles afterward. Critically, the onboarding must be operable with the abilities it's asking about — it must never require the very gestures it exists to compensate for.
- **Fixes.** A one-size default that fits no one; settings that are too deep to discover; onboarding that itself excludes the user.
- **Acceptance.** The onboarding is completable one-handed, keyboard-only, and by the user's stated modality; skipping yields safe defaults; it can be re-run later.
- **Tradeoffs.** Building a generator and settings surface is real work; the payoff is a product that fits the person on the first run and adapts on the tenth.
