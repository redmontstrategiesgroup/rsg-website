# Interaction Rules

Substitutions for interactions that exclude people, and the reasoning behind each. Every rule here
exists because some real input method cannot perform the original.

## Contents
1. Substitution table
2. Reach zones
3. Target sizing and spacing
4. Timing
5. Fatigue budgeting
6. Verification procedures

---

## 1. Substitution table

| Excluding interaction | Why it fails | Accessible equivalent |
|---|---|---|
| Pinch to zoom | Needs two contact points | Zoom buttons, or a zoom control in a toolbar |
| Two-finger scroll | Two contact points | Single-finger scroll, scrollbar, paging buttons |
| Drag to reorder | Sustained precise contact | Move up / move down buttons, or cut-and-place |
| Drag to a target | Same, plus dual attention | Select item, then choose destination from a list |
| Slider | Precise sustained tracking | Stepper buttons plus a numeric input |
| Long-press menu | Timing plus sustained contact | Visible menu button revealing the same actions |
| Double-tap | Timing between taps | Single tap, or single tap plus explicit confirm |
| Swipe to delete | Directional precision | Visible delete control in the row or its menu |
| Hover to reveal | No hover on touch or switch | Always visible, or revealed on focus and tap |
| Modifier + click | Two simultaneous inputs | Dedicated control, or a selection mode |
| Multi-select by dragging | Sustained precision | Checkboxes with a select-all option |
| Pull to refresh | Directional drag | Refresh button |
| Shake to undo | Requires moving the device | Undo button, always available |
| Canvas free-draw only | Continuous precision | Shape tools, click-to-place points |

**The pattern:** replace *sustained, precise, simultaneous, or timed* input with *discrete, forgiving,
single-contact, untimed* input. When adding an interaction, ask which of those four properties it
depends on.

---

## 2. Reach zones

One-handed on a phone, the thumb sweeps an arc pivoting near the bottom corner of the holding side.

- **Comfortable** — lower half, biased toward the holding side. Primary actions, frequent controls,
  and the confirm button live here.
- **Stretch** — upper middle and lower opposite corner. Reachable with effort or a grip shift. Use for
  secondary actions.
- **Hard** — the top corner opposite the holding hand. Requires a grip change, which for someone using
  their only functional hand may mean putting the device down. Avoid entirely for anything routine.

**Two consequences worth acting on.** Bottom-anchored primary actions are better than top-anchored
ones, which inverts a lot of conventional layout. And the hard zone is a *useful* place for rare
destructive actions, since difficulty of reach is a mild safety property.

**Handedness inverts the map entirely.** Provide a setting, apply it to layout rather than only to
alignment, and default to neither — ask.

**On desktop**, the equivalent constraint is distance and precision of pointer travel, plus whether an
interaction can be completed without holding a modifier.

---

## 3. Target sizing and spacing

Aim for a comfortably large minimum touch target, and larger for primary or frequently used controls.
The commonly cited platform minimums are floors, not goals.

**Spacing is the more important variable and the more neglected one.** Adjacent controls with no gap
mean an imprecise tap lands on the wrong one. A missed tap costs a retry; a mis-hit costs an undo, and
on a destructive control it may cost data. Prioritize accordingly:

- Generous space between any two interactive elements.
- Extra space around destructive actions, and never adjacent to a confirm.
- Never place a destructive control where a common control sits in a similar screen — muscle memory
  will find it.
- The visual target and the actual hit area should match. A hit area larger than the visual is
  confusing; smaller is a defect.

---

## 4. Timing

**Remove timing dependencies rather than lengthening them.** A longer timeout still excludes someone.

- No content that disappears before it is read. Toasts persist or are re-readable.
- No session expiry that discards work. Save continuously; on expiry, restore after re-authentication.
- No double-tap, no timed gesture, no "press and hold for N seconds" as the only path.
- Auto-advancing carousels and auto-dismissing dialogs are hostile to slower interaction — provide
  controls, or do not auto-advance.
- Where a timing requirement is genuinely unavoidable, make the duration adjustable and generous by
  default.

**Dwell input specifically** requires that no interaction depend on movement while activated, and that
spacing exceeds the pointer's jitter.

---

## 5. Fatigue budgeting

Treat interactions as a budget the person spends, rather than costs measured one at a time.

- **Count the interactions per task.** Enumerate every tap, focus move, and scroll to complete a common
  flow. High counts are the finding, even when each step is easy.
- **Reduce required steps** — sensible defaults, remembered choices, skippable optional steps,
  batch actions instead of per-item ones.
- **Never require re-entry.** Anything the person already told you is asked once.
- **Support partial completion.** Save state continuously; make resume the default when returning.
- **Watch for repetition.** Ten identical actions in a row is a fatigue problem asking for a
  select-all or an apply-to-all.

**Design review question:** if this task had to be completed at the end of a painful day, with one
hand, taking breaks — does it still work? That is the realistic case, not the exceptional one.

---

## 6. Verification procedures

Each of these is a real procedure, run against a real build. None can be replaced by inspecting code.

**One-handed pass.** Hold a phone in one hand, thumb only, no second hand, no surface. Complete each
primary task. Note anything requiring a grip shift.

**Both handedness settings.** Repeat holding in the other hand with the handedness setting flipped.
Asymmetric problems appear immediately.

**Keyboard-only.** Put the mouse away. Complete every task with keyboard alone. Check tab order is
sensible, focus is always visible, nothing traps focus, and no action is unreachable.

**Voice.** Every control must have a speakable name matching its visible label. Icon-only buttons
without accessible names are the usual failure.

**Sequential access.** Simulate switch scanning by tabbing forward only, one step at a time, counting
steps to each frequent control. Long paths to common actions are the finding.

**Reduced precision.** Use a stylus held loosely, or tap with a knuckle. Mis-hits reveal spacing
problems that careful testing hides.

**Interruption.** Abandon each flow halfway, wait, return. Work should be preserved and resumption
obvious.

**Error recovery.** Deliberately trigger every destructive action and undo it. Deliberately submit
invalid input and recover.

**Zoom and contrast.** Enlarge text substantially and check nothing is clipped, overlapped, or pushed
off-screen — magnification and motor limitation frequently co-occur.

**What automated checkers give you:** they catch missing labels, insufficient contrast, and some
structural problems, which is genuinely useful. They cannot tell you whether a task can be completed
one-handed. Report a clean automated result as what it is — the absence of one class of error, not
evidence of usability.
