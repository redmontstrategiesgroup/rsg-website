# Input Modalities

What each input method can and can't do, its minimum requirements, and how to test it. Use during **step 4 (diagnose against modalities)** and **step 7 (test)**. A barrier is often invisible until you view a flow through one specific modality, so check every method the profile enables.

For each modality: **Capabilities** (what the user can do), **Constraints** (what breaks), **Minimum requirements** (what the design must guarantee), **Test** (how to try it).

## Contents
- [1. One-handed touch — thumb-driven](#1-one-handed-touch--thumb-driven)
- [2. One-handed touch — index finger, device braced](#2-one-handed-touch--index-finger-device-braced)
- [3. Keyboard only](#3-keyboard-only)
- [4. Voice control](#4-voice-control)
- [5. Switch access — scanning](#5-switch-access--scanning)
- [6. Foot pedals](#6-foot-pedals)
- [7. Dwell, eye, and head pointing](#7-dwell-eye-and-head-pointing)

## 1. One-handed touch — thumb-driven

The user holds and operates the device with the same hand; the thumb does the work.

- **Capabilities.** Taps and short swipes within a thumb arc; can reach a curved band from the bottom corner of the holding side. Comfortable zone is the lower two-thirds nearest the thumb; the opposite top corner is the classic dead zone.
- **Constraints.** Cannot reach the far top corner without re-gripping. Cannot do multi-finger gestures (pinch, two-finger scroll, rotate). Drags are tiring and imprecise, especially long ones. Holding the device *is* the grip, so "hold while dragging" is effectively two-handed.
- **Minimum requirements.** Primary actions live in the reachable band or float to it; a handedness setting mirrors the layout. No action requires pinch, rotate, multi-touch, or a long precise drag. Targets and spacing large enough for a thumb. Reachable alternative for anything otherwise stranded at an extreme.
- **Test.** Operate the whole flow with one thumb, device in the same hand, and do not let the other hand touch the screen. Then repeat holding the phone in the non-dominant hand.

## 2. One-handed touch — index finger, device braced

The device rests on a surface, a stand, or against the body; a single finger taps.

- **Capabilities.** Better precision and reach than thumb-only because the device is stabilized; can reach most of the screen.
- **Constraints.** Often cannot brace the device *and* perform a gesture that needs a second contact point (pinch, two-finger). Sustained holds and repeated drags still tire and can hurt. If the device isn't stable, precision drops sharply.
- **Minimum requirements.** No multi-touch gesture without a single-pointer alternative. No mandatory sustained hold. Works whether or not the device is perfectly stable.
- **Test.** Rest the device on a table and complete the flow with one finger only.

## 3. Keyboard only

No pointer at all — Tab, arrows, Enter/Space, Escape, and single keys. This is also the substrate many switch and voice setups ride on, so keyboard access buys broad coverage.

- **Capabilities.** Move focus, activate, type, navigate menus and lists — *if* every interactive element is focusable and every action has a key path.
- **Constraints.** Cannot use anything mouse-only: hover reveals, drag, canvas manipulation, custom widgets that don't take focus. Cannot see where they are without a visible focus indicator. Chords (two keys at once) may be impossible for the same users who need keyboard access.
- **Minimum requirements.** Logical tab order; a clearly visible focus indicator on every focusable element; no keyboard traps (focus can always move on and Escape dismisses); skip links past repeated navigation; a single-key or sequential alternative to every chord, and remappable bindings; drag and hover actions have keyboard equivalents.
- **Test.** Unplug or ignore the mouse. Complete every flow using only the keyboard, watching that focus is always visible and never stuck.

## 4. Voice control

The user speaks commands ("click Send", "scroll down", "show numbers"). Often paired with dwell or a single switch for a fallback click.

- **Capabilities.** Activate any control that has a name, dictate text, navigate by label, and use a numbered-overlay mode to target unlabeled elements.
- **Constraints.** Controls with no accessible name are unreachable except by the clumsy numbered overlay. Drag, pinch, and freeform pointing are hard or impossible by voice. Two unlabeled icons that look identical can't be distinguished. Noisy timing-based UI (things that vanish) is hard to catch by voice.
- **Minimum requirements.** Every interactive control has a clear, unique, visible-or-programmatic name that matches what a user would say; icon-only controls carry a spoken-name label; gestures have named command equivalents ("zoom in", "next"); nothing critical depends on precise pointing; timeouts are generous or off.
- **Test.** Drive the flow with a voice-control tool (or simulate: allow yourself only "activate the control named X", "scroll", "go back", and a numbered-overlay tap). If you can't name it, you can't click it.

## 5. Switch access — scanning

One or two physical switches (a button, a sip-and-puff, a head switch). The system highlights elements in sequence (auto-scan) or on a step switch; the user selects with a second switch or a dwell.

- **Capabilities.** Reach every focusable element by waiting for or stepping the scan to it, then selecting. Group scanning (regions, then items) cuts the number of steps.
- **Constraints.** Everything is *sequential* — no direct pointing, so far-apart or many targets mean many steps. Cannot do simultaneous input at all. Sensitive to scan speed: too fast is unusable, too slow is exhausting. Hover, drag, and timed disappearing UI break scanning.
- **Minimum requirements.** A logical scan order; grouped/region scanning to keep steps low; adjustable scan speed and an auto-scan/dwell option; no simultaneous-input requirement anywhere; minimal steps to core actions; no element that can only be reached by pointing.
- **Test.** Simulate single-switch scanning: Tab through elements one at a time (that's your "scan"), select only with Enter, and count the steps to finish each core task. Long counts and any unreachable element are failures.

## 6. Foot pedals

A small number of discrete foot inputs, often alongside another method. Best as accelerators for frequent single actions.

- **Capabilities.** Fire a few reliable discrete actions hands-free: confirm, next/previous, scroll, page, push-to-talk, or act as a modifier so a chord becomes "pedal + tap."
- **Constraints.** Very few inputs; no precision pointing; not suited to targeting or text. Overloading pedals with long-press or sequences defeats the point.
- **Minimum requirements.** High-frequency single actions are mappable to pedals; a pedal can serve as the modifier half of any chord; nothing *requires* a pedal (they accelerate, they don't gate); no precise pointing assigned to a foot.
- **Test.** Pick the three most frequent actions in the flow and confirm each can be a single discrete trigger (mappable to a pedal) rather than a gesture or a chord.

## 7. Dwell, eye, and head pointing

The pointer is driven by eyes, head, or a joystick; "clicking" happens by dwelling (resting on a target for a set time) rather than pressing.

- **Capabilities.** Move a pointer and select by dwell; can reach anywhere the pointer goes.
- **Constraints.** No physical click, so anything needing press-and-hold, drag, or a real button-down is hard or impossible. Small or crowded targets cause mis-dwells. Hover-activated UI fires accidentally as the pointer passes over it. Precise, sustained pointing is tiring; targets must be generous.
- **Minimum requirements.** Every action achievable by a dwell-click (no mandatory physical press, hold, or drag); larger targets and generous spacing so dwell lands cleanly; adjustable dwell time with visible dwell progress; no accidental activation on mere hover/pass-over; a dwell-friendly alternative to any drag.
- **Test.** Assume clicks come only from resting on a target: verify nothing needs a hold or drag, targets are big enough to rest on without slipping to a neighbor, and passing the pointer over things doesn't trigger them.
