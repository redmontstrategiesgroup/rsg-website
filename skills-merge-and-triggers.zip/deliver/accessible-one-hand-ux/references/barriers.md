# Barrier Catalog

The failure modes that block limited one-hand or one-arm use, grouped by kind. Use this as the checklist for **step 3 (inspect each flow for barriers)**. For every step in a flow, run the six-question inspection, then scan the relevant groups below.

## Contents
- [The six-question flow inspection](#the-six-question-flow-inspection)
- [A. Reach and position](#a-reach-and-position)
- [B. Target and precision](#b-target-and-precision)
- [C. Gesture and manipulation](#c-gesture-and-manipulation)
- [D. Input combination and timing](#d-input-combination-and-timing)
- [E. Motion and endurance](#e-motion-and-endurance)
- [F. Errors, undo, and state](#f-errors-undo-and-state)

## The six-question flow inspection

Walk each step of a flow and ask, in order:

1. **Where is the control?** Is it inside a comfortable reach for a thumb or a single hand, or at a far corner / opposite edge / top of a tall screen?
2. **How big and precise is it?** Is the target comfortably large and spaced, or small, thin, crowded, or precision-dependent?
3. **What gesture does it require?** A single tap, or a drag, pinch, rotate, swipe, hover, or long-press?
4. **What combination or timing does it demand?** Anything held while something else moves? A chord of keys? A double-tap window, a timeout, a disappearing element, an auto-advance?
5. **How repetitive is it?** How many precise or forceful actions does completing the task take end to end?
6. **What happens on an error or interruption?** Is a mistake easy to make and hard to undo? Does leaving mid-task or a timeout lose progress?

Anything that answers "the hard version" is a barrier. Log it with the capability it demands.

## A. Reach and position

- **Controls outside comfortable reach.** Primary actions in the top corners, the far edge, or the side opposite the working hand. On a large phone a thumb simply can't get there without re-gripping (which for many people means putting the device down).
- **Critical actions at screen extremes.** "Done", "Pay", "Next", "Send" pinned to a top-right corner or the very top of a long scroll on tall or large screens.
- **Fixed one-side placement.** A floating action button or nav control hard-anchored to one side (usually bottom-right) with no mirror for the other hand.
- **Reach that shifts with content.** Controls that move as a list grows or the keyboard opens, landing the key action somewhere unreachable at the moment it's needed.

## B. Target and precision

- **Small targets.** Hit areas below a comfortable size — icon-only buttons, close "×" glyphs, tiny checkboxes, compact toolbars.
- **Tightly spaced targets.** Adjacent controls with little or no padding, so a tremor or an imprecise thumb hits the neighbor. Adjacency of a safe control and a destructive one is especially dangerous.
- **Precision-dependent controls.** Thin sliders, small drag handles, resize corners, color-picker points, map pins, timeline scrubbers — anything that demands landing and holding on a few pixels.
- **Dense hit areas without forgiveness.** Long dropdown lists, dense date pickers, seat maps, and grids where every option is a small, crowded target.

## C. Gesture and manipulation

- **Drag-only actions.** Reordering by drag-and-drop, slide-to-confirm, slide-to-delete, drag-to-upload, drag sliders — offered with no tap/button/keyboard equivalent.
- **Pinch, zoom, rotate.** Multi-finger gestures for zooming images, maps, or documents, or for rotating content, with no on-screen stepper or buttons.
- **Hover-only reveal.** Menus, tooltips, controls, or content that appear only on hover. On touch there is no hover; for dwell and switch users, hover activation is unreliable or accidental.
- **Swipe-only navigation.** Tabs, carousels, "next page", or drawers reachable only by swipe, with no visible buttons.
- **Long-press as the only path.** Context actions, selection, or menus available only by press-and-hold — hard or painful for users who can't sustain a hold.
- **Multi-touch / two-handed gestures.** Two-finger scroll-as-the-only-scroll, split interactions, or anything assuming a second hand to brace or act.

## D. Input combination and timing

- **Simultaneous input.** Hold-and-drag, press-and-move, modifier-plus-click, or "hold this while tapping that." Any requirement to do two coordinated things at once is a barrier for one hand and for switch/dwell users.
- **Multi-key shortcuts (chords).** Keyboard shortcuts requiring two or more keys at once with no single-key or sequential alternative, and no remapping.
- **Strict timing.** Double-tap or double-click windows, session timeouts, toasts and menus that vanish before they can be acted on, auto-advancing carousels or steps, "press within N seconds" prompts.
- **Sustained pressure or hold.** Press-and-hold to confirm, hold-to-record, hold-to-fast-forward, force/3D-touch — requiring maintained pressure many users can't give without pain or fatigue.

## E. Motion and endurance

- **Repetitive motion.** Tasks that take many taps, drags, or precise actions to finish (incrementing a quantity one tap at a time up to 30; tapping through dozens of items; repeated drag-reordering).
- **Fatigue-inducing sequences.** Long multi-step forms, wizards, or precise-action chains with no save point, so tiring or pain forces a restart.
- **Momentum / flick-dependent scrolling.** Long content that practically requires repeated flicks, or physics-based scrolling with no page-up/down, jump-to, or keyboard scroll.

## F. Errors, undo, and state

- **Difficult or missing undo.** Actions with no way back, or an undo that is time-limited, hidden, buried in a menu, or itself hard to reach.
- **Accidental destructive actions.** Delete, send, archive, discard, or purchase that fire from a single tap, sit next to a safe control, or trigger on an easy-to-mishit gesture — with no confirmation and no undo.
- **Excessive navigation.** Deep menu trees and many-screen paths that multiply the reaches, taps, and chances to slip needed to do one thing.
- **Lost progress after interruptions.** No autosave; forms and drafts wiped by a back gesture, a timeout, a phone call, or the app being backgrounded. Costly for anyone who works slowly or in short bursts between rests.
- **Irreversible single-input commits.** A non-reversible action (submit, pay, post, delete permanently) reachable by one imprecise input, with nothing between the slip and the consequence.
