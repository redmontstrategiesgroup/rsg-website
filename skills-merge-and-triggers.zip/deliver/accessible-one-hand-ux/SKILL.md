---
name: accessible-one-hand-ux
description: Design or audit any product or interface for people with limited use of one arm or hand — one-handed operation, thumb reach and target placement, reduced grip or precision, tremor, limited range of motion, fatigue, pain, RSI, interrupted sessions, or reliance on voice, keyboard, switch/scanning, foot-pedal, or dwell input. Use this whenever a task touches motor accessibility, one-handed or thumb-zone layout, reachability, handedness or left-handed layout, remappable controls, or making a flow completable without fine motor control — even when the person only says "accessibility", "ergonomics", "RSI", "make this easier to use on a phone", or names a device like a foot pedal or sip-and-puff switch, and even if they never say "one hand". Design around what the person can comfortably and reliably do rather than any diagnosis, and verify that a person with limited movement can actually finish the task efficiently rather than trusting ARIA labels alone.
---

# Accessible One-Hand UX

Design and audit products so a person with limited use of one arm or hand can complete real tasks efficiently. This covers permanent limitations, temporary ones (a cast, holding a baby, an injury), and abilities that change hour to hour with fatigue, pain, or a flare-up.

Two layers govern everything below: **principles** (how to think) and **hard constraints** (what must never ship). Internalize both before touching a flow.

## Core principles (read first)

1. **Design around comfortable, reliable ability — never a diagnosis.** Do not ask what condition someone has. Ask what they can comfortably and repeatably do: which hand, how far they can reach, how precise their aim is, whether holding or dragging is easy, how fast they tire. Two people with the same diagnosis need different layouts; two people with different diagnoses often need the same one. Ability is the design input; diagnosis is noise. Functional questions are also less intrusive and keep the data a sensitivity tier below a medical fact.

2. **Ability varies — within a person and over time.** The same user is more precise in the morning and shakier when tired; a good day and a bad day want different targets. Design for a *range* and make the important choices adjustable and remembered — adjustable *without re-running setup*, not a hidden toggle a user fights into place once.

3. **ARIA labels are not accessibility.** A correct accessible name does not make a drag target reachable one-handed, a pinch gesture doable with a thumb, or a 4-second double-tap window meetable with a tremor. Semantic markup is necessary and not sufficient. The bar is always: *can a person with limited movement complete this task, and complete it efficiently?* Prove that, don't assume it.

4. **Remove the barrier before adding a path around it.** A single-input path that everyone uses beats a special "accessibility mode" bolted on beside a broken default. Add an equivalent alternative only when the barrier genuinely can't be removed — and make it first-class, not a lesser detour.

5. **Never gate core functionality behind one input method, one gesture, one hand, or one moment in time.** Every action that matters needs a path that survives losing any single capability.

## The five hard constraints

These are not preferences. An interface violating any of them is unusable for some people no matter how good the rest is. Each violation is a defect with a specific fix — see the substitution table in `references/interaction-rules.md`.

1. **Nothing requires two simultaneous contact points.** No pinch-to-zoom as the only zoom, no two-finger scroll as the only scroll, no modifier-plus-click as the only path, no press-and-hold-while-dragging. Every such interaction needs a single-contact equivalent.

2. **Nothing is drag-only.** Dragging demands sustained contact, sustained precision, and sustained attention at once, and it fails for tremor, fatigue, and switch access alike. Every drag needs an alternative: cut/paste or move-up/down for reordering, a stepper plus numeric input for sliders, select-then-choose-destination for moving things.

3. **No strict timing.** No double-tap as the only path, no timeout that discards work, no notification that disappears before it can be read, no session expiry mid-task without recovery. Timing requirements exclude people whose movements are slower or less predictable, and they are almost never load-bearing.

4. **Targets are large and separated.** Generous size matters, but **spacing matters more** — a miss costs a retry while a mis-hit costs an undo, so an accidental tap on a neighbouring control is the worse failure. Give destructive controls extra separation.

5. **Every action is reversible, and recovery is reachable.** Mis-taps are frequent, not exceptional. Undo must be available and must itself satisfy every rule above. A confirmation dialog whose buttons are small, adjacent, and at the top of the screen is not a safety mechanism.

**The pattern underneath all five:** replace *sustained, precise, simultaneous, or timed* input with *discrete, forgiving, single-contact, untimed* input. When adding any interaction, ask which of those four properties it depends on.

## Reach, handedness, and fatigue

- **Reach is not uniform.** One-handed on a phone, the thumb sweeps an arc — comfortable near the bottom and the holding side, straining at the far top corner. Put primary and frequent actions in the comfortable zone; put rare and destructive actions deliberately outside it, which conveniently makes accidental activation harder. Zone definitions are in `references/interaction-rules.md`.
- **Handedness flips the map.** A layout tuned for a right hand is actively hostile to a left hand — the comfortable corner becomes the unreachable one. Support both, driven by a setting that changes layout rather than only alignment, and default to neither: ask.
- **Fatigue is cumulative, so treat interactions as a budget.** Interfaces are typically evaluated on the first interaction, when the person is fresh. Count the *total* interactions a task requires, not the difficulty of each: eight taps to complete something common is a fatigue problem even though no individual tap is hard. Reduce steps, remember choices, never require re-entry, and replace ten repeated actions with a select-all.
- **Sessions get interrupted.** Fatigue, pain, and needing the hand for something else all interrupt tasks mid-flow. Save progress continuously, never discard work on timeout, and make resuming the default when returning.

## Two modes

This skill runs in one of two modes; many jobs use both.

- **Audit** — an existing product, app, site, screens, screenshots, or a URL. Signals: "review / fix / audit our…", a link, images of a UI, "why can't users…". Walk the real flows and find what blocks limited movement.
- **Design** — something new or not yet built. Signals: "build / design / spec a new…", a feature described but not shipped. Produce an accessible-by-design control system and per-flow design.

If it's ambiguous, ask one short question, or default to design-forward recommendations that also work as an audit checklist.

## Workflow

1. **Establish the comfort profile.** For a specific user or persona, run the comfort questionnaire (`assets/onboarding-questionnaire.md`) and generate a starting layout (`scripts/generate_layout.py`, below). For a whole population, you still walk the questionnaire's dimensions — they are your capability checklist — and design for the full range rather than one profile.
2. **Map the flows that matter.** Enumerate the tasks: core tasks, high-frequency tasks, and every destructive or irreversible one. Count the interactions each requires. Accessibility fails in *flows*, not isolated components — a button can be perfect and the four-step path to reach it still be a wall.
3. **Audit against the five hard constraints.** Every violation is a defect with a named fix. Do this before the finer-grained pass — it catches the blocking problems fastest.
4. **Inspect each flow for the remaining barriers.** Go step by step with `references/barriers.md` as the checklist. For every control ask: where is it, how big and precise, what gesture, what input combination or timing, how repetitive, and what happens on an error or interruption. Note the capability each step *demands*.
5. **Diagnose against input modalities.** For each barrier, check `references/modalities.md`: does this break for a thumb-only user, keyboard-only, voice, switch scanning, foot pedals, or dwell/eye pointing? A barrier is often invisible until you view the flow through one specific modality. Check reach and handedness for *both* hands, on the smallest supported screen.
6. **Remediate.** Use `references/remediations.md`. Prefer removing the barrier; otherwise provide an equivalent alternative. Attach concrete acceptance criteria to every fix — a remediation you can't test isn't done.
7. **Specify the control system.** Turn the fixes into concrete, named settings and defaults: reachable zones, handedness, target-size tier, gesture substitutions, remapping, undo/confirmation posture, progress persistence, named profiles, and emergency reset. Give defaults, ranges, and behaviors, not adjectives.
8. **Run the test protocol.** Put the result through `references/test-protocol.md`. Verify each input path completes a real task end to end — not "is it focusable", but actually finishing the flow using only the keyboard, then only voice, then simulated sequential access. Abandon a flow mid-way and return; mis-tap and undo. Do not call a flow accessible until it passes every applicable test, including the efficiency bar rather than the "technically possible" bar.
9. **Produce the deliverable.** Write it up with `references/report-template.md` (an audit report or a design spec). Follow the template structure exactly so findings are scannable and every claim maps to a flow.

## The comfort questionnaire and the layout generator

The onboarding a product should ship — and the intake you use while designing — asks one question in many forms: **"What can you comfortably do?"** Never "what's wrong with you?"

- Present the questions from `assets/onboarding-questionnaire.md`, adapting the wording to the product's domain. Every item offers a skip / "prefer not to say" that resolves to the most supportive default.
- Collect answers as JSON per the schema in that file.
- Generate a recommended layout:

```bash
# From a saved answers file:
python scripts/generate_layout.py answers.json

# Try a built-in worked example (prints its answers and the generated layout):
python scripts/generate_layout.py --example

# Ask the questions interactively on the command line:
python scripts/generate_layout.py --interactive

# Emit only machine-readable JSON (for wiring into a real onboarding flow):
python scripts/generate_layout.py answers.json --json
```

The generator maps comfortable abilities to concrete layout decisions (handedness, reachable band, target/spacing tiers, which gestures to replace, hold and timing policy, enabled input methods with their settings, undo/confirmation posture, and warnings). Treat its output as a *starting recommendation the user can adjust* — and expose those same choices in the product as live settings, saved named profiles, and an always-reachable reset. The onboarding must itself be operable with the user's stated abilities: never require a drag to answer "I can't drag."

## Output format

Use `references/report-template.md` verbatim as the structure. In brief:

- **Audit** → comfort profiles in scope → summary with a per-flow verdict (pass / at-risk / blocked) → flow-by-flow findings (a table of step, barrier, capability demanded, who it blocks, severity, remediation) → control-system recommendations → modality test results table → a Now / Next / Later remediation plan with acceptance criteria.
- **Design** → comfort profiles supported → the control system (defaults, ranges, behaviors) → per-flow design showing the single-input path for every action → acceptance criteria drawn from the test protocol → the onboarding flow.

## Reference map (load as needed)

- `references/interaction-rules.md` — **quick lookup.** Substitution table (excluding interaction → why it fails → accessible equivalent), reach-zone definitions, target sizing and spacing numbers, timing rules, fatigue budgeting. Read during steps 2 and 3, and any time you need a fast answer for "what do I use instead."
- `references/barriers.md` — catalog of barriers and how to detect them in a real UI. Read during step 4.
- `references/modalities.md` — what each input method (touch, keyboard, voice, switch, foot, dwell) can and can't do, with minimums and test notes. Read during steps 5 and 8.
- `references/remediations.md` — **full catalog.** Fixes mapped to barriers and modalities, each with acceptance criteria and tradeoffs. Read during steps 6 and 7.
- `references/test-protocol.md` — the manual test matrix and pass criteria, including the efficiency bar. Read during step 8.
- `references/report-template.md` — audit and design output templates, plus the severity scale. Read during step 9.
- `references/examples.md` — worked end-to-end examples (an audit, a greenfield design, a power-user remap). Read when you want a model to imitate.

## Guardrails

- Never ask for or design around a medical diagnosis — and never infer one from functional answers. Comfortable ability only.
- Never claim a flow is accessible from ARIA/labels alone. Demonstrate task completion via the test protocol.
- Never add an accessible alternative that is worse. A second-class path — more steps, fewer features, harder to find — communicates who the product is really for.
- Adjustability is the default posture, not a buried toggle. There is no single "hard mode" that is the only mode, and no accommodation that requires redoing setup to change.
- Every destructive or irreversible action has an undo, a confirmation, or an undo-with-delay — never none of the three, and never placed where a mis-tap fires it.
- Never rely on hover, precision drag, or multi-touch for anything essential.
- Never evaluate only when fresh and only on the largest screen. Test tired, one-handed, on the smallest device you support.
- Keep the person's dignity central. Alternative paths are equal citizens, not a slower back door.

**The test that matters most:** can the whole task be finished by someone who can only tap, one finger at a time, imprecisely, with pauses? If yes, the design works for a very wide range of people.
