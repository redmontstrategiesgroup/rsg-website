---
name: preventing-fake-implementations
description: >-
  Trace every user-visible claim through the whole stack — interface, handler, service, database or provider, response, and refreshed interface — to find functionality that looks finished but does no real work, then replace the fakes with real implementations and prove it. Finds dashboards of invented numbers, save buttons whose data vanishes on refresh, checkouts that never charge, integrations that never contact their provider, uploads that store nothing, "adaptive" or "AI" features returning canned output, and success messages shown before anything succeeded. Use when someone suspects vibe-coded or stubbed features, asks whether something actually works or is fake, wants a truthfulness audit before a demo, handoff, or launch, or says "does this really do anything", "make sure it works end to end", or "prove this is real". Trigger even without the word "fake" — a feature nobody has verified past the happy path is the same problem. For a whole-repo assessment, start with auditing-existing-codebases.
---

# Preventing Fake Implementations

## The method: change the input, prove the output changes

Reading code tells you what it appears to do. It does not tell you whether the thing on screen came
from where it claims. The only reliable test is **causation**:

**Change the input that supposedly drives a behavior. If the output does not change, the behavior is
fake.**

This one procedure catches the whole class. A recommendation that claims to adapt to a user's data
must produce visibly different output for visibly different data. A dashboard claiming live figures
must change when the underlying records change. A saved setting must survive a refresh, a new session,
and a different device.

Everything below is scaffolding around that test.

## The seven claims to verify

For any feature, work through these. Each has a specific, cheap procedure.

**1. Does the write reach storage?**
Submit data. Then query the database directly — not the interface, which may be reading its own
in-memory copy. If the row is not there, nothing was saved.

**2. Does it survive?**
Hard-refresh. Then sign out and back in. Then open a different browser or device. Data held in
component state survives navigation; data in browser storage survives refresh but not a device change.
Only real persistence survives all three.

**3. Is derived output actually derived?**
Change the inputs meaningfully and confirm the output changes correspondingly. Then change them a
different way and confirm it changes differently. **A canned default passes a single comparison** —
two different inputs that produce identical output is the signature of a hardcoded result wearing an
adaptive label.

**4. Is authorization real and server-side?**
Call the endpoint directly as a different user, bypassing the interface entirely. Attempt to read and
to modify another user's record. Hiding a control in the UI is not authorization, and this test is the
only one that distinguishes them.

**5. Does the success message follow a confirmed operation?**
Force the underlying operation to fail — disconnect the network, break the credential, stop the
dependency. If a success message still appears, it was never tied to the outcome. This is the most
common single defect in generated code.

**6. Does the integration contact its provider?**
Watch the outbound network. If no request leaves, the integration is a stub regardless of how complete
its code looks.

**7. Is the displayed data real?**
Trace each number and string on screen back to its origin. Placeholder values, plausible-looking
constants, and arrays defined in the component are the tells.

## Workflow

**Step 1 — Enumerate the claims.** List every capability the interface asserts — every button implying
an action, every figure implying a measurement, every label implying adaptation. This list is the
audit scope, and building it from the interface rather than the code is deliberate: it captures what a
user would reasonably believe.

**Step 2 — Trace each claim through the stack.** Interface → handler → service → database or provider
→ response → refreshed interface. Note exactly where each breaks.

**Step 3 — Classify honestly.** Each claim is: **verified real**, **partial**, **awaiting
configuration** (real code, missing credentials), **labeled demo** (fake and clearly presented as
such), **misleading demo** (fake and presented as real), or **not implemented**.

**Misleading demo is the finding that matters.** Labeled demos are fine — they are honest. The damage
comes from a user, client, or teammate believing something works when it does not.

**Step 4 — Fix, highest-severity first.** Severity is about the gap between the claim and the reality,
not the difficulty of the fix. A fake save button outranks a missing loading spinner every time.

**Step 5 — Re-run every verification.** Same procedures, plus regression tests that would catch the
fake returning: assert that different inputs produce different outputs, that data survives a
simulated new session, that a cross-user request is refused.

**Step 6 — Report with evidence**, including what you could not verify.

## Signatures worth recognizing

- Arrays of realistic-looking data defined inside a component
- A `setTimeout` standing in for a network call
- A success path with no corresponding error path
- An async function with no `await` of anything external
- A handler that returns a fixed shape regardless of its arguments
- Credentials read but never used
- A "generate" or "analyze" function containing no branching on its input
- Comments like "replace with real API" left in a shipped path
- A `catch` block that swallows and returns success
- Authorization checked in the component and nowhere else
- Round, suspiciously pleasant numbers on a dashboard

## Guardrails

- **Never replace a fake with a better-disguised fake.** If the real implementation cannot be built
  now, label it clearly as unavailable and say so in the report. An honest empty state is a legitimate
  outcome; a more convincing stub is not.
- **Never assert a claim is real without having run the test.** "The code looks correct" is not
  verification — reading code is exactly what this method exists to supplement.
- **Never delete a feature to resolve a finding** unless explicitly asked. Report it.
- **Do not confuse configuration gaps with fakes.** Real code missing an API key is a different finding
  from code that never calls anything, with a different fix and a different severity.
- **Do not fix silently.** Every correction is reported with what was wrong and how it was verified
  afterwards.
- **State what could not be tested.** Some paths need credentials, third-party sandboxes, or
  production data. Listing them honestly is far more useful than an unqualified "verified".

## Report format

Per claim: the claim as the interface presents it, the classification, the evidence (the specific test
run and its result), and — where fixed — what changed and how the fix was verified.

Close with: what was tested and how, what was fixed, **what could not be verified and why**, and the
remaining risks. A report that says "eleven of fourteen claims verified real, two fixed, one
unverifiable without production credentials" is worth far more than one claiming everything works.
