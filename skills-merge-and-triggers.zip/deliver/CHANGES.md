# Skill library changes — merge + trigger tuning

Applied against the live library as of 2026-07-26 07:48 (54 skills). Result: **53 skills.**

## How to apply

Two different kinds of thing are in this bundle. They install differently.

1. **`accessible-one-hand-ux/`** — a complete skill directory. Replace the existing one wholesale,
   then **delete `designing-accessible-one-hand-ux/`**. The merge is only finished once the old
   skill is gone; leaving both installed reinstates the collision this was meant to fix.
2. **Every other folder** — contains a `SKILL.md` and nothing else. Replace only that one file.
   The `references/`, `scripts/`, and `assets/` in those skills are untouched and should be
   left exactly as they are.

## 1. Merged the duplicate pair

`accessible-one-hand-ux` and `designing-accessible-one-hand-ux` shared **58% of their trigger
vocabulary** — near-duplicates competing for the same requests, with the thinner one winning
roughly half the time.

They turned out to be complementary rather than redundant:

| | had | lacked |
|---|---|---|
| `accessible-one-hand-ux` | 8-step workflow, audit/design modes, comfort questionnaire, `generate_layout.py`, 6 references, output templates | concrete interaction rules in the body |
| `designing-accessible-one-hand-ux` | the five hard constraints, reach zones, fatigue budgeting, substitution table | workflow, deliverable format, tooling |

The merge keeps the first skill's name and structure and folds in the second's substance:

- Added a **five hard constraints** section (two-contact, drag-only, strict timing, target
  spacing, reversibility) between the principles and the workflow.
- Added a **reach, handedness, and fatigue** section — thumb arc zones, handedness inverting the
  layout, fatigue as a countable interaction budget, interrupted sessions.
- Promoted constraint-checking to **step 3** of the workflow, ahead of the finer-grained barrier
  pass, because it catches blocking defects fastest. Steps renumbered 8 → 9.
- Carried `interaction-rules.md` over as a 7th reference, labelled **quick lookup** against
  `remediations.md`'s **full catalog** so the two don't compete.
- Absorbed two guardrails that only existed in the retired skill: never ship a worse alternative
  path, never evaluate only when fresh and only on the largest screen.
- Kept the closing test verbatim: *can the whole task be finished by someone who can only tap,
  one finger at a time, imprecisely, with pauses?*

Verified: all 17 distinct concepts from the retired skill survive, and `generate_layout.py` still
runs clean.

## 2. Trigger tuning — 10 handoff clauses

Before this pass, exactly one pair in the library disambiguated itself —
`database-query-optimization` ↔ `performance-profiling-and-optimization`, which does it well.
That pattern is now applied to every other adjacent pair. Each clause sits on the **roomier**
side of the pair, since four descriptions were within ~30 characters of the 1024 cap.

| skill | clause added |
|---|---|
| `accessibility-regression-audit` | → `accessible-one-hand-ux` for designing/auditing in the first place |
| `auditing-existing-codebases` | assesses and reports; `refining-projects-for-release` performs the fixes |
| `preventing-fake-implementations` | → `auditing-existing-codebases` for a whole-repo assessment |
| `background-job-reliability` | → `webhook-and-event-reliability` for inbound callbacks |
| `webhook-and-event-reliability` | → `background-job-reliability` for self-initiated work |
| `enforcing-production-quality` | whether it works vs. `building-premium-interfaces` for how it feels |
| `demo-to-production-conversion` | → `multi-tenant-client-portal` for tenancy and isolation design |
| `designing-ai-tool-schemas` | → `human-approval-workflows` for the approval step itself |
| `integration-connector-builder` | → `privacy-and-data-retention` for storage, retention, subprocessors |
| `privacy-and-data-retention` | policy/inventory vs. `security-and-privacy-review` (attack testing) and `sensitive-records-and-exports` (sharing) |

`auditing-existing-codebases` had 22 characters of headroom, so one redundant trigger phrase
("review this codebase before we build more features" — already covered by "audit this repo" and
"review… a repository") was removed to make room.

## 3. Findings not acted on

- **Three skills were added at 07:48, mid-session**: `api-contract-and-versioning`,
  `data-sync-and-reconciliation`, `integration-observability-and-triage`. All three are cleanly
  differentiated — highest overlap with anything existing is 0.11, below the near-miss threshold.
  No changes needed. They are included in the 53 count but not in this bundle.
- `incident-response-and-debugging` ↔ `integration-observability-and-triage` scored 0.11. Both
  fire on "something is broken in production." Below the threshold and both descriptions are
  specific, so left alone — but it's the pair most likely to need a handoff next.

## Verification run

- 53 skills, every `description` present and under the 1024-character cap
- highest remaining overlap **0.15**, down from 0.58 (measured with handoff clauses excluded, so
  naming a sibling skill doesn't inflate the score)
- every pair above 0.12 now carries an explicit handoff
- `accessible-one-hand-ux/scripts/generate_layout.py --example` exits 0

Rebuild is scripted and idempotent in `build.py` — re-runnable against a changed source library.
