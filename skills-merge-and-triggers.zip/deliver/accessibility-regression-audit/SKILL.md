---
name: accessibility-regression-audit
description: >-
  Verify that an interface change did not break accessibility that previously worked — checking one-handed use, keyboard navigation, voice access, switch and sequential navigation, reduced precision, left- and right-handed layouts, reduced motion, high contrast, screen zoom, target sizes, and undo paths. Use after any interface change to an accessibility-sensitive product: a redesign, a new component, a layout change, a framework or library upgrade, or before merging UI work. Also use when someone asks "did this break anything", "check accessibility before I ship", or reports that something that used to work no longer does. Trigger on UI diffs even when the change looks cosmetic, since spacing, ordering, and focus regressions are exactly the kind that ship unnoticed. For designing or auditing one-handed and motor accessibility in the first place — rather than checking whether a change broke it — use accessible-one-hand-ux instead.
---

# Accessibility Regression Audit

## What this is for

Not an initial accessibility review — that is design work, covered by
`designing-accessible-one-hand-ux`. This is the narrower, repeatable question:

**Did this change break something that used to work?**

Accessibility regressions are unusually easy to ship because they are invisible to the person making
the change. A refactor reorders the DOM and destroys tab order. A component library upgrade shrinks
touch targets. A layout tweak moves the primary action out of thumb reach. A new modal traps focus. A
CSS change removes a focus indicator. Every one of these passes visual review, and several pass
automated checkers too.

**The audit is a fixed checklist run against a real build every time**, because the value comes from
running the same checks repeatedly rather than from cleverness.

## Scope the audit to the change

Full audits are expensive and get skipped, which makes them worthless. Scope by what the diff touched:

- **Component changed** → audit that component in every context it appears
- **Layout or spacing changed** → reach, target size, and separation on the affected screens
- **Navigation, routing, or DOM order changed** → focus order, focus management, and sequential
  traversal
- **New interactive element** → the full checklist for that element
- **Library or framework upgrade** → a broad pass, since these change defaults invisibly and across the
  whole surface
- **Styling-only change** → focus indicators, contrast, target size, and motion

**When in doubt, widen the scope.** A missed regression in this domain locks someone out.

## The checklist

Run against a real build, not code review. Each line is either verified or a finding.

**One-handed operation**
- [ ] Every primary action reachable by thumb, both left and right hand
- [ ] No action requires two simultaneous contact points
- [ ] No action is drag-only
- [ ] Primary actions still in the comfortable zone; destructive ones still out of it

**Keyboard**
- [ ] Every interactive element reachable by tab
- [ ] Tab order matches visual order and is sensible
- [ ] Focus indicator visible on every focusable element
- [ ] No focus trap; modals return focus on close
- [ ] New content receives or announces focus appropriately
- [ ] Escape closes what it should

**Voice**
- [ ] Every control has a speakable accessible name matching its visible label
- [ ] No icon-only control without a name
- [ ] Names are unique enough to disambiguate on screen

**Switch and sequential navigation**
- [ ] Traversal order sensible and grouped
- [ ] Step count to frequent actions has not increased
- [ ] No interaction requires timing

**Precision and targets**
- [ ] Target sizes at or above the minimum
- [ ] Spacing between interactive elements preserved
- [ ] Destructive controls still separated from frequent ones
- [ ] Hit areas match visual bounds

**Display preferences**
- [ ] Reduced-motion setting respected; no unavoidable animation
- [ ] High contrast mode usable, nothing invisible
- [ ] Text scaling to a large size without clipping, overlap, or loss of function
- [ ] Zoom to a high level without horizontal scrolling of body content

**Recovery**
- [ ] Undo still available for every destructive action
- [ ] Undo itself satisfies every rule above
- [ ] Errors preserve user input
- [ ] Interrupted flows still resume

## Method

**1. Establish the baseline.** Know what worked before. Ideally from a previous audit record; otherwise
run the checklist against the previous build first, or you cannot distinguish a regression from a
pre-existing gap — and that distinction changes what you do about it.

**2. Automated checks first.** They are fast and catch missing names, contrast failures, and some
structural problems. **Treat a clean result as the absence of one class of error, never as evidence of
usability.** No checker can tell you whether a task can be completed one-handed.

**3. Manual passes, one input method at a time.** Keyboard only, then voice only, then tab-only
sequential traversal counting steps, then one-handed on a phone in each hand. Complete a real task each
time — not "can I focus this" but "can I finish it."

**4. Display preference passes.** Reduced motion, high contrast, large text, high zoom.

**5. Record the result** so it becomes the next audit's baseline. This is what makes the practice
compound.

## Reporting

Per finding: what broke, which check found it, which change caused it if identifiable, severity, and
the specific fix.

**Severity by consequence, not by effort:**
- **Blocking** — a task cannot be completed by some input method. Ship-stopping.
- **Serious** — completable but substantially harder: more steps, precision now required, undo lost.
- **Minor** — friction without exclusion.

Close with what was checked, what passed, what could not be tested and why, and whether anything found
was pre-existing rather than a regression.

## Guardrails

- **Never accept an automated pass as the audit.**
- **Never audit only the changed screen.** Shared components regress everywhere they appear.
- **Never skip the audit for a cosmetic change** — spacing, ordering, and focus regressions are almost
  always cosmetic changes.
- **Never test only in one handedness setting**, and never only on the largest screen.
- **Never mark a check passed you did not run.** An honest gap is useful; a false pass means the next
  person trusts a check nobody performed.
- **Do not fix a regression by removing the feature** unless that is genuinely the decision — report it
  and let someone choose.
