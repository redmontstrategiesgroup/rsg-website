---
name: auditing-existing-codebases
description: >-
  Perform a rigorous, evidence-based technical AND product audit of an existing codebase — reverse-engineering what the product is meant to do, then tracing the real implementation behind every feature to expose the gap between what is claimed and what actually works. Use this whenever the user wants to audit, review, assess, vet, inherit, or get an honest read on a repository, app, or codebase. Trigger on requests like "audit this repo", "is this app actually finished / real / production-ready", "what's fake vs real here", "why does this feel hollow", "do a security and quality review", "find the mock data / dead buttons / fake integrations", "I inherited this codebase and don't trust it", or a user just pointing at a repo and asking whether it's any good. Especially trigger when a slick-looking app might be hiding a missing or fake backend, since the point of this skill is to look past the visual surface at what is genuinely wired up. Assesses and reports; refining-projects-for-release performs the fixes.
---

# Auditing Existing Codebases

You are conducting a forensic audit of a codebase. Your job is to determine, with evidence,
**what this product actually does versus what it claims to do**, and to hand back an honest,
prioritized account a founder or engineering lead can act on.

The single most valuable thing you produce is *grounded truth*. A codebase can look finished —
polished UI, confident copy, a full-looking dashboard — and still be hollow underneath: mock
data dressed as real, buttons that do nothing, "integrations" that are never called, auth that
only exists in the browser. Your value is seeing past the surface to the wiring. Conversely, a
plain-looking repo can be solid and production-ready. Report what is *true*, not what *looks*
true.

## The one rule that makes this audit worth anything: evidence discipline

An audit with no evidence is just vibes, and vibes are exactly what this skill exists to
puncture. So hold yourself to a strict standard:

- **Every finding cites a concrete location** — `path/to/file.ts:120-134`, a specific route, a
  named function, a table. "The app has poor error handling" is not a finding. "`submitOrder()`
  in `src/checkout/actions.ts:44` swallows all errors in a bare `catch {}` and returns
  `{ ok: true }` regardless, so a failed charge shows the user a success screen" is a finding.
- **Every finding shows the evidence** — the actual snippet, the command output, the missing
  call. Quote the code. Paste the failing build line. Show the empty handler.
- **Separate CONFIRMED from SUSPECTED.** If you traced it end to end and it's fake, say
  *confirmed*. If it smells fake but you haven't proven it, say *suspected* and state exactly
  what would confirm it (e.g., "grep shows no `fetch`/SDK call in this module; confirm by
  checking whether `NEXT_PUBLIC_*` keys are even set"). Never upgrade a suspicion to a fact.
- **Do not pad.** A generic checklist item you didn't actually verify ("consider adding rate
  limiting") is noise. Only report what you looked at. Ten real, located findings beat forty
  boilerplate ones, and padding destroys the credibility of the genuine findings.
- **Credit what's genuinely good.** Honesty cuts both ways. If the auth is properly enforced
  server-side, if the tests are real and meaningful, if the data model is clean — say so
  specifically. An audit that only lists problems is neither honest nor useful.

If you catch yourself writing a finding you cannot point to a file for, stop and either go find
the evidence or delete the finding.

## Do no harm

Audit read-only. **Do not modify the repository's source, git history, or configuration**, and
do not push, deploy, or open PRs. The one carve-out: you may take actions genuinely required to
*run* the project so you can verify it — installing dependencies, generating a lockfile, copying
`.env.example` to `.env` with placeholder values. That's it. Note any such action in the report.

Be careful that verification commands don't cause real-world side effects. Tests or seed scripts
can hit a live database, send real email, or call paid APIs if the repo is misconfigured. Prefer
a dev/test environment. If a command looks like it could mutate external state and you can't
confirm it's safe, **skip it and report it as skipped-for-safety** rather than risk damage.

## Workflow

Work through these phases in order. Earlier phases feed later ones — you cannot judge a "gap"
in phase 5 without the "claim" you established in phase 1.

### Phase 0 — Orient
Locate the repo (often under `/mnt/user-data/uploads/`, or a path the user gives). Get a feel
for size and shape: top-level layout, languages, `README`, and any obvious monorepo structure.
Detect the stack(s) — you'll use this to pick the right verification commands and the right
playbook. Don't go deep yet; just build a map of the territory.

### Phase 1 — Reverse-engineer intent (establish the claim)
Before evaluating anything, figure out what this product is *supposed* to be. This is your
yardstick for every later judgment. Read the `README` and any docs, but **do not stop there** —
docs lie or lag. Triangulate the real intent from:
- **UI copy and marketing** — landing pages, headings, button labels, feature lists, pricing
  tiers. These are the *promises*.
- **Routes and page names** — `/dashboard`, `/billing`, `/team/invite` each imply a capability.
- **Database schema** — tables and columns reveal the intended domain model and features.
- **Environment variables and config** — `STRIPE_SECRET_KEY`, `RESEND_API_KEY`,
  `SUPABASE_SERVICE_ROLE_KEY` name the integrations the product *intends* to have.
- **Auth system** — what roles, permissions, and gated features are implied.

Produce an explicit **Claimed Capabilities** list — the features a user would reasonably believe
exist. Do not judge the product by its visual polish; polish is often the mask, not the product.
See `references/methodology.md` for how to do this well.

### Phase 2 — Map the surface
Inventory the moving parts so nothing is missed and orphans become visible:
- **Routes/pages** and which are reachable vs. dead.
- **API endpoints / server actions / RPCs** and what each claims to do.
- **Database tables** and — critically — which are actually *read from* and *written to*.
- **Auth & authorization** — where checks live (client? server? middleware?).
- **Integrations & external services** and where each is actually invoked.
- **Background jobs, webhooks, cron.**

This map surfaces the tells: a route with no backend, a table never written to, an endpoint
nothing calls, an integration configured but never imported.

### Phase 3 — Trace each feature end to end (the heart of the audit)
For **every** Claimed Capability from Phase 1, follow the wire the whole way:
UI trigger → handler/action → business logic → persistence → external service → response → UI.
At each hop ask the forensic question: **is this real, or is it theater?**

This is where you catch the fakery this skill is named for — mock data posing as real, no-op
buttons, hardcoded responses, fake integrations, client-only auth, missing persistence.
`references/methodology.md` gives concrete, grep-able detection recipes for each. Use them. Trace
the code; never trust the demo or the screenshot.

### Phase 4 — Run the verifications (get ground truth)
Reading is not enough — *execute*. From the skill's `scripts/`:
- `bash scripts/run_checks.sh <repo-path>` — auto-detects the stack and runs type-checking,
  linting, tests, and a production build, capturing real exit codes and output. A failing build
  or a red test suite is ground truth, not opinion. **Read the actual errors** — they routinely
  reveal broken imports, missing env, type holes, and dead code.
- `bash scripts/scan_secrets.sh <repo-path>` — scans for committed `.env` files, hardcoded
  credentials, and known key formats (AWS, Stripe, GitHub, Slack, Google, private keys, Supabase
  `service_role`). Any hit is likely Critical.

If a check can't run, that itself is a finding (missing scripts, broken toolchain, etc.). When
you quote a leaked secret in the report, **mask it** — show a prefix like `sk_live_51H8…` and
never the full value.

### Phase 5 — Systematic sweep
Now walk the full category checklist in `references/audit-checklist.md` — security, data
integrity, error/loading/empty states, accessibility, mobile, performance, dead code, duplicate
components, abandoned routes, unused dependencies, tests, deployment risk, and more. For each
category the checklist tells you *how to detect* the issue and *how to rate its severity*. Pull
in `references/stack-playbooks.md` for stack-specific traps (e.g. Next.js server/client boundary
and `NEXT_PUBLIC_` leakage; Supabase Row Level Security and `service_role` exposure).

### Phase 6 — Classify, synthesize, and deliver
Assign a severity to every finding using the rubric below. Write each finding in the required
seven-part structure. Then step back and write the honest synthesis — maturity rating, real
strengths, biggest risks, biggest product gaps, order of operations, and a phased roadmap.
Assemble the report from `assets/report-template.md` and deliver it (see Output contract).

## Severity rubric

Calibrate to real-world risk and user/business impact, not to how easy something is to nitpick.

- **Critical** — Actively broken, exploitable, or fundamentally dishonest. Exploitable security
  hole (auth bypass, injection, exposed secret, no server-side authorization), data loss or
  corruption, or a *core advertised feature that is fake/non-functional* (e.g. "checkout" never
  charges, "save" never persists). Ship-stopping. Fix before anything else.
- **High** — Serious but not catastrophic: a real feature broken in common cases, missing
  persistence on a secondary flow, a significant vulnerability requiring some precondition,
  no tests around critical paths, a production build that fails. Fix before new feature work.
- **Medium** — Real quality/robustness problems that degrade the product but don't break or
  expose it: missing error/empty/loading states on important flows, meaningful a11y gaps, poor
  mobile behavior on key screens, notable perf issues, meaningful dead code or duplication.
- **Low** — Polish and hygiene: minor inconsistencies, small unused-dependency bloat, cosmetic
  a11y nits, stylistic drift, TODOs. Worth listing, cheap to fix, not blocking.

When unsure between two levels, state your reasoning and pick the higher one if real users or
data are at risk. Detailed examples per category live in `references/audit-checklist.md`.

## Every finding uses this exact structure

For **each** finding, provide all seven, in order:

1. **The exact problem** — one or two precise sentences. Lead with CONFIRMED or SUSPECTED.
2. **Affected file paths** — specific paths with line ranges where possible.
3. **Evidence** — the code snippet, command output, or the conspicuous *absence* (e.g. "no
   `INSERT`/`update()` anywhere for this table"). Show, don't assert.
4. **User / business impact** — who is hurt and how. Tie it to the product, not to abstract
   correctness ("users believe their payment succeeded but no order is created").
5. **Recommended correction** — the concrete fix, specific enough to act on.
6. **Estimated effort** — a rough size (e.g. ~1 hr, ~1 day, ~1 week) with a one-line basis.
7. **Fix before further feature development?** — Yes/No, with a short why.

## Output contract

Deliver **both**:

1. **A saved Markdown report file** — the full audit, built from `assets/report-template.md`,
   written to `/mnt/user-data/outputs/` (e.g. `outputs/audit-<project>.md`) and presented to the
   user with `present_files`. This is the primary deliverable; a real audit is a document, not a
   chat message.
2. **A tight chat summary** — a short spoken-language wrap in the conversation: the maturity
   rating, the 2–4 things that genuinely matter most (usually the Criticals), and the single
   recommended first move. Enough to orient at a glance; the file holds the depth. Do not dump
   the whole report into chat.

The report must end with the honest synthesis the user asked for: a product maturity rating, the
strongest parts of the current implementation, the biggest technical risks, the biggest product
gaps, the recommended order of operations, and a phased recovery/improvement roadmap. The
template lays out the exact structure — follow it.

## Reference material (read as needed)

- `references/methodology.md` — how to reverse-engineer intent and, crucially, the concrete
  fake-vs-real detection recipes (grep patterns and code smells). The signature technique of
  this skill; read it early.
- `references/audit-checklist.md` — the exhaustive, category-by-category checklist with
  detection guidance and severity calibration for each item.
- `references/stack-playbooks.md` — stack-specific gotchas (Next.js/React, Supabase, Node/
  Express, Python/Django/FastAPI, Rails, Go, mobile/RN). Read the one(s) matching the repo.
- `assets/report-template.md` — the exact output structure for the report file.
- `scripts/run_checks.sh` — stack-detecting verification runner (typecheck/lint/test/build).
- `scripts/scan_secrets.sh` — exposed-secret and credential scanner.
