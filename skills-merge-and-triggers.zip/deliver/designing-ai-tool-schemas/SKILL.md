---
name: designing-ai-tool-schemas
description: >-
  Design tools for AI agents to call so they are narrow, explicit, validated, permission-aware, and hard to misuse — covering parameter design and validation, scoping to the acting user's permissions, resistance to parameter tampering and prompt injection, clear separation of reversible from irreversible actions, and which operations require human confirmation. Use whenever someone is defining tools or function schemas for an agent, exposing an API to a model, reviewing what an agent is allowed to do, or asks "how should I structure this tool", "how do I stop the agent doing something destructive", "should this need approval", or "how do I keep the model from passing the wrong ID". Trigger on any tool that writes data, spends money, sends messages, or reads records belonging to someone. For designing the approval step itself — what the approver sees, how consent is scoped, batching — use human-approval-workflows.
---

# Designing AI Tool Schemas

## The security premise

**Treat every tool call as arriving from an untrusted client.**

A model's tool arguments are influenced by everything in its context — including documents it read,
web pages it fetched, and messages other people wrote. A tool that trusts its parameters is a tool
that can be driven by whoever controls any of that content. This is not hypothetical; it is the
standard shape of a prompt injection attack.

The consequence: **authorization belongs in the tool implementation, bound to the session's actor —
never in the parameters.** A tool taking a `user_id` and acting on it will act on whichever ID appears
in the arguments, and the argument is exactly what an attacker gets to influence.

## Design rules

**Narrow beats general.** A tool that does one thing with three parameters is safer and gets called
more correctly than a general tool with a mode flag and twelve. `cancel_subscription(id)` is better
than `manage_subscription(id, action, options)` — the general version's blast radius includes actions
you did not intend to expose in this context, and the model picks the mode from ambiguous context.

**Explicit beats inferred.** No parameter should require the model to guess a format, unit, or
convention. Use enums for anything with a fixed set of values, state units in the name
(`amount_cents`, `duration_seconds`), and use unambiguous formats.

**Read and write are separate tools.** Never a flag that switches between them, because a flag is one
token away from the wrong value.

**Small result sets.** Return what is needed, paginated, with a cap. Dumping a hundred records into
context is expensive, degrades reasoning, and increases the injection surface.

**Descriptions are part of the interface.** The model chooses tools from their descriptions, so state
what the tool does, when to use it, when *not* to, what it costs, and whether it is reversible. A vague
description produces wrong calls that look like model failures but are schema failures.

## Parameters

- **Validate everything server-side** against a schema, exactly as with a public API. Reject unknown
  fields.
- **Never accept identity or scope as a parameter** — no user ID, tenant ID, account ID, or role.
  Derive them from the session.
- **Constrain rather than free-form.** Enums over strings, allowlists over patterns, bounded ranges over
  open numbers. A sort field should be an enum; a file path parameter should be a key into a known set,
  not a path.
- **Bound everything with a cost** — limits, quantities, date ranges. An unbounded parameter is an
  unbounded bill or an unbounded query.
- **Prefer stable opaque identifiers** the model obtained from a previous read, and validate that the
  referenced object is within the actor's scope before acting.

## Reversibility determines the gate

Classify every tool, and let the classification drive the controls:

- **Read** — no side effects. Still scoped and rate-limited; still capable of exfiltrating data if
  results flow somewhere.
- **Reversible write** — creating a draft, updating a record with history, adding a tag. Safe to
  execute directly, provided it is scoped and audited.
- **Irreversible or externally visible** — sending a message, publishing, deleting, charging, granting
  permissions, deploying, triggering an external workflow. **These require explicit human confirmation
  of the specific action**, with the actual parameters shown.

**Confirmation must be per-action and specific.** "Allow this agent to send emails" granted once is not
consent to the twentieth email. Show the recipient, the content, the amount — the concrete thing — and
get agreement to that. See `human-approval-workflows` for the approval model itself.

**Make irreversible tools idempotent** anyway. Agents retry.

## Resisting injection through tool results

The output of a tool is data, not instruction. A fetched page, a read document, a retrieved record, or
another user's message may contain text directed at the model.

- **Label tool results as data** in the context, clearly delimited from instructions.
- **Never let a tool result raise the agent's permissions**, select the next tool unconditionally, or
  supply a parameter to a subsequent write without passing back through the actor's scope check.
- **Be suspicious of the pattern where a read tool's output determines a write tool's target.** That
  chain is the standard exfiltration path: read something attacker-controlled, then send data
  somewhere the attacker named.
- **Recipients, URLs, and destinations should come from the user or an allowlist**, never from content
  the agent read.

## Guardrails

- **Never put authorization in the parameters.**
- **Never expose an unbounded query or an arbitrary code-execution tool** without a strong sandbox and
  explicit consent.
- **Never let the model choose whether confirmation is needed** — that is a property of the tool.
- **Never return secrets, tokens, or credentials in a tool result.** They enter context and may be
  echoed.
- **Never silently expand what a tool can do.** Widening scope is a permission change and needs the same
  scrutiny as a new tool.
- **Audit every call**: actor, tool, parameters (redacted), outcome, and whether it was confirmed.
- **Do not ship a tool you have not tried to misuse.** Attempt the cross-user access, the tampered
  identifier, the injected instruction in a document. The tool is done when those attempts fail
  cleanly.
