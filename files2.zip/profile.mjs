// Real: persist to the datastore; read back from the same place.
export async function saveProfile(store, userId, prefs) {
  const { error } = await store.upsert('user_settings', { user_id: userId, ...prefs });
  if (error) throw new Error(error.message || 'save failed');
  return { ok: true };
}
export async function loadProfile(store, userId) {
  const { data } = await store.select('user_settings');
  return (data || []).find((r) => r.user_id === userId) || null;
}
