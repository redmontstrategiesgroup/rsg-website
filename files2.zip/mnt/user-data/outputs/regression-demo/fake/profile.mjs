// Fake: writes only to a browser-local object; the datastore is never touched.
const browserLocal = {};
export async function saveProfile(store, userId, prefs) {
  browserLocal[userId] = JSON.stringify(prefs);           // localStorage-style
  await new Promise((r) => setTimeout(r, 5));              // simulate a network save
  return { ok: true };
}
export async function loadProfile(store, userId) {
  const { data } = await store.select('user_settings');   // real app reads from DB
  return (data || []).find((r) => r.user_id === userId) || null;
}
