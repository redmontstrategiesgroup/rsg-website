import { test } from 'node:test';
import assert from 'node:assert/strict';
import { makeStore } from '../mocks.mjs';
const impl = process.env.IMPL || 'fixed';
const { saveProfile, loadProfile } = await import(`../${impl}/profile.mjs`);

test('profile_save_persists_to_datastore', async () => {
  const store = makeStore();
  await saveProfile(store, 'u1', { theme: 'dark' });
  const wrote = store.calls.some((c) => c.op === 'upsert' && c.table === 'user_settings' && c.row.theme === 'dark');
  assert.ok(wrote, 'expected an upsert to user_settings');
});
test('profile_survives_reload_from_source_of_truth', async () => {
  const store = makeStore();
  await saveProfile(store, 'u1', { theme: 'dark' });
  const reloaded = await loadProfile(store, 'u1');
  assert.equal(reloaded?.theme, 'dark', 'settings should survive a reload');
});
