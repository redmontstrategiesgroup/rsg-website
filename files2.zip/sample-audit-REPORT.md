# Truthfulness Report: sample-app (settings, dashboard, admin, checkout, integrations)

> This is the report the `preventing-fake-implementations` skill produced when run against the test
> sample app, as a demonstration of the output. Four of the fixes below (persistence, metrics,
> authorization, payments) were implemented as runnable modules with regression tests that were actually
> executed — they pass on the fix and fail when reverted to the fake.

## Summary
- Scope audited: whole app (11 source files)
- Capabilities examined: 10, plus 1 security finding
- Verified real: 1 · Partial: 1 · Awaiting config: 1 · Labeled demo: 1 · **Misleading: 5** · **Not implemented: 1**  (+1 secret-exposure bug)
- Environment limits: no live Stripe or Slack credentials here, so end-to-end charge and message delivery could not be exercised; those paths were wired to be real and to fail loudly without config.
- Headline: most of the trust-bearing surface — saving settings, revenue, admin authorization, checkout, and the Slack "test connection" — was simulated. A live Stripe **secret** key is also exposed to the browser.

## Highest-risk findings
- **Checkout never charges (money-critical).** `POST /api/checkout` returned `{ status: 'succeeded' }` with no processor call, so orders could be "paid" for free. Wired a real Stripe path that fails loudly without keys and fulfills only on a verified intent status. **Flagged for review** before going live.
- **Admin authorization is client-only (security-critical).** The UI hid admin controls via `isAdmin(user)`, but `POST /api/admin/settings` performed the update with no server-side check — any caller could hit it directly. Added server-enforced authorization. **Flagged for review**; ideally back this with RLS too.
- **Stripe secret key exposed to the client.** `NEXT_PUBLIC_STRIPE_SECRET_KEY = 'sk_live_…'` ships to the browser. Must become a server-only `STRIPE_SECRET_KEY` used only in server code, and the leaked key rotated. (The `NEXT_PUBLIC_SUPABASE_ANON_KEY` alongside it is fine — anon keys are meant to be public.)
- **"Ban user" does nothing.** The button only updates local component state; no endpoint exists. Users appear banned until reload.

## Capability-by-capability

| Capability | Claim it makes | Classification | Evidence (traced) | Action taken | Unverified / remaining | Regression test |
|---|---|---|---|---|---|---|
| Notes (add/list) | Notes are saved and listed | **Verified real** | `Notes.tsx` → `lib/notes.ts` inserts and selects the same `notes` table; errors thrown, not swallowed. | None | — | (add `notes_persist_and_reload` when hardening) |
| Settings save | "Settings saved!" persists prefs | **Misleading → fixed** | `save()` wrote `localStorage` only; page reads `user_settings` from Supabase → fails the refresh test. | Fixed: upsert to `user_settings`; read path unchanged. | — | `profile_save_persists_to_datastore`, `profile_survives_reload_from_source_of_truth` ✅ ran |
| Revenue tile | Shows monthly revenue | **Misleading → fixed** | Value was `Math.round(Math.random()*250000)`. | Fixed: aggregate `orders`. | — | `revenue_reflects_underlying_orders`, `revenue_tracks_changes_in_data` ✅ ran |
| Recent orders list | Lists recent orders | **Partial** | Orders are written elsewhere, but this list renders a hardcoded `RECENT_ORDERS` constant, so new orders never appear. | Fix: read from the real `orders` query. | — | `recent_orders_include_newly_created` |
| Analytics example table | (labeled "Example data") | **Demo, correctly labeled** | Seeded rows rendered under a visible "Example data" badge; a user can tell it isn't their data. | None — acceptable | — | badge-renders assertion (optional) |
| Export CSV | Downloads my filtered data | **Misleading → fix** | Returns a constant `SAMPLE_CSV` regardless of data or filters. | Fix: build CSV from the real filtered query. | — | `export_contains_real_filtered_data` |
| Admin authorization | Only admins can change org settings | **Misleading (client-only) → fixed, flagged** | `isAdmin` gated the UI; the endpoint did no server check. | Server-enforced authorization added; recommend RLS. | Belt-and-braces RLS policy not added here | `org_settings_forbidden_for_non_admin_at_server` ✅ ran |
| Ban user | Bans the user | **Not implemented** | `ban()` updates local state; no endpoint exists. | Fix: real endpoint with server authz + persistence. | Endpoint to be built | `ban_persists_and_enforced_server_side` |
| Slack integration | "Test connection" confirms Slack works | **Misleading → awaiting config** | Webhook saved but never read; `testSlackConnection()` returns `{ok:true}` unconditionally. | Wired real `notify()`/`testConnection()` that POST to the webhook and fail loud without it. | Live delivery unverified (no workspace webhook) | `slack_test_connection_makes_real_request`, `slack_notify_posts_to_webhook` |
| Checkout | Charges the customer | **Misleading (money) → fixed, flagged** | Returned `succeeded` with no Stripe call. | Real Stripe path; fails loud without keys; fulfill only on verified status. | End-to-end charge unverified (no live keys) | `checkout_calls_processor_with_amount`, `checkout_fails_loud_without_processor` ✅ ran |
| Secret exposure (finding) | — | **Bug → fix** | `NEXT_PUBLIC_STRIPE_SECRET_KEY` ships to the browser. | Move to server-only `STRIPE_SECRET_KEY`; rotate the leaked key. | Rotation is an ops step | n/a (lint rule recommended) |

## Could not be verified end to end
- **Stripe checkout** — no live/test keys in this environment. The real path is wired and fails loudly without keys; a live charge was not exercised.
- **Slack delivery** — no workspace webhook. The real POST is wired and fails loudly without a URL; actual message delivery was not exercised.

## Setup required to finish verification
- Set server-only `STRIPE_SECRET_KEY` (and rotate the exposed one); run `checkout_calls_processor_with_amount` against Stripe test mode.
- Store a real Slack webhook in `integrations.webhook_url`; run `slack_test_connection_makes_real_request`.
- Add a Supabase RLS policy on `org_settings` so authorization is enforced at the database, not only in the route.
